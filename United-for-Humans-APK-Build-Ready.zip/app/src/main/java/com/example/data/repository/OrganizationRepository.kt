package com.example.data.repository

import com.example.core.AppConfig
import com.example.core.OperationType
import com.example.core.handleFirestoreError
import com.example.data.model.ActivityItem
import com.example.data.model.NoticeItem
import com.example.data.model.OrganizationInfo
import com.example.data.model.PositionItem
import com.example.data.model.ServiceCategory
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class OrganizationRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    private fun requireUserId(): String =
        auth.currentUser?.uid?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("অনুগ্রহ করে প্রথমে লগইন করুন।")

    fun observeOrganization(): Flow<OrganizationInfo?> {
        val path = "organizations/${AppConfig.ORGANIZATION_ID}"
        return db.collection("organizations").document(AppConfig.ORGANIZATION_ID)
            .snapshots()
            .map { doc ->
                if (!doc.exists()) null
                else doc.toObject(
                    OrganizationInfo::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }
            .catch { error ->
                val firestoreErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreErr == null && error is CancellationException) throw error
                handleFirestoreError(error, OperationType.GET, path)
                emit(null)
            }
    }

    fun observeServices(): Flow<List<ServiceCategory>> {
        val path = "services"
        return db.collection(path)
            .whereEqualTo("organizationId", AppConfig.ORGANIZATION_ID)
            .snapshots()
            .map { snap ->
                snap.documents.mapNotNull { doc ->
                    doc.toObject(
                        ServiceCategory::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }.sortedBy { it.sortOrder }
            }
            .catch { error ->
                val firestoreErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreErr == null && error is CancellationException) throw error
                handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    fun observeActivities(): Flow<List<ActivityItem>> {
        val path = "activities"
        return db.collection(path)
            .whereEqualTo("organizationId", AppConfig.ORGANIZATION_ID)
            .snapshots()
            .map { snap ->
                snap.documents.mapNotNull { doc ->
                    doc.toObject(
                        ActivityItem::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }.sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                val firestoreErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreErr == null && error is CancellationException) throw error
                handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    fun observeNotices(): Flow<List<NoticeItem>> {
        val path = "notices"
        return db.collection(path)
            .whereEqualTo("organizationId", AppConfig.ORGANIZATION_ID)
            .snapshots()
            .map { snap ->
                snap.documents.mapNotNull { doc ->
                    doc.toObject(
                        NoticeItem::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }.sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                val firestoreErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreErr == null && error is CancellationException) throw error
                handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    fun observePositions(): Flow<List<PositionItem>> {
        val path = "positions"
        return db.collection(path)
            .whereEqualTo("organizationId", AppConfig.ORGANIZATION_ID)
            .snapshots()
            .map { snap ->
                snap.documents.mapNotNull { doc ->
                    doc.toObject(
                        PositionItem::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }.sortedBy { it.rank }
            }
            .catch { error ->
                val firestoreErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreErr == null && error is CancellationException) throw error
                handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    suspend fun saveService(item: ServiceCategory): Result<Unit> = try {
        requireUserId()
        if (item.id.isBlank()) {
            db.collection("services").add(item.toCreateMap()).await()
        } else {
            val updates = mapOf(
                "title" to item.title.trim(),
                "titleBn" to item.titleBn.trim(),
                "description" to item.description.trim(),
                "iconKey" to item.iconKey.trim(),
                "active" to item.active,
                "sortOrder" to item.sortOrder,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("services").document(item.id).update(updates).await()
        }
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.WRITE, "services")
        Result.failure(e)
    }

    suspend fun deleteService(serviceId: String): Result<Unit> = try {
        requireUserId()
        db.collection("services").document(serviceId).delete().await()
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.DELETE, "services/$serviceId")
        Result.failure(e)
    }

    suspend fun saveActivity(item: ActivityItem): Result<Unit> = try {
        val uid = requireUserId()
        if (item.id.isBlank()) {
            db.collection("activities").add(item.copy(createdBy = uid).toCreateMap()).await()
        } else {
            val updates = buildMap<String, Any> {
                put("title", item.title.trim())
                put("description", item.description.trim())
                put("category", item.category.trim())
                put("imageUrl", item.imageUrl.trim())
                put("dateText", item.dateText.trim())
                put("location", item.location.trim())
                put("participantsCount", item.participantsCount.coerceAtLeast(0))
                put("beneficiariesCount", item.beneficiariesCount.coerceAtLeast(0))
                put("budget", item.budget.coerceAtLeast(0.0))
                put("status", item.status)
                put("updatedAt", FieldValue.serverTimestamp())
            }
            db.collection("activities").document(item.id).update(updates).await()
        }
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.WRITE, "activities")
        Result.failure(e)
    }

    suspend fun deleteActivity(activityId: String): Result<Unit> = try {
        requireUserId()
        db.collection("activities").document(activityId).delete().await()
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.DELETE, "activities/$activityId")
        Result.failure(e)
    }

    suspend fun saveNotice(item: NoticeItem): Result<Unit> = try {
        val uid = requireUserId()
        if (item.id.isBlank()) {
            db.collection("notices").add(item.copy(createdBy = uid).toCreateMap()).await()
        } else {
            val updates = buildMap<String, Any> {
                put("title", item.title.trim())
                put("body", item.body.trim())
                put("type", item.type)
                put("eventDate", item.eventDate.trim())
                put("location", item.location.trim())
                put("updatedAt", FieldValue.serverTimestamp())
            }
            db.collection("notices").document(item.id).update(updates).await()
        }
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.WRITE, "notices")
        Result.failure(e)
    }

    suspend fun deleteNotice(noticeId: String): Result<Unit> = try {
        requireUserId()
        db.collection("notices").document(noticeId).delete().await()
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.DELETE, "notices/$noticeId")
        Result.failure(e)
    }

    suspend fun savePosition(item: PositionItem): Result<Unit> = try {
        requireUserId()
        if (item.id.isBlank()) {
            db.collection("positions").add(item.toCreateMap()).await()
        } else {
            val updates = mapOf(
                "title" to item.title.trim(),
                "titleBn" to item.titleBn.trim(),
                "rank" to item.rank,
                "description" to item.description.trim(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("positions").document(item.id).update(updates).await()
        }
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.WRITE, "positions")
        Result.failure(e)
    }

    suspend fun deletePosition(positionId: String): Result<Unit> = try {
        requireUserId()
        db.collection("positions").document(positionId).delete().await()
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.DELETE, "positions/$positionId")
        Result.failure(e)
    }
}
