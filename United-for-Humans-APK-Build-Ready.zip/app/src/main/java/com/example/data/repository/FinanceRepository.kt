package com.example.data.repository

import com.example.core.AppConfig
import com.example.core.OperationType
import com.example.core.handleFirestoreError
import com.example.data.model.ContributionRecord
import com.example.data.model.DonationRecord
import com.example.data.model.ExpenseRecord
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class FinanceRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    private fun requireUserId(): String =
        auth.currentUser?.uid?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("অনুগ্রহ করে প্রথমে লগইন করুন।")

    fun observeContributions(): Flow<List<ContributionRecord>> {
        val path = "contributions"
        return db.collection(path)
            .whereEqualTo("organizationId", AppConfig.ORGANIZATION_ID)
            .snapshots()
            .map { snap ->
                snap.documents.mapNotNull { doc ->
                    doc.toObject(
                        ContributionRecord::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }.sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                val firestoreErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreErr == null && error is CancellationException) throw error
                handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    fun observeDonations(): Flow<List<DonationRecord>> {
        val path = "donations"
        return db.collection(path)
            .whereEqualTo("organizationId", AppConfig.ORGANIZATION_ID)
            .snapshots()
            .map { snap ->
                snap.documents.mapNotNull { doc ->
                    doc.toObject(
                        DonationRecord::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }.sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                val firestoreErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreErr == null && error is CancellationException) throw error
                handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    fun observeExpenses(): Flow<List<ExpenseRecord>> {
        val path = "expenses"
        return db.collection(path)
            .whereEqualTo("organizationId", AppConfig.ORGANIZATION_ID)
            .snapshots()
            .map { snap ->
                snap.documents.mapNotNull { doc ->
                    doc.toObject(
                        ExpenseRecord::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }.sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                val firestoreErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreErr == null && error is CancellationException) throw error
                handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    suspend fun addContribution(record: ContributionRecord): Result<Unit> = try {
        val uid = requireUserId()
        db.collection("contributions").add(record.copy(recordedBy = uid).toCreateMap()).await()
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.CREATE, "contributions")
        Result.failure(e)
    }

    suspend fun addDonation(record: DonationRecord): Result<Unit> = try {
        val uid = requireUserId()
        db.collection("donations").add(record.copy(recordedBy = uid).toCreateMap()).await()
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.CREATE, "donations")
        Result.failure(e)
    }

    suspend fun addExpense(record: ExpenseRecord): Result<Unit> = try {
        val uid = requireUserId()
        db.collection("expenses").add(record.copy(recordedBy = uid).toCreateMap()).await()
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.CREATE, "expenses")
        Result.failure(e)
    }

    suspend fun deleteRecord(collection: String, docId: String): Result<Unit> = try {
        requireUserId()
        db.collection(collection).document(docId).delete().await()
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.DELETE, "$collection/$docId")
        Result.failure(e)
    }
}
