package com.example.data.repository

import com.example.core.AppConfig
import com.example.core.OperationType
import com.example.core.handleFirestoreError
import com.example.data.model.AppNotification
import com.example.data.model.ChatMessage
import com.example.data.model.ConversationItem
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class MessagingAndNotificationRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    private fun requireUserId(): String =
        auth.currentUser?.uid?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("অনুগ্রহ করে প্রথমে লগইন করুন।")

    fun observeConversations(uid: String): Flow<List<ConversationItem>> {
        if (uid.isBlank()) return kotlinx.coroutines.flow.flowOf(emptyList())
        val path = "conversations"
        return db.collection(path)
            .whereArrayContains("participantUids", uid)
            .snapshots()
            .map { snap ->
                snap.documents.mapNotNull { doc ->
                    doc.toObject(
                        ConversationItem::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }.sortedByDescending { it.lastMessageAt?.seconds ?: 0L }
            }
            .catch { error ->
                val firestoreErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreErr == null && error is CancellationException) throw error
                handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    fun observeMessages(conversationId: String, uid: String): Flow<List<ChatMessage>> {
        if (uid.isBlank() || conversationId.isBlank()) return kotlinx.coroutines.flow.flowOf(emptyList())
        val path = "conversations/$conversationId/messages"
        return db.collection("conversations").document(conversationId)
            .collection("messages")
            .whereArrayContains("participantUids", uid)
            .snapshots()
            .map { snap ->
                snap.documents.mapNotNull { doc ->
                    doc.toObject(
                        ChatMessage::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }.sortedBy { it.createdAt?.seconds ?: Long.MAX_VALUE }
            }
            .catch { error ->
                val firestoreErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreErr == null && error is CancellationException) throw error
                handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    suspend fun startOrGetConversation(
        otherUid: String,
        otherName: String,
        otherPhoto: String,
        myName: String,
        myPhoto: String
    ): Result<String> = try {
        val myUid = requireUserId()
        val sortedUids = listOf(myUid, otherUid).sorted()
        val convId = "${sortedUids[0]}_${sortedUids[1]}"
        val docRef = db.collection("conversations").document(convId)
        val snap = docRef.get().await()
        if (!snap.exists()) {
            val names = mapOf(myUid to myName.ifBlank { "Member" }, otherUid to otherName.ifBlank { "Member" })
            val photos = buildMap<String, String> {
                if (myPhoto.startsWith("https://")) put(myUid, myPhoto)
                if (otherPhoto.startsWith("https://")) put(otherUid, otherPhoto)
            }
            val data = buildMap<String, Any> {
                put("organizationId", AppConfig.ORGANIZATION_ID)
                put("participantUids", sortedUids)
                put("participantNames", names)
                if (photos.isNotEmpty()) put("participantPhotos", photos)
                put("lastMessage", "")
                put("lastSenderUid", myUid)
                put("lastMessageAt", FieldValue.serverTimestamp())
                put("createdAt", FieldValue.serverTimestamp())
                put("updatedAt", FieldValue.serverTimestamp())
            }
            docRef.set(data).await()
        }
        Result.success(convId)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.WRITE, "conversations")
        Result.failure(e)
    }

    suspend fun sendMessage(
        conversationId: String,
        participantUids: List<String>,
        senderName: String,
        text: String,
        imageUrl: String
    ): Result<Unit> = try {
        val myUid = requireUserId()
        val cleanText = text.trim()
        val cleanImg = imageUrl.trim()
        require(cleanText.isNotEmpty() || cleanImg.startsWith("https://")) {
            "বার্তা বা ছবির লিংক লিখুন।"
        }

        val msgMap = buildMap<String, Any> {
            put("conversationId", conversationId)
            put("participantUids", participantUids)
            put("senderUid", myUid)
            put("senderName", senderName.ifBlank { "Member" })
            put("text", cleanText)
            if (cleanImg.startsWith("https://")) put("imageUrl", cleanImg)
            put("seenBy", listOf(myUid))
            put("createdAt", FieldValue.serverTimestamp())
        }

        val convRef = db.collection("conversations").document(conversationId)
        val msgRef = convRef.collection("messages").document()
        val preview = cleanText.ifBlank { "ছবি পাঠিয়েছেন" }

        val batch = db.batch()
        batch.set(msgRef, msgMap)
        batch.update(
            convRef,
            mapOf(
                "lastMessage" to preview.take(200),
                "lastSenderUid" to myUid,
                "lastMessageAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.commit().await()

        val otherUid = participantUids.firstOrNull { it != myUid }
        if (!otherUid.isNullOrBlank()) {
            createNotification(
                recipientUid = otherUid,
                title = "নতুন বার্তা: $senderName",
                body = preview.take(180),
                category = "message",
                referenceId = conversationId
            )
        }
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.CREATE, "conversations/$conversationId/messages")
        Result.failure(e)
    }

    suspend fun markMessagesSeen(conversationId: String, messages: List<ChatMessage>) {
        val myUid = auth.currentUser?.uid ?: return
        val unseen = messages.filter { it.senderUid != myUid && !it.seenBy.contains(myUid) }
        if (unseen.isEmpty()) return
        try {
            val batch = db.batch()
            unseen.forEach { msg ->
                val ref = db.collection("conversations").document(conversationId)
                    .collection("messages").document(msg.id)
                val updatedSeen = (msg.seenBy + myUid).distinct().take(2)
                batch.update(ref, "seenBy", updatedSeen)
            }
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "conversations/$conversationId/messages")
        }
    }

    fun observeNotifications(uid: String): Flow<List<AppNotification>> {
        if (uid.isBlank()) return kotlinx.coroutines.flow.flowOf(emptyList())
        val path = "notifications"
        return db.collection(path)
            .whereIn("recipientUid", listOf(uid, "all"))
            .snapshots()
            .map { snap ->
                snap.documents.mapNotNull { doc ->
                    doc.toObject(
                        AppNotification::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }.sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                val firestoreErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreErr == null && error is CancellationException) throw error
                handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    suspend fun createNotification(
        recipientUid: String,
        title: String,
        body: String,
        category: String,
        referenceId: String = ""
    ): Result<Unit> = try {
        requireUserId()
        val data = buildMap<String, Any> {
            put("organizationId", AppConfig.ORGANIZATION_ID)
            put("recipientUid", recipientUid)
            put("title", title.trim().take(160))
            put("body", body.trim().take(800))
            put("category", category)
            if (referenceId.isNotBlank()) put("referenceId", referenceId)
            put("read", false)
            put("createdAt", FieldValue.serverTimestamp())
        }
        db.collection("notifications").add(data).await()
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.CREATE, "notifications")
        Result.failure(e)
    }

    suspend fun markNotificationRead(notificationId: String): Result<Unit> = try {
        requireUserId()
        db.collection("notifications").document(notificationId)
            .update("read", true)
            .await()
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.UPDATE, "notifications/$notificationId")
        Result.failure(e)
    }
}
