package com.example.data.repository

import android.content.Context
import android.util.Log
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import com.example.R
import com.example.core.AppConfig
import com.example.core.OperationType
import com.example.core.handleFirestoreError
import com.example.data.model.UserProfile
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class AuthRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {

    fun currentUidOrNull(): String? = auth.currentUser?.uid?.takeIf { it.isNotBlank() }

    private fun requireUserId(): String =
        currentUidOrNull() ?: throw IllegalStateException("অনুগ্রহ করে প্রথমে লগইন করুন।")

    fun observeAuthState(): Flow<FirebaseUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            trySend(firebaseAuth.currentUser)
        }
        auth.addAuthStateListener(listener)
        trySend(auth.currentUser)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    fun observeUserProfile(uid: String): Flow<UserProfile?> {
        if (uid.isBlank()) return kotlinx.coroutines.flow.flowOf(null)
        val path = "users/$uid"
        return db.collection("users").document(uid)
            .snapshots()
            .map { snapshot ->
                if (!snapshot.exists()) null
                else snapshot.toObject(
                    UserProfile::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }
            .catch { error ->
                val firestoreErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreErr == null && error is CancellationException) throw error
                handleFirestoreError(error, OperationType.GET, path)
                emit(null)
            }
    }

    fun observeAllUsers(): Flow<List<UserProfile>> {
        val path = "users"
        return db.collection(path)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .snapshots()
            .map { snap ->
                snap.documents.mapNotNull { doc ->
                    doc.toObject(
                        UserProfile::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
            }
            .catch { error ->
                val firestoreErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreErr == null && error is CancellationException) throw error
                handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    suspend fun signInWithEmail(email: String, password: String): Result<FirebaseUser> {
        return try {
            val result = auth.signInWithEmailAndPassword(email.trim(), password).await()
            val user = result.user ?: return Result.failure(IllegalStateException("ব্যবহারকারী পাওয়া যায়নি।"))
            ensureUserProfileExists(user)
            Result.success(user)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun registerWithEmail(
        name: String,
        email: String,
        password: String,
        phone: String,
        photoUrl: String,
        bloodGroup: String
    ): Result<FirebaseUser> {
        return try {
            val result = auth.createUserWithEmailAndPassword(email.trim(), password).await()
            val user = result.user ?: return Result.failure(IllegalStateException("নিবন্ধন সম্পন্ন হয়নি।"))

            val profileUpdates = UserProfileChangeRequest.Builder()
                .setDisplayName(name.trim())
                .build()
            runCatching { user.updateProfile(profileUpdates).await() }

            val role = if (user.uid == AppConfig.SUPER_ADMIN_UID) "super_admin" else "member"
            val userMap = buildMap<String, Any> {
                put("uid", user.uid)
                put("name", name.trim())
                put("email", email.trim())
                if (phone.isNotBlank()) put("phone", phone.trim())
                if (photoUrl.startsWith("https://")) put("photoUrl", photoUrl.trim())
                if (bloodGroup.isNotBlank()) put("bloodGroup", bloodGroup.trim())
                put("organizationId", AppConfig.ORGANIZATION_ID)
                put("role", role)
                put("permissions", emptyList<String>())
                put("status", "active")
                put("createdAt", FieldValue.serverTimestamp())
                put("updatedAt", FieldValue.serverTimestamp())
            }
            db.collection("users").document(user.uid).set(userMap).await()
            Result.success(user)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "users")
            Result.failure(e)
        }
    }

    suspend fun signInWithGoogle(activityContext: Context): Result<FirebaseUser> {
        return try {
            val webClientId = activityContext.getString(R.string.default_web_client_id)
            val option = GetSignInWithGoogleOption.Builder(webClientId).build()
            val request = GetCredentialRequest.Builder()
                .addCredentialOption(option)
                .build()
            val credentialManager = CredentialManager.create(activityContext)
            val response = credentialManager.getCredential(activityContext, request)
            val cred = response.credential
            if (cred is CustomCredential &&
                cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
            ) {
                val googleCred = GoogleIdTokenCredential.createFrom(cred.data)
                val firebaseCred = GoogleAuthProvider.getCredential(googleCred.idToken, null)
                val authResult = auth.signInWithCredential(firebaseCred).await()
                val user = authResult.user
                    ?: return Result.failure(IllegalStateException("Google লগইন সম্পন্ন হয়নি।"))
                ensureUserProfileExists(user)
                Result.success(user)
            } else {
                Result.failure(IllegalStateException("অসমর্থিত Google ক্রেডেনশিয়াল।"))
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w("Auth", "Google sign-in cancelled by user", e)
            Result.failure(e)
        } catch (e: GetCredentialException) {
            Log.e("Auth", "Credential Manager error", e)
            Result.failure(e)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun ensureUserProfileExists(user: FirebaseUser) {
        val docRef = db.collection("users").document(user.uid)
        try {
            val snap = docRef.get().await()
            if (!snap.exists()) {
                val role = if (user.uid == AppConfig.SUPER_ADMIN_UID) "super_admin" else "member"
                val displayName = user.displayName?.takeIf { it.isNotBlank() }
                    ?: user.email?.substringBefore("@")
                    ?: "Member"
                val userMap = buildMap<String, Any> {
                    put("uid", user.uid)
                    put("name", displayName.take(120))
                    put("email", user.email ?: "user@anvex.org")
                    val photo = user.photoUrl?.toString().orEmpty()
                    if (photo.startsWith("https://")) put("photoUrl", photo)
                    put("organizationId", AppConfig.ORGANIZATION_ID)
                    put("role", role)
                    put("permissions", emptyList<String>())
                    put("status", "active")
                    put("createdAt", FieldValue.serverTimestamp())
                    put("updatedAt", FieldValue.serverTimestamp())
                }
                docRef.set(userMap).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "users/${user.uid}")
        }
    }

    suspend fun updateOwnProfile(
        name: String,
        phone: String,
        photoUrl: String,
        bloodGroup: String,
        address: String
    ): Result<Unit> {
        return try {
            val uid = requireUserId()
            val updates = buildMap<String, Any> {
                put("name", name.trim())
                put("phone", phone.trim())
                if (photoUrl.isBlank() || photoUrl.startsWith("https://")) {
                    put("photoUrl", photoUrl.trim())
                }
                put("bloodGroup", bloodGroup.trim())
                put("address", address.trim())
                put("updatedAt", FieldValue.serverTimestamp())
            }
            db.collection("users").document(uid).update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users/${currentUidOrNull()}")
            Result.failure(e)
        }
    }

    suspend fun updateUserRoleAndPermissions(
        targetUid: String,
        role: String,
        permissions: List<String>,
        status: String
    ): Result<Unit> {
        return try {
            requireUserId()
            val safeRole = if (targetUid == AppConfig.SUPER_ADMIN_UID) "super_admin" else role
            val updates = mapOf(
                "role" to safeRole,
                "permissions" to permissions.distinct(),
                "status" to status,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("users").document(targetUid).update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users/$targetUid")
            Result.failure(e)
        }
    }

    suspend fun signOut() {
        withContext(NonCancellable) {
            auth.signOut()
        }
    }
}
