package com.example.data.repository

import com.example.core.AppConfig
import com.example.core.OperationType
import com.example.core.handleFirestoreError
import com.example.data.model.BloodRequest
import com.example.data.model.MedicalCase
import com.example.data.model.MemberItem
import com.example.data.model.ServiceRequest
import com.example.data.model.VolunteerItem
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class PeopleAndBloodRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    private fun requireUserId(): String =
        auth.currentUser?.uid?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("অনুগ্রহ করে প্রথমে লগইন করুন।")

    fun observeMembers(): Flow<List<MemberItem>> {
        val path = "members"
        return db.collection(path)
            .whereEqualTo("organizationId", AppConfig.ORGANIZATION_ID)
            .snapshots()
            .map { snap ->
                snap.documents.mapNotNull { doc ->
                    doc.toObject(
                        MemberItem::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }.sortedBy { it.name.lowercase() }
            }
            .catch { error ->
                val firestoreErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreErr == null && error is CancellationException) throw error
                handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    fun observeVolunteers(): Flow<List<VolunteerItem>> {
        val path = "volunteers"
        return db.collection(path)
            .whereEqualTo("organizationId", AppConfig.ORGANIZATION_ID)
            .snapshots()
            .map { snap ->
                snap.documents.mapNotNull { doc ->
                    doc.toObject(
                        VolunteerItem::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }.sortedBy { it.name.lowercase() }
            }
            .catch { error ->
                val firestoreErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreErr == null && error is CancellationException) throw error
                handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    fun observeBloodRequests(): Flow<List<BloodRequest>> {
        val path = "bloodRequests"
        return db.collection(path)
            .whereEqualTo("organizationId", AppConfig.ORGANIZATION_ID)
            .snapshots()
            .map { snap ->
                snap.documents.mapNotNull { doc ->
                    doc.toObject(
                        BloodRequest::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }.sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                val firestoreErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreErr == null && error is CancellationException) throw error
                handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    fun observeServiceRequests(uid: String, isAdmin: Boolean): Flow<List<ServiceRequest>> {
        val path = "serviceRequests"
        val query = if (isAdmin) {
            db.collection(path).whereEqualTo("organizationId", AppConfig.ORGANIZATION_ID)
        } else {
            db.collection(path).whereEqualTo("requesterUid", uid)
        }
        return query.snapshots()
            .map { snap ->
                snap.documents.mapNotNull { doc ->
                    doc.toObject(
                        ServiceRequest::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }.sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                val firestoreErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreErr == null && error is CancellationException) throw error
                handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    fun observeMedicalCases(uid: String, isAdmin: Boolean): Flow<List<MedicalCase>> {
        val path = "medicalCases"
        val query = if (isAdmin) {
            db.collection(path).whereEqualTo("organizationId", AppConfig.ORGANIZATION_ID)
        } else {
            db.collection(path).whereEqualTo("createdBy", uid)
        }
        return query.snapshots()
            .map { snap ->
                snap.documents.mapNotNull { doc ->
                    doc.toObject(
                        MedicalCase::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }.sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                val firestoreErr = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreErr == null && error is CancellationException) throw error
                handleFirestoreError(error, OperationType.LIST, path)
                throw error
            }
    }

    suspend fun saveMember(item: MemberItem): Result<Unit> = try {
        requireUserId()
        if (item.id.isBlank()) {
            db.collection("members").add(item.toCreateMap()).await()
        } else {
            val updates = buildMap<String, Any> {
                put("name", item.name.trim())
                if (item.photoUrl.isBlank() || item.photoUrl.startsWith("https://")) {
                    put("photoUrl", item.photoUrl.trim())
                }
                put("phone", item.phone.trim())
                put("email", item.email.trim())
                put("bloodGroup", item.bloodGroup.trim())
                put("position", item.position.trim())
                put("joiningDate", item.joiningDate.trim())
                put("address", item.address.trim())
                put("status", item.status)
                put("bloodDonor", item.bloodDonor)
                put("donationCount", item.donationCount.coerceAtLeast(0))
                put("lastDonationDate", item.lastDonationDate.trim())
                put("donorAvailable", item.donorAvailable)
                put("updatedAt", FieldValue.serverTimestamp())
            }
            db.collection("members").document(item.id).update(updates).await()
        }
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.WRITE, "members")
        Result.failure(e)
    }

    suspend fun toggleMemberStatus(memberId: String, newStatus: String): Result<Unit> = try {
        requireUserId()
        db.collection("members").document(memberId).update(
            mapOf("status" to newStatus, "updatedAt" to FieldValue.serverTimestamp())
        ).await()
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.UPDATE, "members/$memberId")
        Result.failure(e)
    }

    suspend fun deleteMember(memberId: String): Result<Unit> = try {
        requireUserId()
        db.collection("members").document(memberId).delete().await()
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.DELETE, "members/$memberId")
        Result.failure(e)
    }

    suspend fun saveVolunteer(item: VolunteerItem): Result<Unit> = try {
        val uid = requireUserId()
        if (item.id.isBlank()) {
            val payload = if (item.userId.isBlank()) item.copy(userId = uid) else item
            db.collection("volunteers").add(payload.toCreateMap()).await()
        } else {
            val updates = buildMap<String, Any> {
                put("name", item.name.trim())
                if (item.photoUrl.isBlank() || item.photoUrl.startsWith("https://")) {
                    put("photoUrl", item.photoUrl.trim())
                }
                put("phone", item.phone.trim())
                put("skills", item.skills.trim())
                put("availability", item.availability.trim())
                put("bloodGroup", item.bloodGroup.trim())
                put("joiningDate", item.joiningDate.trim())
                put("status", item.status)
                put("updatedAt", FieldValue.serverTimestamp())
            }
            db.collection("volunteers").document(item.id).update(updates).await()
        }
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.WRITE, "volunteers")
        Result.failure(e)
    }

    suspend fun toggleVolunteerStatus(volunteerId: String, newStatus: String): Result<Unit> = try {
        requireUserId()
        db.collection("volunteers").document(volunteerId).update(
            mapOf("status" to newStatus, "updatedAt" to FieldValue.serverTimestamp())
        ).await()
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.UPDATE, "volunteers/$volunteerId")
        Result.failure(e)
    }

    suspend fun deleteVolunteer(volunteerId: String): Result<Unit> = try {
        requireUserId()
        db.collection("volunteers").document(volunteerId).delete().await()
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.DELETE, "volunteers/$volunteerId")
        Result.failure(e)
    }

    suspend fun createBloodRequest(item: BloodRequest): Result<String> = try {
        val uid = requireUserId()
        val ref = db.collection("bloodRequests").add(item.copy(createdBy = uid).toCreateMap()).await()
        Result.success(ref.id)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.CREATE, "bloodRequests")
        Result.failure(e)
    }

    suspend fun updateBloodRequestStatus(requestId: String, status: String): Result<Unit> = try {
        requireUserId()
        db.collection("bloodRequests").document(requestId).update(
            mapOf("status" to status, "updatedAt" to FieldValue.serverTimestamp())
        ).await()
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.UPDATE, "bloodRequests/$requestId")
        Result.failure(e)
    }

    suspend fun deleteBloodRequest(requestId: String): Result<Unit> = try {
        requireUserId()
        db.collection("bloodRequests").document(requestId).delete().await()
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.DELETE, "bloodRequests/$requestId")
        Result.failure(e)
    }

    suspend fun submitServiceRequest(item: ServiceRequest): Result<String> = try {
        val uid = requireUserId()
        val ref = db.collection("serviceRequests").add(item.copy(requesterUid = uid).toCreateMap()).await()
        Result.success(ref.id)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.CREATE, "serviceRequests")
        Result.failure(e)
    }

    suspend fun updateServiceRequestStatus(
        requestId: String,
        status: String,
        adminNote: String
    ): Result<Unit> = try {
        requireUserId()
        val updates = buildMap<String, Any> {
            put("status", status)
            if (adminNote.isNotBlank()) put("adminNote", adminNote.trim())
            put("updatedAt", FieldValue.serverTimestamp())
        }
        db.collection("serviceRequests").document(requestId).update(updates).await()
        Result.success(Unit)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.UPDATE, "serviceRequests/$requestId")
        Result.failure(e)
    }

    suspend fun submitMedicalCase(item: MedicalCase): Result<String> = try {
        val uid = requireUserId()
        val ref = db.collection("medicalCases").add(item.copy(createdBy = uid).toCreateMap()).await()
        Result.success(ref.id)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        handleFirestoreError(e, OperationType.CREATE, "medicalCases")
        Result.failure(e)
    }
}
