package com.example.data.model

import androidx.annotation.Keep
import com.example.core.AppConfig
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties

@Keep
@IgnoreExtraProperties
data class OrganizationInfo(
    @DocumentId val id: String = "",
    val name: String = AppConfig.ORG_NAME,
    val orgTypeBn: String = AppConfig.ORG_TYPE_BN,
    val taglineBn: String = AppConfig.TAGLINE_BN,
    val taglineEn: String = AppConfig.TAGLINE_EN,
    val description: String = "",
    val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val phone: String = "",
    val photoUrl: String = "",
    val bloodGroup: String = "",
    val address: String = "",
    val organizationId: String = AppConfig.ORGANIZATION_ID,
    val role: String = "member",
    val permissions: List<String> = emptyList(),
    val status: String = "active",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    val isSuperAdmin: Boolean
        get() = uid == AppConfig.SUPER_ADMIN_UID || role == "super_admin"

    val isAdmin: Boolean
        get() = isSuperAdmin || (role == "admin" && status == "active")

    fun hasPermission(perm: String): Boolean =
        isSuperAdmin || (isAdmin && permissions.contains(perm))
}

@Keep
@IgnoreExtraProperties
data class PositionItem(
    @DocumentId val id: String = "",
    val organizationId: String = AppConfig.ORGANIZATION_ID,
    val title: String = "",
    val titleBn: String = "",
    val rank: Int = 0,
    val description: String = "",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = buildMap {
        put("organizationId", organizationId)
        put("title", title.trim())
        put("titleBn", titleBn.trim())
        put("rank", rank)
        if (description.isNotBlank()) put("description", description.trim())
        put("createdAt", FieldValue.serverTimestamp())
        put("updatedAt", FieldValue.serverTimestamp())
    }
}

@Keep
@IgnoreExtraProperties
data class MemberItem(
    @DocumentId val id: String = "",
    val organizationId: String = AppConfig.ORGANIZATION_ID,
    val userId: String = "",
    val name: String = "",
    val photoUrl: String = "",
    val phone: String = "",
    val email: String = "",
    val bloodGroup: String = "",
    val position: String = "",
    val joiningDate: String = "",
    val address: String = "",
    val status: String = "active",
    val bloodDonor: Boolean = false,
    val donationCount: Int = 0,
    val lastDonationDate: String = "",
    val donorAvailable: Boolean = true,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = buildMap {
        put("organizationId", organizationId)
        if (userId.isNotBlank()) put("userId", userId)
        put("name", name.trim())
        if (photoUrl.isNotBlank()) put("photoUrl", photoUrl.trim())
        put("phone", phone.trim())
        if (email.isNotBlank()) put("email", email.trim())
        put("bloodGroup", bloodGroup.trim())
        put("position", position.trim())
        if (joiningDate.isNotBlank()) put("joiningDate", joiningDate.trim())
        if (address.isNotBlank()) put("address", address.trim())
        put("status", status)
        put("bloodDonor", bloodDonor)
        put("donationCount", donationCount.coerceAtLeast(0))
        if (lastDonationDate.isNotBlank()) put("lastDonationDate", lastDonationDate.trim())
        put("donorAvailable", donorAvailable)
        put("createdAt", FieldValue.serverTimestamp())
        put("updatedAt", FieldValue.serverTimestamp())
    }
}

@Keep
@IgnoreExtraProperties
data class VolunteerItem(
    @DocumentId val id: String = "",
    val organizationId: String = AppConfig.ORGANIZATION_ID,
    val userId: String = "",
    val name: String = "",
    val photoUrl: String = "",
    val phone: String = "",
    val skills: String = "",
    val availability: String = "",
    val bloodGroup: String = "",
    val joiningDate: String = "",
    val status: String = "active",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = buildMap {
        put("organizationId", organizationId)
        if (userId.isNotBlank()) put("userId", userId)
        put("name", name.trim())
        if (photoUrl.isNotBlank()) put("photoUrl", photoUrl.trim())
        put("phone", phone.trim())
        put("skills", skills.trim())
        put("availability", availability.trim())
        put("bloodGroup", bloodGroup.trim())
        if (joiningDate.isNotBlank()) put("joiningDate", joiningDate.trim())
        put("status", status)
        put("createdAt", FieldValue.serverTimestamp())
        put("updatedAt", FieldValue.serverTimestamp())
    }
}

@Keep
@IgnoreExtraProperties
data class ServiceCategory(
    @DocumentId val id: String = "",
    val organizationId: String = AppConfig.ORGANIZATION_ID,
    val title: String = "",
    val titleBn: String = "",
    val description: String = "",
    val iconKey: String = "volunteer",
    val active: Boolean = true,
    val sortOrder: Int = 0,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = buildMap {
        put("organizationId", organizationId)
        put("title", title.trim())
        put("titleBn", titleBn.trim())
        put("description", description.trim())
        put("iconKey", iconKey.trim().ifBlank { "volunteer" })
        put("active", active)
        put("sortOrder", sortOrder)
        put("createdAt", FieldValue.serverTimestamp())
        put("updatedAt", FieldValue.serverTimestamp())
    }
}

@Keep
@IgnoreExtraProperties
data class ServiceRequest(
    @DocumentId val id: String = "",
    val organizationId: String = AppConfig.ORGANIZATION_ID,
    val serviceId: String = "",
    val serviceTitle: String = "",
    val requesterUid: String = "",
    val requesterName: String = "",
    val requesterPhone: String = "",
    val location: String = "",
    val details: String = "",
    val urgency: String = "normal",
    val status: String = "pending",
    val adminNote: String = "",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = buildMap {
        put("organizationId", organizationId)
        put("serviceId", serviceId)
        put("serviceTitle", serviceTitle.trim())
        put("requesterUid", requesterUid)
        put("requesterName", requesterName.trim())
        put("requesterPhone", requesterPhone.trim())
        put("location", location.trim())
        put("details", details.trim())
        put("urgency", urgency)
        put("status", "pending")
        if (adminNote.isNotBlank()) put("adminNote", adminNote.trim())
        put("createdAt", FieldValue.serverTimestamp())
        put("updatedAt", FieldValue.serverTimestamp())
    }
}

@Keep
@IgnoreExtraProperties
data class BloodRequest(
    @DocumentId val id: String = "",
    val organizationId: String = AppConfig.ORGANIZATION_ID,
    val createdBy: String = "",
    val patientName: String = "",
    val bloodGroup: String = "",
    val hospital: String = "",
    val location: String = "",
    val requiredDate: String = "",
    val units: Int = 1,
    val contact: String = "",
    val urgency: String = "urgent",
    val status: String = "open",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = buildMap {
        put("organizationId", organizationId)
        put("createdBy", createdBy)
        put("patientName", patientName.trim())
        put("bloodGroup", bloodGroup.trim())
        put("hospital", hospital.trim())
        put("location", location.trim())
        put("requiredDate", requiredDate.trim())
        put("units", units.coerceIn(1, 20))
        put("contact", contact.trim())
        put("urgency", urgency)
        put("status", "open")
        put("createdAt", FieldValue.serverTimestamp())
        put("updatedAt", FieldValue.serverTimestamp())
    }
}

@Keep
@IgnoreExtraProperties
data class MedicalCase(
    @DocumentId val id: String = "",
    val organizationId: String = AppConfig.ORGANIZATION_ID,
    val createdBy: String = "",
    val patientName: String = "",
    val conditionSummary: String = "",
    val hospital: String = "",
    val estimatedCost: Double = 0.0,
    val contact: String = "",
    val status: String = "pending",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = buildMap {
        put("organizationId", organizationId)
        put("createdBy", createdBy)
        put("patientName", patientName.trim())
        put("conditionSummary", conditionSummary.trim())
        put("hospital", hospital.trim())
        put("estimatedCost", estimatedCost.coerceAtLeast(0.0))
        put("contact", contact.trim())
        put("status", "pending")
        put("createdAt", FieldValue.serverTimestamp())
        put("updatedAt", FieldValue.serverTimestamp())
    }
}

@Keep
@IgnoreExtraProperties
data class ActivityItem(
    @DocumentId val id: String = "",
    val organizationId: String = AppConfig.ORGANIZATION_ID,
    val title: String = "",
    val description: String = "",
    val category: String = "",
    val imageUrl: String = "",
    val dateText: String = "",
    val location: String = "",
    val participantsCount: Int = 0,
    val beneficiariesCount: Int = 0,
    val budget: Double = 0.0,
    val status: String = "ongoing",
    val createdBy: String = "",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = buildMap {
        put("organizationId", organizationId)
        put("title", title.trim())
        put("description", description.trim())
        put("category", category.trim())
        if (imageUrl.isNotBlank()) put("imageUrl", imageUrl.trim())
        put("dateText", dateText.trim())
        put("location", location.trim())
        put("participantsCount", participantsCount.coerceAtLeast(0))
        put("beneficiariesCount", beneficiariesCount.coerceAtLeast(0))
        put("budget", budget.coerceAtLeast(0.0))
        put("status", status)
        put("createdBy", createdBy)
        put("createdAt", FieldValue.serverTimestamp())
        put("updatedAt", FieldValue.serverTimestamp())
    }
}

@Keep
@IgnoreExtraProperties
data class ContributionRecord(
    @DocumentId val id: String = "",
    val organizationId: String = AppConfig.ORGANIZATION_ID,
    val memberUid: String = "",
    val memberName: String = "",
    val expectedAmount: Double = 0.0,
    val paidAmount: Double = 0.0,
    val dueAmount: Double = 0.0,
    val month: String = "",
    val paymentDate: String = "",
    val paymentMethod: String = "",
    val notes: String = "",
    val recordedBy: String = "",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = buildMap {
        put("organizationId", organizationId)
        if (memberUid.isNotBlank()) put("memberUid", memberUid)
        put("memberName", memberName.trim())
        put("expectedAmount", expectedAmount.coerceAtLeast(0.0))
        put("paidAmount", paidAmount.coerceAtLeast(0.0))
        put("dueAmount", dueAmount.coerceAtLeast(0.0))
        put("month", month.trim())
        put("paymentDate", paymentDate.trim())
        put("paymentMethod", paymentMethod.trim())
        if (notes.isNotBlank()) put("notes", notes.trim())
        put("recordedBy", recordedBy)
        put("createdAt", FieldValue.serverTimestamp())
        put("updatedAt", FieldValue.serverTimestamp())
    }
}

@Keep
@IgnoreExtraProperties
data class DonationRecord(
    @DocumentId val id: String = "",
    val organizationId: String = AppConfig.ORGANIZATION_ID,
    val donorName: String = "",
    val amount: Double = 0.0,
    val purpose: String = "",
    val paymentMethod: String = "",
    val donationDate: String = "",
    val notes: String = "",
    val recordedBy: String = "",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = buildMap {
        put("organizationId", organizationId)
        put("donorName", donorName.trim())
        put("amount", amount.coerceAtLeast(0.01))
        put("purpose", purpose.trim())
        put("paymentMethod", paymentMethod.trim())
        put("donationDate", donationDate.trim())
        if (notes.isNotBlank()) put("notes", notes.trim())
        put("recordedBy", recordedBy)
        put("createdAt", FieldValue.serverTimestamp())
        put("updatedAt", FieldValue.serverTimestamp())
    }
}

@Keep
@IgnoreExtraProperties
data class ExpenseRecord(
    @DocumentId val id: String = "",
    val organizationId: String = AppConfig.ORGANIZATION_ID,
    val title: String = "",
    val category: String = "",
    val amount: Double = 0.0,
    val expenseDate: String = "",
    val receiptUrl: String = "",
    val notes: String = "",
    val recordedBy: String = "",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = buildMap {
        put("organizationId", organizationId)
        put("title", title.trim())
        put("category", category.trim())
        put("amount", amount.coerceAtLeast(0.01))
        put("expenseDate", expenseDate.trim())
        if (receiptUrl.isNotBlank()) put("receiptUrl", receiptUrl.trim())
        if (notes.isNotBlank()) put("notes", notes.trim())
        put("recordedBy", recordedBy)
        put("createdAt", FieldValue.serverTimestamp())
        put("updatedAt", FieldValue.serverTimestamp())
    }
}

data class FinancialSummary(
    val totalContributions: Double = 0.0,
    val totalDonations: Double = 0.0,
    val totalExpenses: Double = 0.0
) {
    val currentBalance: Double
        get() = totalContributions + totalDonations - totalExpenses
}

@Keep
@IgnoreExtraProperties
data class NoticeItem(
    @DocumentId val id: String = "",
    val organizationId: String = AppConfig.ORGANIZATION_ID,
    val title: String = "",
    val body: String = "",
    val type: String = "notice",
    val eventDate: String = "",
    val location: String = "",
    val createdBy: String = "",
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = buildMap {
        put("organizationId", organizationId)
        put("title", title.trim())
        put("body", body.trim())
        put("type", type)
        if (eventDate.isNotBlank()) put("eventDate", eventDate.trim())
        if (location.isNotBlank()) put("location", location.trim())
        put("createdBy", createdBy)
        put("createdAt", FieldValue.serverTimestamp())
        put("updatedAt", FieldValue.serverTimestamp())
    }
}

@Keep
@IgnoreExtraProperties
data class ConversationItem(
    @DocumentId val id: String = "",
    val organizationId: String = AppConfig.ORGANIZATION_ID,
    val participantUids: List<String> = emptyList(),
    val participantNames: Map<String, String> = emptyMap(),
    val participantPhotos: Map<String, String> = emptyMap(),
    val lastMessage: String = "",
    val lastSenderUid: String = "",
    val lastMessageAt: Timestamp? = null,
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class ChatMessage(
    @DocumentId val id: String = "",
    val conversationId: String = "",
    val participantUids: List<String> = emptyList(),
    val senderUid: String = "",
    val senderName: String = "",
    val text: String = "",
    val imageUrl: String = "",
    val seenBy: List<String> = emptyList(),
    val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class AppNotification(
    @DocumentId val id: String = "",
    val organizationId: String = AppConfig.ORGANIZATION_ID,
    val recipientUid: String = "",
    val title: String = "",
    val body: String = "",
    val category: String = "announcement",
    val referenceId: String = "",
    val read: Boolean = false,
    val createdAt: Timestamp? = null
)
