package com.example.core

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

object ImageHostingConfig {
    /**
     * External Image Hosting Configuration (NO Firebase Storage).
     * Configure your Cloudinary Cloud Name & Unsigned Upload Preset here (or via BuildConfig/.env)
     * so users can upload compressed images directly from the gallery and receive an HTTPS URL.
     * Note: Unsigned upload presets do NOT require any secret API key inside the APK.
     */
    var cloudinaryCloudName: String = ""
    var cloudinaryUploadPreset: String = ""

    fun isConfigured(): Boolean =
        cloudinaryCloudName.isNotBlank() && cloudinaryUploadPreset.isNotBlank()
}

class ImageUploadHelper(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun compressAndUploadImage(
        uri: Uri,
        cloudNameOverride: String = ImageHostingConfig.cloudinaryCloudName,
        presetOverride: String = ImageHostingConfig.cloudinaryUploadPreset
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val cloudName = cloudNameOverride.trim()
            val preset = presetOverride.trim()
            if (cloudName.isBlank() || preset.isBlank()) {
                return@withContext Result.failure(
                    IllegalStateException(
                        "এক্সটার্নাল ইমেজ হোস্টিং কনফিগার করা হয়নি। অনুগ্রহ করে সরাসরি HTTPS ছবির লিংক দিন অথবা অ্যাডমিন সেটিংসে Cloudinary Unsigned Preset যোগ করুন।"
                    )
                )
            }

            val compressedBytes = compressUriToJpeg(uri)
                ?: return@withContext Result.failure(IllegalStateException("ছবিটি প্রসেস করা যায়নি।"))

            val uploadUrl = "https://api.cloudinary.com/v1_1/$cloudName/image/upload"
            val requestBody = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("upload_preset", preset)
                .addFormDataPart(
                    "file",
                    "upload_${System.currentTimeMillis()}.jpg",
                    compressedBytes.toRequestBody("image/jpeg".toMediaType())
                )
                .build()

            val request = Request.Builder()
                .url(uploadUrl)
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(
                        IllegalStateException("ছবি আপলোড ব্যর্থ হয়েছে (${response.code})")
                    )
                }
                val json = JSONObject(bodyStr)
                val secureUrl = json.optString("secure_url")
                if (secureUrl.startsWith("https://")) {
                    Result.success(secureUrl)
                } else {
                    Result.failure(IllegalStateException("সার্ভার থেকে বৈধ HTTPS লিংক পাওয়া যায়নি।"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun compressUriToJpeg(uri: Uri): ByteArray? {
        val inputStream = context.contentResolver.openInputStream(uri) ?: return null
        val original = inputStream.use { BitmapFactory.decodeStream(it) } ?: return null

        val maxDim = 1080
        val width = original.width
        val height = original.height
        val scale = if (width > maxDim || height > maxDim) {
            minOf(maxDim.toFloat() / width, maxDim.toFloat() / height)
        } else {
            1f
        }

        val targetBitmap = if (scale < 1f) {
            Bitmap.createScaledBitmap(
                original,
                (width * scale).toInt().coerceAtLeast(1),
                (height * scale).toInt().coerceAtLeast(1),
                true
            )
        } else {
            original
        }

        val out = ByteArrayOutputStream()
        targetBitmap.compress(Bitmap.CompressFormat.JPEG, 80, out)
        if (targetBitmap != original) {
            targetBitmap.recycle()
        }
        original.recycle()
        return out.toByteArray()
    }
}
