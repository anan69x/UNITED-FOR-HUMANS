package com.example.core

object AppConfig {
    const val ORGANIZATION_ID = "anvex_united_for_humans"
    const val SUPER_ADMIN_UID = "PhjnBPiB5DNWAjiTdsYtB7oDAq93"
    const val ORG_NAME = "Anvex™"
    const val APP_NAME = "United for Humans"
    const val ORG_TYPE_BN = "বাংলাদেশ সেবামূলক সংগঠন"
    const val TAGLINE_BN = "মানুষের পাশে, মানবতার জন্য"
    const val TAGLINE_EN = "Together for a Better Tomorrow."

    // Granular Admin Permissions
    const val PERM_SERVICES = "manage_services"
    const val PERM_MEMBERS = "manage_members"
    const val PERM_VOLUNTEERS = "manage_volunteers"
    const val PERM_BLOOD = "manage_blood"
    const val PERM_ACTIVITIES = "manage_activities"
    const val PERM_FINANCE = "manage_finance"
    const val PERM_NOTICES = "manage_notices"
    const val PERM_NOTIFICATIONS = "manage_notifications"

    val ALL_PERMISSIONS = listOf(
        PERM_SERVICES to "সেবা বিভাগ ও অনুরোধ পরিচালনা",
        PERM_MEMBERS to "সদস্য ও পদবী পরিচালনা",
        PERM_VOLUNTEERS to "স্বেচ্ছাসেবক পরিচালনা",
        PERM_BLOOD to "রক্তদান ও অনুরোধ পরিচালনা",
        PERM_ACTIVITIES to "মানবিক কার্যক্রম পরিচালনা",
        PERM_FINANCE to "আর্থিক হিসাব ও অনুদান পরিচালনা",
        PERM_NOTICES to "নোটিশ ও ইভেন্ট পরিচালনা",
        PERM_NOTIFICATIONS to "বিজ্ঞপ্তি প্রচার"
    )

    val BLOOD_GROUPS = listOf("A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-")
}
