package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Campaign
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.VolunteerActivism
import androidx.compose.material.icons.outlined.WorkHistory
import androidx.compose.material.icons.rounded.Campaign
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.VolunteerActivism
import androidx.compose.material.icons.rounded.WorkHistory
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.components.GuestThirtySecondNudgeDialog
import com.example.ui.components.HumanitarianTopBar
import com.example.ui.navigation.AppRoutes
import com.example.ui.screens.ActivitiesScreen
import com.example.ui.screens.AdminPanelScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.BloodDonationScreen
import com.example.ui.screens.ChatRoomScreen
import com.example.ui.screens.ConversationsScreen
import com.example.ui.screens.DeveloperAnvexScreen
import com.example.ui.screens.DirectoryScreen
import com.example.ui.screens.FinanceScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.NoticesScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ServicesScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.UnitedForHumansTheme
import com.example.ui.viewmodel.MainViewModel
import com.google.firebase.FirebaseApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        FirebaseApp.initializeApp(this)
        setContent {
            UnitedForHumansTheme {
                UnitedForHumansApp()
            }
        }
    }
}

private data class BottomTabItem(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

@Composable
fun UnitedForHumansApp(
    viewModel: MainViewModel = viewModel()
) {
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }

    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val isSignedIn = currentUser != null

    val servicesState by viewModel.servicesState.collectAsStateWithLifecycle()
    val activitiesState by viewModel.activitiesState.collectAsStateWithLifecycle()
    val noticesState by viewModel.noticesState.collectAsStateWithLifecycle()
    val positionsState by viewModel.positionsState.collectAsStateWithLifecycle()
    val membersState by viewModel.membersState.collectAsStateWithLifecycle()
    val volunteersState by viewModel.volunteersState.collectAsStateWithLifecycle()
    val bloodRequestsState by viewModel.bloodRequestsState.collectAsStateWithLifecycle()
    val serviceRequestsState by viewModel.serviceRequestsState.collectAsStateWithLifecycle()
    val contributionsState by viewModel.contributionsState.collectAsStateWithLifecycle()
    val donationsState by viewModel.donationsState.collectAsStateWithLifecycle()
    val expensesState by viewModel.expensesState.collectAsStateWithLifecycle()
    val financialSummary by viewModel.financialSummary.collectAsStateWithLifecycle()
    val conversationsState by viewModel.conversationsState.collectAsStateWithLifecycle()
    val notificationsState by viewModel.notificationsState.collectAsStateWithLifecycle()
    val unreadNotifCount by viewModel.unreadNotificationsCount.collectAsStateWithLifecycle()

    val authBusy by viewModel.authBusy.collectAsStateWithLifecycle()
    val authError by viewModel.authError.collectAsStateWithLifecycle()
    val showGuestNudge by viewModel.showGuestLoginNudge.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        viewModel.toastEvents.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val bottomTabs = remember {
        listOf(
            BottomTabItem(AppRoutes.HOME, "হোম", Icons.Rounded.Home, Icons.Outlined.Home, "nav_home"),
            BottomTabItem(AppRoutes.SERVICES, "সেবাসমূহ", Icons.Rounded.VolunteerActivism, Icons.Outlined.VolunteerActivism, "nav_services"),
            BottomTabItem(AppRoutes.ACTIVITIES, "কার্যক্রম", Icons.Rounded.WorkHistory, Icons.Outlined.WorkHistory, "nav_activities"),
            BottomTabItem(AppRoutes.NOTICES, "নোটিশ", Icons.Rounded.Campaign, Icons.Outlined.Campaign, "nav_notices"),
            BottomTabItem(AppRoutes.PROFILE, "প্রোফাইল", Icons.Rounded.Person, Icons.Outlined.Person, "nav_profile")
        )
    }

    val mainTabRoutes = remember { bottomTabs.map { it.route }.toSet() }
    val showMainChrome = currentRoute in mainTabRoutes

    if (showGuestNudge && !isSignedIn && currentRoute != AppRoutes.AUTH && currentRoute != AppRoutes.SPLASH) {
        GuestThirtySecondNudgeDialog(
            onLoginClick = {
                viewModel.dismissGuestNudge()
                navController.navigate(AppRoutes.AUTH)
            },
            onDismiss = { viewModel.dismissGuestNudge() }
        )
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            if (showMainChrome) {
                HumanitarianTopBar(
                    userProfile = userProfile,
                    isSignedIn = isSignedIn,
                    unreadNotificationCount = unreadNotifCount,
                    onMessagesClick = { navController.navigate(AppRoutes.MESSAGES) },
                    onNotificationsClick = { navController.navigate(AppRoutes.NOTIFICATIONS) },
                    onLoginClick = { navController.navigate(AppRoutes.AUTH) },
                    onProfileClick = {
                        navController.navigate(AppRoutes.PROFILE) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
        },
        bottomBar = {
            if (showMainChrome) {
                NavigationBar(
                    windowInsets = WindowInsets.navigationBars,
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    bottomTabs.forEach { tab ->
                        val selected = currentRoute == tab.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(tab.route) {
                                    popUpTo(AppRoutes.HOME) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                    contentDescription = tab.label
                                )
                            },
                            label = { Text(tab.label) },
                            modifier = Modifier.testTag(tab.testTag)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            NavHost(
                navController = navController,
                startDestination = AppRoutes.SPLASH,
                enterTransition = {
                    fadeIn(tween(260)) + slideInHorizontally(initialOffsetX = { it / 12 }, animationSpec = tween(260))
                },
                exitTransition = {
                    fadeOut(tween(220)) + slideOutHorizontally(targetOffsetX = { -it / 16 }, animationSpec = tween(220))
                },
                popEnterTransition = {
                    fadeIn(tween(260)) + slideInHorizontally(initialOffsetX = { -it / 12 }, animationSpec = tween(260))
                },
                popExitTransition = {
                    fadeOut(tween(220)) + slideOutHorizontally(targetOffsetX = { it / 16 }, animationSpec = tween(220))
                }
            ) {
                composable(AppRoutes.SPLASH) {
                    SplashScreen(
                        onFinished = {
                            navController.navigate(AppRoutes.HOME) {
                                popUpTo(AppRoutes.SPLASH) { inclusive = true }
                            }
                            viewModel.startGuestThirtySecondTimer()
                        }
                    )
                }

                composable(AppRoutes.HOME) {
                    HomeScreen(
                        isSignedIn = isSignedIn,
                        servicesState = servicesState,
                        activitiesState = activitiesState,
                        noticesState = noticesState,
                        membersState = membersState,
                        volunteersState = volunteersState,
                        bloodRequestsState = bloodRequestsState,
                        onOpenBlood = { navController.navigate(AppRoutes.BLOOD) },
                        onOpenDirectory = { navController.navigate(AppRoutes.DIRECTORY) },
                        onOpenFinance = { navController.navigate(AppRoutes.FINANCE) },
                        onOpenMessages = { navController.navigate(AppRoutes.MESSAGES) },
                        onOpenServices = { navController.navigate(AppRoutes.SERVICES) },
                        onOpenActivities = { navController.navigate(AppRoutes.ACTIVITIES) },
                        onOpenNotices = { navController.navigate(AppRoutes.NOTICES) }
                    )
                }

                composable(AppRoutes.SERVICES) {
                    ServicesScreen(
                        isSignedIn = isSignedIn,
                        userProfile = userProfile,
                        servicesState = servicesState,
                        serviceRequestsState = serviceRequestsState,
                        onRequireLogin = { navController.navigate(AppRoutes.AUTH) },
                        onSubmitServiceRequest = { req, done -> viewModel.submitServiceRequest(req, done) }
                    )
                }

                composable(AppRoutes.ACTIVITIES) {
                    ActivitiesScreen(activitiesState = activitiesState)
                }

                composable(AppRoutes.NOTICES) {
                    NoticesScreen(noticesState = noticesState)
                }

                composable(AppRoutes.PROFILE) {
                    ProfileScreen(
                        isSignedIn = isSignedIn,
                        userProfile = userProfile,
                        viewModel = viewModel,
                        onOpenLogin = { navController.navigate(AppRoutes.AUTH) },
                        onOpenAdminPanel = { navController.navigate(AppRoutes.ADMIN) },
                        onOpenBlood = { navController.navigate(AppRoutes.BLOOD) },
                        onOpenDirectory = { navController.navigate(AppRoutes.DIRECTORY) },
                        onOpenFinance = { navController.navigate(AppRoutes.FINANCE) },
                        onOpenMessages = { navController.navigate(AppRoutes.MESSAGES) },
                        onOpenDeveloperAnvex = { navController.navigate(AppRoutes.DEVELOPER_ANVEX) },
                        onSignOut = { viewModel.signOut() }
                    )
                }

                composable(AppRoutes.AUTH) {
                    AuthScreen(
                        viewModel = viewModel,
                        isBusy = authBusy,
                        authError = authError,
                        onAuthSuccess = {
                            navController.popBackStack()
                        },
                        onContinueAsGuest = {
                            navController.popBackStack()
                        }
                    )
                }

                composable(AppRoutes.BLOOD) {
                    BloodDonationScreen(
                        isSignedIn = isSignedIn,
                        userProfile = userProfile,
                        membersState = membersState,
                        bloodRequestsState = bloodRequestsState,
                        onBack = { navController.popBackStack() },
                        onRequireLogin = { navController.navigate(AppRoutes.AUTH) },
                        onCreateBloodRequest = { req, done -> viewModel.createBloodRequest(req, done) },
                        onUpdateRequestStatus = { id, status -> viewModel.updateBloodRequestStatus(id, status) }
                    )
                }

                composable(AppRoutes.DIRECTORY) {
                    DirectoryScreen(
                        isSignedIn = isSignedIn,
                        positionsState = positionsState,
                        membersState = membersState,
                        volunteersState = volunteersState,
                        onBack = { navController.popBackStack() },
                        onRequireLogin = { navController.navigate(AppRoutes.AUTH) }
                    )
                }

                composable(AppRoutes.FINANCE) {
                    FinanceScreen(
                        isSignedIn = isSignedIn,
                        summary = financialSummary,
                        contributionsState = contributionsState,
                        donationsState = donationsState,
                        expensesState = expensesState,
                        onBack = { navController.popBackStack() },
                        onRequireLogin = { navController.navigate(AppRoutes.AUTH) }
                    )
                }

                composable(AppRoutes.MESSAGES) {
                    ConversationsScreen(
                        isSignedIn = isSignedIn,
                        currentUid = currentUser?.uid.orEmpty(),
                        conversationsState = conversationsState,
                        membersState = membersState,
                        onBack = { navController.popBackStack() },
                        onRequireLogin = { navController.navigate(AppRoutes.AUTH) },
                        onOpenConversation = { convId -> navController.navigate(AppRoutes.chatRoute(convId)) },
                        onStartConversationWithMember = { member ->
                            viewModel.startConversation(
                                otherUid = member.userId,
                                otherName = member.name,
                                otherPhoto = member.photoUrl
                            ) { convId ->
                                navController.navigate(AppRoutes.chatRoute(convId))
                            }
                        }
                    )
                }

                composable(
                    route = AppRoutes.CHAT,
                    arguments = listOf(navArgument("conversationId") { type = NavType.StringType })
                ) { backStackEntry ->
                    val convId = backStackEntry.arguments?.getString("conversationId").orEmpty()
                    ChatRoomScreen(
                        conversationId = convId,
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(AppRoutes.NOTIFICATIONS) {
                    NotificationsScreen(
                        isSignedIn = isSignedIn,
                        notificationsState = notificationsState,
                        onBack = { navController.popBackStack() },
                        onRequireLogin = { navController.navigate(AppRoutes.AUTH) },
                        onMarkRead = { id -> viewModel.markNotificationRead(id) }
                    )
                }

                composable(AppRoutes.ADMIN) {
                    AdminPanelScreen(
                        viewModel = viewModel,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(AppRoutes.DEVELOPER_ANVEX) {
                    DeveloperAnvexScreen(
                        onBack = { navController.popBackStack() }
                    )
                }
            }
        }
    }
}
