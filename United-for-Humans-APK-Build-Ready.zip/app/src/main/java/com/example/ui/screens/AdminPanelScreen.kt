package com.example.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.Bloodtype
import androidx.compose.material.icons.rounded.Campaign
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.LocalAtm
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Savings
import androidx.compose.material.icons.rounded.VolunteerActivism
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.AppConfig
import com.example.core.UiState
import com.example.data.model.ActivityItem
import com.example.data.model.BloodRequest
import com.example.data.model.MemberItem
import com.example.data.model.ServiceCategory
import com.example.data.model.UserProfile
import com.example.data.model.VolunteerItem
import com.example.ui.components.AnimatedOutlinedActionButton
import com.example.ui.components.EmbossedCard
import com.example.ui.components.EmptyStateBengaliCard
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.EmeraldSecondary
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanelScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val profile by viewModel.userProfile.collectAsStateWithLifecycle()
    val services = (viewModel.servicesState.collectAsStateWithLifecycle().value as? UiState.Success)?.data.orEmpty()
    val serviceRequests = (viewModel.serviceRequestsState.collectAsStateWithLifecycle().value as? UiState.Success)?.data.orEmpty()
    val members = (viewModel.membersState.collectAsStateWithLifecycle().value as? UiState.Success)?.data.orEmpty()
    val volunteers = (viewModel.volunteersState.collectAsStateWithLifecycle().value as? UiState.Success)?.data.orEmpty()
    val activities = (viewModel.activitiesState.collectAsStateWithLifecycle().value as? UiState.Success)?.data.orEmpty()
    val bloodRequests = (viewModel.bloodRequestsState.collectAsStateWithLifecycle().value as? UiState.Success)?.data.orEmpty()
    val notices = (viewModel.noticesState.collectAsStateWithLifecycle().value as? UiState.Success)?.data.orEmpty()
    val positions = (viewModel.positionsState.collectAsStateWithLifecycle().value as? UiState.Success)?.data.orEmpty()
    val contributions = (viewModel.contributionsState.collectAsStateWithLifecycle().value as? UiState.Success)?.data.orEmpty()
    val donations = (viewModel.donationsState.collectAsStateWithLifecycle().value as? UiState.Success)?.data.orEmpty()
    val expenses = (viewModel.expensesState.collectAsStateWithLifecycle().value as? UiState.Success)?.data.orEmpty()
    val summary by viewModel.financialSummary.collectAsStateWithLifecycle()
    val allUsers = (viewModel.allUsersState.collectAsStateWithLifecycle().value as? UiState.Success)?.data.orEmpty()

    var selectedSection by remember { mutableIntStateOf(0) }

    // Dialog states
    var serviceDialogItem by remember { mutableStateOf<ServiceCategory?>(null) }
    var showNewService by remember { mutableStateOf(false) }
    var memberDialogItem by remember { mutableStateOf<MemberItem?>(null) }
    var showNewMember by remember { mutableStateOf(false) }
    var volunteerDialogItem by remember { mutableStateOf<VolunteerItem?>(null) }
    var showNewVolunteer by remember { mutableStateOf(false) }
    var activityDialogItem by remember { mutableStateOf<ActivityItem?>(null) }
    var showNewActivity by remember { mutableStateOf(false) }
    var showNewBloodReq by remember { mutableStateOf(false) }
    var showNewContrib by remember { mutableStateOf(false) }
    var showNewDonation by remember { mutableStateOf(false) }
    var showNewExpense by remember { mutableStateOf(false) }
    var showNewNotice by remember { mutableStateOf(false) }
    var showNewPosition by remember { mutableStateOf(false) }
    var roleDialogUser by remember { mutableStateOf<UserProfile?>(null) }

    if (profile?.isAdmin != true) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("অ্যাডমিন প্যানেল") },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "ফিরে যান")
                        }
                    }
                )
            }
        ) { padding ->
            Box(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                EmptyStateBengaliCard(
                    title = "প্রবেশাধিকার সংরক্ষিত",
                    subtitle = "এই বিভাগটি শুধুমাত্র অনুমোদিত অ্যাডমিন এবং সুপার অ্যাডমিনের জন্য।",
                    icon = Icons.Rounded.AdminPanelSettings
                )
            }
        }
        return
    }

    val isSuperAdmin = profile?.isSuperAdmin == true
    val canServices = profile?.hasPermission(AppConfig.PERM_SERVICES) == true
    val canMembers = profile?.hasPermission(AppConfig.PERM_MEMBERS) == true
    val canVolunteers = profile?.hasPermission(AppConfig.PERM_VOLUNTEERS) == true
    val canBlood = profile?.hasPermission(AppConfig.PERM_BLOOD) == true
    val canActivities = profile?.hasPermission(AppConfig.PERM_ACTIVITIES) == true
    val canFinance = profile?.hasPermission(AppConfig.PERM_FINANCE) == true
    val canNotices = profile?.hasPermission(AppConfig.PERM_NOTICES) == true

    val sections = buildList {
        add(0 to "ড্যাশবোর্ড")
        add(1 to "সেবা")
        add(2 to "সদস্য ও স্বেচ্ছাসেবক")
        add(3 to "কার্যক্রম ও রক্তদান")
        add(4 to "অর্থ ও নোটিশ")
        if (isSuperAdmin) add(5 to "সুপার অ্যাডমিন")
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("অ্যাডমিন ড্যাশবোর্ড")
                        Text(
                            text = if (isSuperAdmin) "সুপার অ্যাডমিন মোড" else "অ্যাডমিন প্যানেল",
                            style = MaterialTheme.typography.bodySmall,
                            color = CrimsonPrimary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "ফিরে যান")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .navigationBarsPadding()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                sections.forEach { (id, label) ->
                    FilterChip(
                        selected = selectedSection == id,
                        onClick = { selectedSection = id },
                        label = { Text(label) }
                    )
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when (selectedSection) {
                    0 -> {
                        // Real Firestore Admin Dashboard Metrics
                        item {
                            EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                Text("রিয়েল-টাইম সংগঠন পরিসংখ্যান", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(10.dp))
                                MetricRow("মোট সদস্য", members.size.toString(), "স্বেচ্ছাসেবক", volunteers.size.toString())
                                MetricRow("সক্রিয় সেবা", services.count { it.active }.toString(), "সম্পন্ন কার্যক্রম", activities.count { it.status == "completed" }.toString())
                                MetricRow("রক্তের অনুরোধ", bloodRequests.size.toString(), "মোট চাঁদা", "৳${summary.totalContributions.toInt()}")
                                MetricRow("মোট অনুদান", "৳${summary.totalDonations.toInt()}", "মোট ব্যয়", "৳${summary.totalExpenses.toInt()}")
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "বর্তমান তহবিল ব্যালেন্স: ৳${summary.currentBalance.toInt()}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldSecondary
                                )
                            }
                        }

                        // 8 Quick Actions
                        item {
                            Text("দ্রুত অ্যাকশনসমূহ", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    AnimatedOutlinedActionButton(
                                        text = "সদস্য যোগ",
                                        icon = Icons.Rounded.Groups,
                                        enabled = canMembers,
                                        onClick = { showNewMember = true },
                                        modifier = Modifier.weight(1f)
                                    )
                                    AnimatedOutlinedActionButton(
                                        text = "স্বেচ্ছাসেবক যোগ",
                                        icon = Icons.Rounded.VolunteerActivism,
                                        enabled = canVolunteers,
                                        onClick = { showNewVolunteer = true },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    AnimatedOutlinedActionButton(
                                        text = "কার্যক্রম যোগ",
                                        icon = Icons.Rounded.Add,
                                        enabled = canActivities,
                                        onClick = { showNewActivity = true },
                                        modifier = Modifier.weight(1f)
                                    )
                                    AnimatedOutlinedActionButton(
                                        text = "রক্তের অনুরোধ",
                                        icon = Icons.Rounded.Bloodtype,
                                        enabled = canBlood,
                                        onClick = { showNewBloodReq = true },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    AnimatedOutlinedActionButton(
                                        text = "চাঁদা পেমেন্ট",
                                        icon = Icons.Rounded.Savings,
                                        enabled = canFinance,
                                        onClick = { showNewContrib = true },
                                        modifier = Modifier.weight(1f)
                                    )
                                    AnimatedOutlinedActionButton(
                                        text = "অনুদান যোগ",
                                        icon = Icons.Rounded.LocalAtm,
                                        enabled = canFinance,
                                        onClick = { showNewDonation = true },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    AnimatedOutlinedActionButton(
                                        text = "ব্যয় যুক্ত",
                                        icon = Icons.Rounded.ReceiptLong,
                                        enabled = canFinance,
                                        onClick = { showNewExpense = true },
                                        modifier = Modifier.weight(1f)
                                    )
                                    AnimatedOutlinedActionButton(
                                        text = "নোটিশ তৈরি",
                                        icon = Icons.Rounded.Campaign,
                                        enabled = canNotices,
                                        onClick = { showNewNotice = true },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }

                    1 -> {
                        // Services & Service Requests Management
                        item {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("সেবা বিভাগসমূহ (${services.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                if (canServices) {
                                    AnimatedOutlinedActionButton(text = "নতুন সেবা", icon = Icons.Rounded.Add, onClick = { showNewService = true })
                                }
                            }
                        }
                        items(services, key = { it.id }) { s ->
                            EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("${s.titleBn} (${s.title})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        Text(s.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    if (canServices) {
                                        IconButton(onClick = { serviceDialogItem = s }) { Icon(Icons.Rounded.Edit, "সম্পাদনা") }
                                        IconButton(onClick = { viewModel.deleteService(s.id) }) { Icon(Icons.Rounded.Delete, "মুছুন", tint = CrimsonPrimary) }
                                    }
                                }
                            }
                        }
                        item {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("সেবার আবেদনসমূহ (${serviceRequests.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        items(serviceRequests, key = { it.id }) { req ->
                            EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                Text("${req.serviceTitle} — ${req.requesterName}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                Text("${req.requesterPhone} • ${req.location}", style = MaterialTheme.typography.bodySmall)
                                Text(req.details, style = MaterialTheme.typography.bodyMedium)
                                if (canServices) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        TextButton(onClick = { viewModel.updateServiceRequestStatus(req, "in_progress", "কার্যক্রম শুরু হয়েছে") }) { Text("চলমান করুন") }
                                        TextButton(onClick = { viewModel.updateServiceRequestStatus(req, "completed", "সহায়তা প্রদান সম্পন্ন হয়েছে") }) { Text("সম্পন্ন করুন") }
                                    }
                                }
                            }
                        }
                    }

                    2 -> {
                        // Members, Positions & Volunteers
                        item {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("পদবীসমূহ (${positions.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                if (canMembers) {
                                    AnimatedOutlinedActionButton(text = "পদবী যোগ", icon = Icons.Rounded.Add, onClick = { showNewPosition = true })
                                }
                            }
                        }
                        items(positions, key = { it.id }) { pos ->
                            EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Text("${pos.rank}. ${pos.titleBn} (${pos.title})", modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                                    if (canMembers) {
                                        IconButton(onClick = { viewModel.deletePosition(pos.id) }) { Icon(Icons.Rounded.Delete, "মুছুন", tint = CrimsonPrimary) }
                                    }
                                }
                            }
                        }
                        item {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("সদস্যবৃন্দ (${members.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                if (canMembers) {
                                    AnimatedOutlinedActionButton(text = "সদস্য যোগ", icon = Icons.Rounded.Add, onClick = { showNewMember = true })
                                }
                            }
                        }
                        items(members, key = { it.id }) { m ->
                            EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("${m.name} (${m.position})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        Text("${m.phone} • ${m.bloodGroup} • ${m.status}", style = MaterialTheme.typography.bodySmall)
                                    }
                                    if (canMembers) {
                                        TextButton(onClick = { viewModel.toggleMemberStatus(m) }) {
                                            Text(if (m.status == "active") "নিষ্ক্রিয়" else "সক্রিয়")
                                        }
                                        IconButton(onClick = { memberDialogItem = m }) { Icon(Icons.Rounded.Edit, "সম্পাদনা") }
                                        IconButton(onClick = { viewModel.deleteMember(m.id) }) { Icon(Icons.Rounded.Delete, "মুছুন", tint = CrimsonPrimary) }
                                    }
                                }
                            }
                        }
                        item {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("স্বেচ্ছাসেবক (${volunteers.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                if (canVolunteers) {
                                    AnimatedOutlinedActionButton(text = "স্বেচ্ছাসেবক যোগ", icon = Icons.Rounded.Add, onClick = { showNewVolunteer = true })
                                }
                            }
                        }
                        items(volunteers, key = { it.id }) { v ->
                            EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(v.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        Text("${v.skills} • ${v.status}", style = MaterialTheme.typography.bodySmall)
                                    }
                                    if (canVolunteers) {
                                        TextButton(onClick = { viewModel.toggleVolunteerStatus(v) }) {
                                            Text(if (v.status == "active") "নিষ্ক্রিয়" else "সক্রিয়")
                                        }
                                        IconButton(onClick = { volunteerDialogItem = v }) { Icon(Icons.Rounded.Edit, "সম্পাদনা") }
                                        IconButton(onClick = { viewModel.deleteVolunteer(v.id) }) { Icon(Icons.Rounded.Delete, "মুছুন", tint = CrimsonPrimary) }
                                    }
                                }
                            }
                        }
                    }

                    3 -> {
                        // Activities & Blood Requests
                        item {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("মানবিক কার্যক্রম (${activities.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                if (canActivities) {
                                    AnimatedOutlinedActionButton(text = "নতুন কার্যক্রম", icon = Icons.Rounded.Add, onClick = { showNewActivity = true })
                                }
                            }
                        }
                        items(activities, key = { it.id }) { a ->
                            EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(a.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        Text("${a.category} • ${a.status} • ${a.dateText}", style = MaterialTheme.typography.bodySmall)
                                    }
                                    if (canActivities) {
                                        IconButton(onClick = { activityDialogItem = a }) { Icon(Icons.Rounded.Edit, "সম্পাদনা") }
                                        IconButton(onClick = { viewModel.deleteActivity(a.id) }) { Icon(Icons.Rounded.Delete, "মুছুন", tint = CrimsonPrimary) }
                                    }
                                }
                            }
                        }
                        item {
                            Text("রক্তের অনুরোধ (${bloodRequests.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        items(bloodRequests, key = { it.id }) { req ->
                            EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("${req.patientName} (${req.bloodGroup})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        Text("${req.hospital} • ${req.status}", style = MaterialTheme.typography.bodySmall)
                                    }
                                    if (canBlood) {
                                        if (req.status == "open") {
                                            TextButton(onClick = { viewModel.updateBloodRequestStatus(req.id, "fulfilled") }) { Text("সম্পন্ন") }
                                        }
                                        IconButton(onClick = { viewModel.deleteBloodRequest(req.id) }) { Icon(Icons.Rounded.Delete, "মুছুন", tint = CrimsonPrimary) }
                                    }
                                }
                            }
                        }
                    }

                    4 -> {
                        // Finance & Notices
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (canFinance) {
                                    AnimatedOutlinedActionButton(text = "চাঁদা", icon = Icons.Rounded.Add, onClick = { showNewContrib = true }, modifier = Modifier.weight(1f))
                                    AnimatedOutlinedActionButton(text = "অনুদান", icon = Icons.Rounded.Add, onClick = { showNewDonation = true }, modifier = Modifier.weight(1f))
                                    AnimatedOutlinedActionButton(text = "ব্যয়", icon = Icons.Rounded.Add, onClick = { showNewExpense = true }, modifier = Modifier.weight(1f))
                                }
                            }
                        }
                        items(contributions, key = { it.id }) { c ->
                            EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("চাঁদা: ${c.memberName} (${c.month})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        Text("জমা: ৳${c.paidAmount.toInt()} • বকেয়া: ৳${c.dueAmount.toInt()}", style = MaterialTheme.typography.bodySmall)
                                    }
                                    if (canFinance) {
                                        IconButton(onClick = { viewModel.deleteFinanceRecord("contributions", c.id) }) {
                                            Icon(Icons.Rounded.Delete, "মুছুন", tint = CrimsonPrimary)
                                        }
                                    }
                                }
                            }
                        }
                        items(donations, key = { it.id }) { d ->
                            EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("অনুদান: ${d.donorName}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        Text("৳${d.amount.toInt()} • ${d.purpose}", style = MaterialTheme.typography.bodySmall)
                                    }
                                    if (canFinance) {
                                        IconButton(onClick = { viewModel.deleteFinanceRecord("donations", d.id) }) {
                                            Icon(Icons.Rounded.Delete, "মুছুন", tint = CrimsonPrimary)
                                        }
                                    }
                                }
                            }
                        }
                        items(expenses, key = { it.id }) { e ->
                            EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("ব্যয়: ${e.title}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        Text("৳${e.amount.toInt()} • ${e.category}", style = MaterialTheme.typography.bodySmall)
                                    }
                                    if (canFinance) {
                                        IconButton(onClick = { viewModel.deleteFinanceRecord("expenses", e.id) }) {
                                            Icon(Icons.Rounded.Delete, "মুছুন", tint = CrimsonPrimary)
                                        }
                                    }
                                }
                            }
                        }
                        item {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("নোটিশ ও ইভেন্ট (${notices.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                if (canNotices) {
                                    AnimatedOutlinedActionButton(text = "নোটিশ তৈরি", icon = Icons.Rounded.Add, onClick = { showNewNotice = true })
                                }
                            }
                        }
                        items(notices, key = { it.id }) { n ->
                            EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(n.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        Text("${n.type} • ${n.body.take(80)}", style = MaterialTheme.typography.bodySmall)
                                    }
                                    if (canNotices) {
                                        IconButton(onClick = { viewModel.deleteNotice(n.id) }) {
                                            Icon(Icons.Rounded.Delete, "মুছুন", tint = CrimsonPrimary)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    5 -> {
                        // Super Admin RBAC Manager
                        item {
                            Text("ব্যবহারকারীর ভূমিকা ও অ্যাডমিন অনুমতি নিয়ন্ত্রণ", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("সুপার অ্যাডমিন হিসেবে আপনি একাধিক অ্যাডমিন নিয়োগ, অপসারণ এবং নির্দিষ্ট অনুমতি প্রদান করতে পারবেন।", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        items(allUsers, key = { it.uid }) { user ->
                            EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(user.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        Text(user.email, style = MaterialTheme.typography.bodySmall)
                                        Text(
                                            text = "ভূমিকা: ${user.role} • অনুমতি: ${user.permissions.size} টি",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = if (user.isAdmin) CrimsonPrimary else EmeraldSecondary
                                        )
                                    }
                                    if (user.uid != AppConfig.SUPER_ADMIN_UID) {
                                        AnimatedOutlinedActionButton(
                                            text = "নিয়ন্ত্রণ",
                                            onClick = { roleDialogUser = user }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Dialog Hosts
    if (showNewService || serviceDialogItem != null) {
        ServiceFormDialog(
            initial = serviceDialogItem,
            onDismiss = { showNewService = false; serviceDialogItem = null },
            onSave = { item ->
                viewModel.saveService(item) { showNewService = false; serviceDialogItem = null }
            }
        )
    }

    if (showNewMember || memberDialogItem != null) {
        MemberFormDialog(
            initial = memberDialogItem,
            onDismiss = { showNewMember = false; memberDialogItem = null },
            onSave = { item ->
                viewModel.saveMember(item) { showNewMember = false; memberDialogItem = null }
            }
        )
    }

    if (showNewVolunteer || volunteerDialogItem != null) {
        VolunteerFormDialog(
            initial = volunteerDialogItem,
            onDismiss = { showNewVolunteer = false; volunteerDialogItem = null },
            onSave = { item ->
                viewModel.saveVolunteer(item) { showNewVolunteer = false; volunteerDialogItem = null }
            }
        )
    }

    if (showNewActivity || activityDialogItem != null) {
        ActivityFormDialog(
            initial = activityDialogItem,
            viewModel = viewModel,
            onDismiss = { showNewActivity = false; activityDialogItem = null },
            onSave = { item ->
                viewModel.saveActivity(item) { showNewActivity = false; activityDialogItem = null }
            }
        )
    }

    if (showNewBloodReq) {
        // Reuse Blood request quick dialog
        var patient by remember { mutableStateOf("") }
        var bg by remember { mutableStateOf("O+") }
        var hospital by remember { mutableStateOf("") }
        var loc by remember { mutableStateOf("") }
        var date by remember { mutableStateOf("") }
        var contact by remember { mutableStateOf("") }
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showNewBloodReq = false },
            title = { Text("রক্তের অনুরোধ যোগ করুন") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    androidx.compose.material3.OutlinedTextField(value = patient, onValueChange = { patient = it }, label = { Text("রোগীর নাম") }, singleLine = true)
                    androidx.compose.material3.OutlinedTextField(value = bg, onValueChange = { bg = it }, label = { Text("রক্তের গ্রুপ") }, singleLine = true)
                    androidx.compose.material3.OutlinedTextField(value = hospital, onValueChange = { hospital = it }, label = { Text("হাসপাতাল") }, singleLine = true)
                    androidx.compose.material3.OutlinedTextField(value = loc, onValueChange = { loc = it }, label = { Text("এলাকা") }, singleLine = true)
                    androidx.compose.material3.OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("প্রয়োজনের তারিখ") }, singleLine = true)
                    androidx.compose.material3.OutlinedTextField(value = contact, onValueChange = { contact = it }, label = { Text("যোগাযোগ") }, singleLine = true)
                }
            },
            confirmButton = {
                com.example.ui.components.AnimatedPrimaryButton(
                    text = "প্রকাশ করুন",
                    enabled = patient.isNotBlank() && hospital.isNotBlank() && loc.isNotBlank() && date.isNotBlank() && contact.isNotBlank(),
                    onClick = {
                        viewModel.createBloodRequest(
                            BloodRequest(patientName = patient, bloodGroup = bg, hospital = hospital, location = loc, requiredDate = date, units = 1, contact = contact, urgency = "urgent")
                        ) { showNewBloodReq = false }
                    }
                )
            },
            dismissButton = { TextButton(onClick = { showNewBloodReq = false }) { Text("বাতিল") } }
        )
    }

    if (showNewContrib) {
        ContributionFormDialog(
            onDismiss = { showNewContrib = false },
            onSave = { viewModel.addContribution(it) { showNewContrib = false } }
        )
    }

    if (showNewDonation) {
        DonationFormDialog(
            onDismiss = { showNewDonation = false },
            onSave = { viewModel.addDonation(it) { showNewDonation = false } }
        )
    }

    if (showNewExpense) {
        ExpenseFormDialog(
            onDismiss = { showNewExpense = false },
            onSave = { viewModel.addExpense(it) { showNewExpense = false } }
        )
    }

    if (showNewNotice) {
        NoticeFormDialog(
            onDismiss = { showNewNotice = false },
            onSave = { viewModel.saveNotice(it, broadcastNotification = true) { showNewNotice = false } }
        )
    }

    if (showNewPosition) {
        PositionFormDialog(
            onDismiss = { showNewPosition = false },
            onSave = { viewModel.savePosition(it) { showNewPosition = false } }
        )
    }

    roleDialogUser?.let { target ->
        RolePermissionsDialog(
            targetUser = target,
            onDismiss = { roleDialogUser = null },
            onSave = { role, perms, status ->
                viewModel.updateUserRoleAndPermissions(target.uid, role, perms, status)
                roleDialogUser = null
            }
        )
    }
}

@Composable
private fun MetricRow(label1: String, val1: String, label2: String, val2: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text("$label1: $val1", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Spacer(modifier = Modifier.width(8.dp))
        Text("$label2: $val2", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
    }
}
