package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Architecture
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.components.AnimatedEntranceItem
import com.example.ui.components.EmbossedCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeveloperAnvexScreen(
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ডেভেলপার পরিচিতি — Anvex™") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "ফিরে যান")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AnimatedEntranceItem(index = 0) {
                EmbossedCard(
                    modifier = Modifier.fillMaxWidth(),
                    cornerRadius = 24.dp,
                    contentPadding = PaddingValues(22.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .background(Color.White)
                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp))
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.logo_anvex),
                                contentDescription = "Anvex™ Developer Team Logo",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = "POWERED BY ANVEX ™",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Anvex™ সফটওয়্যার ও ইনোভেশন টিম",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "মানবতার সেবায় আধুনিক প্রযুক্তির নিখুঁত প্রয়োগ",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            AnimatedEntranceItem(index = 1) {
                EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "আমাদের সম্পর্কে",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Anvex™ বাংলাদেশের একটি আধুনিক, সৃজনশীল ও বিশ্বস্ত মোবাইল অ্যাপ্লিকেশন এবং ক্লাউড সফটওয়্যার ডেভেলপমেন্ট টিম। আমরা বিশ্বাস করি প্রযুক্তি তখনই সার্থক হয়, যখন তা মানুষের কল্যাণে ও সমাজের ইতিবাচক পরিবর্তনে ব্যবহৃত হয়।\n\nUnited for Humans অ্যাপ্লিকেশনটি Anvex™ টিমের নিখুঁত প্রকৌশল দক্ষতা, রিয়েল-টাইম ক্লাউড নিরাপত্তা এবং মানবিক দায়িত্ববোধের সম্মিলিত ফসল — যাতে বাংলাদেশের প্রতিটি সেবামূলক কার্যক্রম আরও দ্রুত, স্বচ্ছ ও সুশৃঙ্খলভাবে পরিচালিত হতে পারে।",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            AnimatedEntranceItem(index = 2) {
                EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Anvex™ টিমের বিশেষত্ব",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    FeatureLine(
                        icon = Icons.Rounded.Code,
                        title = "১০০% নেটিভ অ্যান্ড্রয়েড আর্কিটেকচার",
                        desc = "Kotlin, Jetpack Compose এবং Material 3-এ নির্মিত অতি দ্রুত ও মসৃণ অ্যানিমেটেড ইউজার ইন্টারফেস।"
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    FeatureLine(
                        icon = Icons.Rounded.Security,
                        title = "জিরো-ট্রাস্ট ক্লাউড নিরাপত্তা",
                        desc = "Firebase Authentication এবং কঠোর Firestore Security Rules-এর মাধ্যমে সদস্যদের তথ্য, অর্থ ও বার্তার সর্বোচ্চ সুরক্ষা।"
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    FeatureLine(
                        icon = Icons.Rounded.Speed,
                        title = "রিয়েল-টাইম সিঙ্ক ও স্বচ্ছতা",
                        desc = "রক্তদান, জরুরি সেবা অনুরোধ, আর্থিক হিসাব ও নোটিশ মুহূর্তেই রিয়েল-টাইমে আপডেট হয়।"
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    FeatureLine(
                        icon = Icons.Rounded.Architecture,
                        title = "উন্নত ও দায়িত্বশীল ডিজাইন",
                        desc = "সকল বয়সের ব্যবহারকারীর জন্য সহজ, পরিচ্ছন্ন বাংলা ও ইংরেজি সমন্বিত অভিজ্ঞতা।"
                    )
                }
            }

            AnimatedEntranceItem(index = 3) {
                EmbossedCard(
                    modifier = Modifier.fillMaxWidth(),
                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Rounded.Favorite,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "United for Humans • সংস্করণ ১.০",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "উন্নয়নে ও কারিগরি সহায়তায়: Anvex™ টিম, বাংলাদেশ",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FeatureLine(
    icon: ImageVector,
    title: String,
    desc: String
) {
    Row(verticalAlignment = Alignment.Top) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(text = desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
