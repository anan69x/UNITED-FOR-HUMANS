package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.AppConfig
import com.example.core.ImageUploadHelper
import com.example.core.UiState
import com.example.core.toFriendlyBengaliError
import com.example.data.model.ActivityItem
import com.example.data.model.AppNotification
import com.example.data.model.BloodRequest
import com.example.data.model.ChatMessage
import com.example.data.model.ContributionRecord
import com.example.data.model.ConversationItem
import com.example.data.model.DonationRecord
import com.example.data.model.ExpenseRecord
import com.example.data.model.FinancialSummary
import com.example.data.model.MemberItem
import com.example.data.model.NoticeItem
import com.example.data.model.OrganizationInfo
import com.example.data.model.PositionItem
import com.example.data.model.ServiceCategory
import com.example.data.model.ServiceRequest
import com.example.data.model.UserProfile
import com.example.data.model.VolunteerItem
import com.example.data.repository.AuthRepository
import com.example.data.repository.FinanceRepository
import com.example.data.repository.MessagingAndNotificationRepository
import com.example.data.repository.OrganizationRepository
import com.example.data.repository.PeopleAndBloodRepository
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val authRepo = AuthRepository()
    private val orgRepo = OrganizationRepository()
    private val peopleRepo = PeopleAndBloodRepository()
    private val financeRepo = FinanceRepository()
    private val msgRepo = MessagingAndNotificationRepository()
    private val imageUploadHelper = ImageUploadHelper(application.applicationContext)

    private val _toastEvents = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val toastEvents = _toastEvents.asSharedFlow()

    private val _authBusy = MutableStateFlow(false)
    val authBusy: StateFlow<Boolean> = _authBusy.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _showGuestLoginNudge = MutableStateFlow(false)
    val showGuestLoginNudge: StateFlow<Boolean> = _showGuestLoginNudge.asStateFlow()

    private var guestNudgeJob: Job? = null
    private var nudgeDismissedForSession = false

    val currentUser: StateFlow<FirebaseUser?> = authRepo.observeAuthState()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val userProfile: StateFlow<UserProfile?> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(null)
            else authRepo.observeUserProfile(user.uid)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val organization: StateFlow<OrganizationInfo?> = orgRepo.observeOrganization()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Public non-PII streams (visible in Guest mode + Member mode)
    val servicesState: StateFlow<UiState<List<ServiceCategory>>> = orgRepo.observeServices()
        .asUiStateFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    val activitiesState: StateFlow<UiState<List<ActivityItem>>> = orgRepo.observeActivities()
        .asUiStateFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    val noticesState: StateFlow<UiState<List<NoticeItem>>> = orgRepo.observeNotices()
        .asUiStateFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    val positionsState: StateFlow<UiState<List<PositionItem>>> = orgRepo.observePositions()
        .asUiStateFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    // Auth-gated protected streams (empty when Guest so rules never fail with PERMISSION_DENIED)
    val membersState: StateFlow<UiState<List<MemberItem>>> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(UiState.Success(emptyList()))
            else peopleRepo.observeMembers().asUiStateFlow()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    val volunteersState: StateFlow<UiState<List<VolunteerItem>>> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(UiState.Success(emptyList()))
            else peopleRepo.observeVolunteers().asUiStateFlow()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    val bloodRequestsState: StateFlow<UiState<List<BloodRequest>>> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(UiState.Success(emptyList()))
            else peopleRepo.observeBloodRequests().asUiStateFlow()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    val serviceRequestsState: StateFlow<UiState<List<ServiceRequest>>> = combine(currentUser, userProfile) { user, profile ->
        user to profile
    }.flatMapLatest { (user, profile) ->
        if (user == null) flowOf(UiState.Success(emptyList()))
        else {
            val canManageServices = user.uid == AppConfig.SUPER_ADMIN_UID ||
                profile?.hasPermission(AppConfig.PERM_SERVICES) == true
            peopleRepo.observeServiceRequests(user.uid, canManageServices).asUiStateFlow()
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    val contributionsState: StateFlow<UiState<List<ContributionRecord>>> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(UiState.Success(emptyList()))
            else financeRepo.observeContributions().asUiStateFlow()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    val donationsState: StateFlow<UiState<List<DonationRecord>>> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(UiState.Success(emptyList()))
            else financeRepo.observeDonations().asUiStateFlow()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    val expensesState: StateFlow<UiState<List<ExpenseRecord>>> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(UiState.Success(emptyList()))
            else financeRepo.observeExpenses().asUiStateFlow()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    val financialSummary: StateFlow<FinancialSummary> = combine(
        contributionsState,
        donationsState,
        expensesState
    ) { contrib, don, exp ->
        val totalC = (contrib as? UiState.Success)?.data?.sumOf { it.paidAmount } ?: 0.0
        val totalD = (don as? UiState.Success)?.data?.sumOf { it.amount } ?: 0.0
        val totalE = (exp as? UiState.Success)?.data?.sumOf { it.amount } ?: 0.0
        FinancialSummary(
            totalContributions = totalC,
            totalDonations = totalD,
            totalExpenses = totalE
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FinancialSummary())

    val conversationsState: StateFlow<UiState<List<ConversationItem>>> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(UiState.Success(emptyList()))
            else msgRepo.observeConversations(user.uid).asUiStateFlow()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    val notificationsState: StateFlow<UiState<List<AppNotification>>> = currentUser
        .flatMapLatest { user ->
            if (user == null) flowOf(UiState.Success(emptyList()))
            else msgRepo.observeNotifications(user.uid).asUiStateFlow()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Loading)

    val unreadNotificationsCount: StateFlow<Int> = notificationsState
        .map { state ->
            (state as? UiState.Success)?.data?.count { !it.read } ?: 0
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val allUsersState: StateFlow<UiState<List<UserProfile>>> = combine(currentUser, userProfile) { user, profile ->
        user to profile
    }.flatMapLatest { (user, profile) ->
        val isAdminUser = user != null &&
            (user.uid == AppConfig.SUPER_ADMIN_UID || profile?.isAdmin == true)
        if (!isAdminUser) flowOf(UiState.Success(emptyList()))
        else authRepo.observeAllUsers().asUiStateFlow()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiState.Success(emptyList()))

    init {
        viewModelScope.launch {
            currentUser.collect { user ->
                if (user != null) {
                    _showGuestLoginNudge.value = false
                    guestNudgeJob?.cancel()
                    authRepo.ensureUserProfileExists(user)
                }
            }
        }
    }

    /**
     * Starts the 30-second guest browse timer after Splash completes.
     * If user stays unauthenticated for 30s, displays a warm Bengali invitation to log in.
     */
    fun startGuestThirtySecondTimer() {
        if (currentUser.value != null || nudgeDismissedForSession) return
        if (guestNudgeJob?.isActive == true) return
        guestNudgeJob = viewModelScope.launch {
            delay(30_000L)
            if (currentUser.value == null && !nudgeDismissedForSession) {
                _showGuestLoginNudge.value = true
            }
        }
    }

    fun dismissGuestNudge() {
        nudgeDismissedForSession = true
        _showGuestLoginNudge.value = false
    }

    fun clearAuthError() {
        _authError.value = null
    }

    fun signInWithEmail(email: String, password: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _authBusy.value = true
            _authError.value = null
            val res = authRepo.signInWithEmail(email, password)
            _authBusy.value = false
            res.onSuccess {
                _toastEvents.tryEmit("সফলভাবে লগইন সম্পন্ন হয়েছে।")
                onSuccess()
            }.onFailure { err ->
                _authError.value = toFriendlyBengaliError(err)
            }
        }
    }

    fun registerWithEmail(
        name: String,
        email: String,
        password: String,
        phone: String,
        photoUrl: String,
        bloodGroup: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            _authBusy.value = true
            _authError.value = null
            val res = authRepo.registerWithEmail(name, email, password, phone, photoUrl, bloodGroup)
            _authBusy.value = false
            res.onSuccess {
                _toastEvents.tryEmit("নিবন্ধন সফল হয়েছে! স্বাগতম।")
                onSuccess()
            }.onFailure { err ->
                _authError.value = toFriendlyBengaliError(err)
            }
        }
    }

    fun signInWithGoogle(activityContext: Context, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _authBusy.value = true
            _authError.value = null
            val res = authRepo.signInWithGoogle(activityContext)
            _authBusy.value = false
            res.onSuccess {
                _toastEvents.tryEmit("Google অ্যাকাউন্টে লগইন সম্পন্ন হয়েছে।")
                onSuccess()
            }.onFailure { err ->
                _authError.value = toFriendlyBengaliError(err)
            }
        }
    }

    fun signOut() {
        viewModelScope.launch {
            authRepo.signOut()
            nudgeDismissedForSession = false
            _toastEvents.tryEmit("সফলভাবে লগআউট হয়েছে।")
        }
    }

    suspend fun uploadImageUri(uri: Uri): Result<String> =
        imageUploadHelper.compressAndUploadImage(uri)

    fun updateOwnProfile(
        name: String,
        phone: String,
        photoUrl: String,
        bloodGroup: String,
        address: String,
        onDone: () -> Unit = {}
    ) {
        viewModelScope.launch {
            authRepo.updateOwnProfile(name, phone, photoUrl, bloodGroup, address)
                .onSuccess {
                    _toastEvents.tryEmit("প্রোফাইল আপডেট হয়েছে।")
                    onDone()
                }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    fun updateUserRoleAndPermissions(
        targetUid: String,
        role: String,
        permissions: List<String>,
        status: String
    ) {
        viewModelScope.launch {
            authRepo.updateUserRoleAndPermissions(targetUid, role, permissions, status)
                .onSuccess { _toastEvents.tryEmit("ব্যবহারকারীর ভূমিকা ও অনুমতি আপডেট হয়েছে।") }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    // --- Services & Service Requests ---
    fun saveService(item: ServiceCategory, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            orgRepo.saveService(item)
                .onSuccess {
                    _toastEvents.tryEmit("সেবা বিভাগ সংরক্ষিত হয়েছে।")
                    onDone()
                }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    fun deleteService(id: String) {
        viewModelScope.launch {
            orgRepo.deleteService(id)
                .onSuccess { _toastEvents.tryEmit("সেবা বিভাগ মুছে ফেলা হয়েছে।") }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    fun submitServiceRequest(item: ServiceRequest, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            peopleRepo.submitServiceRequest(item)
                .onSuccess {
                    _toastEvents.tryEmit("আপনার সেবা অনুরোধ জমা হয়েছে।")
                    onDone()
                }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    fun updateServiceRequestStatus(request: ServiceRequest, status: String, note: String) {
        viewModelScope.launch {
            peopleRepo.updateServiceRequestStatus(request.id, status, note)
                .onSuccess {
                    _toastEvents.tryEmit("অনুরোধের অবস্থা আপডেট হয়েছে।")
                    if (request.requesterUid.isNotBlank()) {
                        msgRepo.createNotification(
                            recipientUid = request.requesterUid,
                            title = "সেবা অনুরোধ আপডেট: ${request.serviceTitle}",
                            body = "অবস্থা: $status ${if (note.isNotBlank()) "• $note" else ""}",
                            category = "service_update",
                            referenceId = request.id
                        )
                    }
                }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    // --- Members, Positions & Volunteers ---
    fun savePosition(item: PositionItem, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            orgRepo.savePosition(item)
                .onSuccess {
                    _toastEvents.tryEmit("পদবী সংরক্ষিত হয়েছে।")
                    onDone()
                }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    fun deletePosition(id: String) {
        viewModelScope.launch {
            orgRepo.deletePosition(id)
                .onSuccess { _toastEvents.tryEmit("পদবী মুছে ফেলা হয়েছে।") }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    fun saveMember(item: MemberItem, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            peopleRepo.saveMember(item)
                .onSuccess {
                    _toastEvents.tryEmit("সদস্যের তথ্য সংরক্ষিত হয়েছে।")
                    onDone()
                }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    fun toggleMemberStatus(member: MemberItem) {
        val next = if (member.status == "active") "inactive" else "active"
        viewModelScope.launch {
            peopleRepo.toggleMemberStatus(member.id, next)
                .onSuccess { _toastEvents.tryEmit("সদস্যের অবস্থা পরিবর্তিত হয়েছে।") }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    fun deleteMember(id: String) {
        viewModelScope.launch {
            peopleRepo.deleteMember(id)
                .onSuccess { _toastEvents.tryEmit("সদস্য মুছে ফেলা হয়েছে।") }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    fun saveVolunteer(item: VolunteerItem, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            peopleRepo.saveVolunteer(item)
                .onSuccess {
                    _toastEvents.tryEmit("স্বেচ্ছাসেবকের তথ্য সংরক্ষিত হয়েছে।")
                    onDone()
                }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    fun toggleVolunteerStatus(volunteer: VolunteerItem) {
        val next = if (volunteer.status == "active") "inactive" else "active"
        viewModelScope.launch {
            peopleRepo.toggleVolunteerStatus(volunteer.id, next)
                .onSuccess { _toastEvents.tryEmit("স্বেচ্ছাসেবকের অবস্থা পরিবর্তিত হয়েছে।") }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    fun deleteVolunteer(id: String) {
        viewModelScope.launch {
            peopleRepo.deleteVolunteer(id)
                .onSuccess { _toastEvents.tryEmit("স্বেচ্ছাসেবক মুছে ফেলা হয়েছে।") }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    // --- Blood Requests ---
    fun createBloodRequest(item: BloodRequest, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            peopleRepo.createBloodRequest(item)
                .onSuccess { reqId ->
                    _toastEvents.tryEmit("জরুরি রক্তের অনুরোধ প্রকাশিত হয়েছে।")
                    msgRepo.createNotification(
                        recipientUid = "all",
                        title = "জরুরি রক্তের প্রয়োজন (${item.bloodGroup})",
                        body = "${item.patientName} • ${item.hospital}, ${item.location} (${item.units} ব্যাগ)",
                        category = "blood_request",
                        referenceId = reqId
                    )
                    onDone()
                }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    fun updateBloodRequestStatus(requestId: String, status: String) {
        viewModelScope.launch {
            peopleRepo.updateBloodRequestStatus(requestId, status)
                .onSuccess { _toastEvents.tryEmit("রক্তের অনুরোধ আপডেট হয়েছে।") }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    fun deleteBloodRequest(requestId: String) {
        viewModelScope.launch {
            peopleRepo.deleteBloodRequest(requestId)
                .onSuccess { _toastEvents.tryEmit("রক্তের অনুরোধ মুছে ফেলা হয়েছে।") }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    // --- Activities ---
    fun saveActivity(item: ActivityItem, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            orgRepo.saveActivity(item)
                .onSuccess {
                    _toastEvents.tryEmit("কার্যক্রম সংরক্ষিত হয়েছে।")
                    onDone()
                }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    fun deleteActivity(id: String) {
        viewModelScope.launch {
            orgRepo.deleteActivity(id)
                .onSuccess { _toastEvents.tryEmit("কার্যক্রম মুছে ফেলা হয়েছে।") }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    // --- Finance ---
    fun addContribution(record: ContributionRecord, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            financeRepo.addContribution(record)
                .onSuccess {
                    _toastEvents.tryEmit("সদস্য চাঁদা যুক্ত হয়েছে।")
                    if (record.memberUid.isNotBlank()) {
                        msgRepo.createNotification(
                            recipientUid = record.memberUid,
                            title = "চাঁদা পরিশোধ আপডেট (${record.month})",
                            body = "জমা: ৳${record.paidAmount.toInt()} • বকেয়া: ৳${record.dueAmount.toInt()}",
                            category = "payment_update"
                        )
                    }
                    onDone()
                }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    fun addDonation(record: DonationRecord, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            financeRepo.addDonation(record)
                .onSuccess {
                    _toastEvents.tryEmit("অনুদান যুক্ত হয়েছে।")
                    onDone()
                }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    fun addExpense(record: ExpenseRecord, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            financeRepo.addExpense(record)
                .onSuccess {
                    _toastEvents.tryEmit("ব্যয়ের হিসাব যুক্ত হয়েছে।")
                    onDone()
                }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    fun deleteFinanceRecord(collection: String, id: String) {
        viewModelScope.launch {
            financeRepo.deleteRecord(collection, id)
                .onSuccess { _toastEvents.tryEmit("হিসাব মুছে ফেলা হয়েছে।") }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    // --- Notices & Notifications ---
    fun saveNotice(item: NoticeItem, broadcastNotification: Boolean = true, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            orgRepo.saveNotice(item)
                .onSuccess {
                    _toastEvents.tryEmit("নোটিশ প্রকাশিত হয়েছে।")
                    if (broadcastNotification && item.id.isBlank()) {
                        val cat = when (item.type) {
                            "event", "meeting" -> "event"
                            "announcement" -> "announcement"
                            else -> "notice"
                        }
                        msgRepo.createNotification(
                            recipientUid = "all",
                            title = item.title,
                            body = item.body.take(240),
                            category = cat
                        )
                    }
                    onDone()
                }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    fun deleteNotice(id: String) {
        viewModelScope.launch {
            orgRepo.deleteNotice(id)
                .onSuccess { _toastEvents.tryEmit("নোটিশ মুছে ফেলা হয়েছে।") }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    fun sendBroadcastAnnouncement(title: String, body: String, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            msgRepo.createNotification(
                recipientUid = "all",
                title = title,
                body = body,
                category = "announcement"
            ).onSuccess {
                _toastEvents.tryEmit("ঘোষণা সকল সদস্যের কাছে পাঠানো হয়েছে।")
                onDone()
            }.onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    fun markNotificationRead(id: String) {
        viewModelScope.launch {
            msgRepo.markNotificationRead(id)
        }
    }

    // --- Messaging ---
    fun observeMessages(conversationId: String): Flow<List<ChatMessage>> {
        val uid = currentUser.value?.uid.orEmpty()
        return msgRepo.observeMessages(conversationId, uid)
    }

    fun startConversation(
        otherUid: String,
        otherName: String,
        otherPhoto: String,
        onOpened: (String) -> Unit
    ) {
        val profile = userProfile.value
        val myName = profile?.name ?: currentUser.value?.displayName ?: "Member"
        val myPhoto = profile?.photoUrl.orEmpty()
        viewModelScope.launch {
            msgRepo.startOrGetConversation(otherUid, otherName, otherPhoto, myName, myPhoto)
                .onSuccess { convId -> onOpened(convId) }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    fun sendMessage(
        conversationId: String,
        participantUids: List<String>,
        text: String,
        imageUrl: String,
        onSent: () -> Unit = {}
    ) {
        val senderName = userProfile.value?.name
            ?: currentUser.value?.displayName
            ?: "Member"
        viewModelScope.launch {
            msgRepo.sendMessage(conversationId, participantUids, senderName, text, imageUrl)
                .onSuccess { onSent() }
                .onFailure { _toastEvents.tryEmit(toFriendlyBengaliError(it)) }
        }
    }

    fun markMessagesSeen(conversationId: String, messages: List<ChatMessage>) {
        viewModelScope.launch {
            msgRepo.markMessagesSeen(conversationId, messages)
        }
    }

    private fun <T> Flow<T>.asUiStateFlow(): Flow<UiState<T>> = this
        .map<T, UiState<T>> { UiState.Success(it) }
        .catch { error ->
            val firestoreErr = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreErr == null && error is CancellationException) throw error
            emit(UiState.Error(toFriendlyBengaliError(firestoreErr ?: error)))
        }
}
