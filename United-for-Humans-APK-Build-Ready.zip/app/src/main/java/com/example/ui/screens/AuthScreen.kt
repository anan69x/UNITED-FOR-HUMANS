package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Login
import androidx.compose.material.icons.rounded.AddAPhoto
import androidx.compose.material.icons.rounded.Bloodtype
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.core.AppConfig
import com.example.ui.components.AnimatedOutlinedActionButton
import com.example.ui.components.AnimatedPrimaryButton
import com.example.ui.components.EmbossedCard
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    viewModel: MainViewModel,
    isBusy: Boolean,
    authError: String?,
    onAuthSuccess: () -> Unit,
    onContinueAsGuest: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isRegisterTab by remember { mutableStateOf(false) }

    // Login state
    var loginEmail by remember { mutableStateOf("") }
    var loginPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    // Register state
    var regName by remember { mutableStateOf("") }
    var regEmail by remember { mutableStateOf("") }
    var regPhone by remember { mutableStateOf("") }
    var regPassword by remember { mutableStateOf("") }
    var regBloodGroup by remember { mutableStateOf("O+") }
    var bloodMenuExpanded by remember { mutableStateOf(false) }
    var regPhotoUrl by remember { mutableStateOf("") }
    var uploadStatus by remember { mutableStateOf<String?>(null) }
    var isUploadingPhoto by remember { mutableStateOf(false) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            isUploadingPhoto = true
            uploadStatus = "ছবি সংকুচিত ও আপলোড হচ্ছে..."
            scope.launch {
                viewModel.uploadImageUri(uri)
                    .onSuccess { url ->
                        regPhotoUrl = url
                        uploadStatus = "প্রোফাইল ছবি আপলোড সম্পন্ন।"
                    }
                    .onFailure { err ->
                        uploadStatus = err.message
                    }
                isUploadingPhoto = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isRegisterTab) "নতুন সদস্য নিবন্ধন" else "সদস্য লগইন") },
                navigationIcon = {
                    IconButton(onClick = onContinueAsGuest) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "ফিরে যান")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.drawable.logo_united_for_humans),
                contentDescription = AppConfig.APP_NAME,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .background(Color.White)
                    .border(1.5.dp, MaterialTheme.colorScheme.outline, CircleShape)
                    .padding(10.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = AppConfig.APP_NAME,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "${AppConfig.ORG_NAME} • ${AppConfig.TAGLINE_BN}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(18.dp))

            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = !isRegisterTab,
                    onClick = {
                        isRegisterTab = false
                        viewModel.clearAuthError()
                    },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                    modifier = Modifier.testTag("tab_login")
                ) {
                    Text("লগইন")
                }
                SegmentedButton(
                    selected = isRegisterTab,
                    onClick = {
                        isRegisterTab = true
                        viewModel.clearAuthError()
                    },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                    modifier = Modifier.testTag("tab_register")
                ) {
                    Text("নিবন্ধন")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (!authError.isNullOrBlank()) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = authError,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(12.dp)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                AnimatedContent(targetState = isRegisterTab, label = "auth_form_switch") { register ->
                    if (!register) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            OutlinedTextField(
                                value = loginEmail,
                                onValueChange = { loginEmail = it },
                                label = { Text("ইমেইল") },
                                leadingIcon = { Icon(Icons.Rounded.Email, null) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("login_email_input")
                            )
                            OutlinedTextField(
                                value = loginPassword,
                                onValueChange = { loginPassword = it },
                                label = { Text("পাসওয়ার্ড") },
                                leadingIcon = { Icon(Icons.Rounded.Lock, null) },
                                trailingIcon = {
                                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                        Icon(
                                            if (passwordVisible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                            contentDescription = "পাসওয়ার্ড দেখুন"
                                        )
                                    }
                                },
                                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("login_password_input")
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            AnimatedPrimaryButton(
                                text = if (isBusy) "অপেক্ষা করুন..." else "লগইন করুন",
                                icon = Icons.AutoMirrored.Rounded.Login,
                                enabled = !isBusy && loginEmail.isNotBlank() && loginPassword.length >= 6,
                                onClick = {
                                    viewModel.signInWithEmail(loginEmail, loginPassword, onAuthSuccess)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "login_submit_btn"
                            )
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primaryContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (regPhotoUrl.startsWith("https://")) {
                                        AsyncImage(
                                            model = regPhotoUrl,
                                            contentDescription = "প্রোফাইল ছবি",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    } else {
                                        Icon(
                                            Icons.Rounded.Person,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(32.dp)
                                        )
                                    }
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    AnimatedOutlinedActionButton(
                                        text = if (isUploadingPhoto) "আপলোড হচ্ছে..." else "প্রোফাইল ছবি বাছাই",
                                        icon = Icons.Rounded.AddAPhoto,
                                        enabled = !isUploadingPhoto,
                                        onClick = {
                                            photoPicker.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        }
                                    )
                                    if (!uploadStatus.isNullOrBlank()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = uploadStatus!!,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = regPhotoUrl,
                                onValueChange = { regPhotoUrl = it },
                                label = { Text("প্রোফাইল ছবির HTTPS লিংক (ঐচ্ছিক)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = regName,
                                onValueChange = { regName = it },
                                label = { Text("পূর্ণ নাম") },
                                leadingIcon = { Icon(Icons.Rounded.Person, null) },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("register_name_input")
                            )

                            OutlinedTextField(
                                value = regEmail,
                                onValueChange = { regEmail = it },
                                label = { Text("ইমেইল") },
                                leadingIcon = { Icon(Icons.Rounded.Email, null) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("register_email_input")
                            )

                            OutlinedTextField(
                                value = regPhone,
                                onValueChange = { regPhone = it },
                                label = { Text("মোবাইল নম্বর") },
                                leadingIcon = { Icon(Icons.Rounded.Phone, null) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("register_phone_input")
                            )

                            ExposedDropdownMenuBox(
                                expanded = bloodMenuExpanded,
                                onExpandedChange = { bloodMenuExpanded = !bloodMenuExpanded }
                            ) {
                                OutlinedTextField(
                                    value = regBloodGroup,
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("রক্তের গ্রুপ") },
                                    leadingIcon = { Icon(Icons.Rounded.Bloodtype, null) },
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = bloodMenuExpanded) },
                                    modifier = Modifier
                                        .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                        .fillMaxWidth()
                                )
                                ExposedDropdownMenu(
                                    expanded = bloodMenuExpanded,
                                    onDismissRequest = { bloodMenuExpanded = false }
                                ) {
                                    AppConfig.BLOOD_GROUPS.forEach { bg ->
                                        DropdownMenuItem(
                                            text = { Text(bg) },
                                            onClick = {
                                                regBloodGroup = bg
                                                bloodMenuExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = regPassword,
                                onValueChange = { regPassword = it },
                                label = { Text("পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)") },
                                leadingIcon = { Icon(Icons.Rounded.Lock, null) },
                                trailingIcon = {
                                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                        Icon(
                                            if (passwordVisible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                            contentDescription = "পাসওয়ার্ড দেখুন"
                                        )
                                    }
                                },
                                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("register_password_input")
                            )

                            AnimatedPrimaryButton(
                                text = if (isBusy) "নিবন্ধন হচ্ছে..." else "সদস্য হিসেবে নিবন্ধন করুন",
                                icon = Icons.Rounded.PersonAdd,
                                enabled = !isBusy && regName.isNotBlank() && regEmail.isNotBlank() && regPhone.isNotBlank() && regPassword.length >= 6,
                                onClick = {
                                    viewModel.registerWithEmail(
                                        name = regName,
                                        email = regEmail,
                                        password = regPassword,
                                        phone = regPhone,
                                        photoUrl = regPhotoUrl,
                                        bloodGroup = regBloodGroup,
                                        onSuccess = onAuthSuccess
                                    )
                                },
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "register_submit_btn"
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            AnimatedOutlinedActionButton(
                text = "Google দিয়ে সাইন ইন করুন",
                enabled = !isBusy,
                onClick = { viewModel.signInWithGoogle(context, onAuthSuccess) },
                modifier = Modifier.fillMaxWidth(),
                testTag = "google_signin_btn"
            )

            if (isBusy) {
                Spacer(modifier = Modifier.height(12.dp))
                CircularProgressIndicator(modifier = Modifier.size(28.dp))
            }

            Spacer(modifier = Modifier.height(8.dp))
            TextButton(onClick = onContinueAsGuest) {
                Text("অতিথি হিসেবে অ্যাপ ঘুরে দেখুন")
            }
        }
    }
}
