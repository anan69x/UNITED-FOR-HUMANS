package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.core.AppConfig
import com.example.data.model.ActivityItem
import com.example.data.model.ContributionRecord
import com.example.data.model.DonationRecord
import com.example.data.model.ExpenseRecord
import com.example.data.model.MemberItem
import com.example.data.model.NoticeItem
import com.example.data.model.PositionItem
import com.example.data.model.ServiceCategory
import com.example.data.model.UserProfile
import com.example.data.model.VolunteerItem
import com.example.ui.components.AnimatedOutlinedActionButton
import com.example.ui.components.AnimatedPrimaryButton
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

@Composable
fun ServiceFormDialog(
    initial: ServiceCategory? = null,
    onDismiss: () -> Unit,
    onSave: (ServiceCategory) -> Unit
) {
    var title by remember { mutableStateOf(initial?.title.orEmpty()) }
    var titleBn by remember { mutableStateOf(initial?.titleBn.orEmpty()) }
    var description by remember { mutableStateOf(initial?.description.orEmpty()) }
    var iconKey by remember { mutableStateOf(initial?.iconKey ?: "volunteer") }
    var sortOrder by remember { mutableStateOf((initial?.sortOrder ?: 1).toString()) }
    var active by remember { mutableStateOf(initial?.active ?: true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "নতুন সেবা বিভাগ" else "সেবা সম্পাদনা") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = titleBn, onValueChange = { titleBn = it }, label = { Text("বাংলা নাম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("ইংরেজি নাম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("বিবরণ") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = iconKey, onValueChange = { iconKey = it }, label = { Text("আইকন কী (blood, medical, food, education, winter, relief, emergency, family, construction, environment, volunteer)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = sortOrder, onValueChange = { sortOrder = it.filter(Char::isDigit) }, label = { Text("ক্রম নম্বর") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = active, onCheckedChange = { active = it })
                    Text("সক্রিয় সেবা")
                }
            }
        },
        confirmButton = {
            AnimatedPrimaryButton(
                text = "সংরক্ষণ",
                enabled = titleBn.isNotBlank() && title.isNotBlank() && description.isNotBlank(),
                onClick = {
                    onSave(
                        (initial ?: ServiceCategory()).copy(
                            title = title,
                            titleBn = titleBn,
                            description = description,
                            iconKey = iconKey.ifBlank { "volunteer" },
                            sortOrder = sortOrder.toIntOrNull() ?: 1,
                            active = active
                        )
                    )
                }
            )
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
fun MemberFormDialog(
    initial: MemberItem? = null,
    onDismiss: () -> Unit,
    onSave: (MemberItem) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name.orEmpty()) }
    var phone by remember { mutableStateOf(initial?.phone.orEmpty()) }
    var email by remember { mutableStateOf(initial?.email.orEmpty()) }
    var bloodGroup by remember { mutableStateOf(initial?.bloodGroup ?: "O+") }
    var position by remember { mutableStateOf(initial?.position ?: "সদস্য") }
    var joiningDate by remember { mutableStateOf(initial?.joiningDate.orEmpty()) }
    var address by remember { mutableStateOf(initial?.address.orEmpty()) }
    var userId by remember { mutableStateOf(initial?.userId.orEmpty()) }
    var bloodDonor by remember { mutableStateOf(initial?.bloodDonor ?: true) }
    var donorAvailable by remember { mutableStateOf(initial?.donorAvailable ?: true) }
    var donationCount by remember { mutableStateOf((initial?.donationCount ?: 0).toString()) }
    var lastDonationDate by remember { mutableStateOf(initial?.lastDonationDate.orEmpty()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "নতুন সদস্য যোগ করুন" else "সদস্য তথ্য সম্পাদনা") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("নাম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("ফোন") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("ইমেইল (ঐচ্ছিক)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = bloodGroup, onValueChange = { bloodGroup = it }, label = { Text("রক্তের গ্রুপ (যেমন: O+)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = position, onValueChange = { position = it }, label = { Text("পদবী") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = joiningDate, onValueChange = { joiningDate = it }, label = { Text("যোগদানের তারিখ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("ঠিকানা") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = userId, onValueChange = { userId = it }, label = { Text("অ্যাকাউন্ট UID (চ্যাটের জন্য ঐচ্ছিক)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = bloodDonor, onCheckedChange = { bloodDonor = it })
                    Text("রক্তদাতা হিসেবে নিবন্ধিত")
                }
                if (bloodDonor) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = donorAvailable, onCheckedChange = { donorAvailable = it })
                        Text("রক্তদানে প্রস্তুত")
                    }
                    OutlinedTextField(value = donationCount, onValueChange = { donationCount = it.filter(Char::isDigit) }, label = { Text("মোট রক্তদান সংখ্যা") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = lastDonationDate, onValueChange = { lastDonationDate = it }, label = { Text("সর্বশেষ রক্তদানের তারিখ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            }
        },
        confirmButton = {
            AnimatedPrimaryButton(
                text = "সংরক্ষণ",
                enabled = name.isNotBlank() && phone.isNotBlank() && bloodGroup.isNotBlank() && position.isNotBlank(),
                onClick = {
                    onSave(
                        (initial ?: MemberItem()).copy(
                            userId = userId.trim(),
                            name = name,
                            phone = phone,
                            email = email,
                            bloodGroup = bloodGroup,
                            position = position,
                            joiningDate = joiningDate,
                            address = address,
                            bloodDonor = bloodDonor,
                            donorAvailable = donorAvailable,
                            donationCount = donationCount.toIntOrNull() ?: 0,
                            lastDonationDate = lastDonationDate
                        )
                    )
                }
            )
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
fun VolunteerFormDialog(
    initial: VolunteerItem? = null,
    onDismiss: () -> Unit,
    onSave: (VolunteerItem) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name.orEmpty()) }
    var phone by remember { mutableStateOf(initial?.phone.orEmpty()) }
    var skills by remember { mutableStateOf(initial?.skills.orEmpty()) }
    var availability by remember { mutableStateOf(initial?.availability ?: "যেকোনো সময়") }
    var bloodGroup by remember { mutableStateOf(initial?.bloodGroup ?: "O+") }
    var joiningDate by remember { mutableStateOf(initial?.joiningDate.orEmpty()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "নতুন স্বেচ্ছাসেবক" else "স্বেচ্ছাসেবক সম্পাদনা") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("নাম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("ফোন") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = skills, onValueChange = { skills = it }, label = { Text("দক্ষতা") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = availability, onValueChange = { availability = it }, label = { Text("উপলব্ধ সময়") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = bloodGroup, onValueChange = { bloodGroup = it }, label = { Text("রক্তের গ্রুপ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = joiningDate, onValueChange = { joiningDate = it }, label = { Text("যোগদানের তারিখ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            AnimatedPrimaryButton(
                text = "সংরক্ষণ",
                enabled = name.isNotBlank() && phone.isNotBlank() && skills.isNotBlank(),
                onClick = {
                    onSave(
                        (initial ?: VolunteerItem()).copy(
                            name = name,
                            phone = phone,
                            skills = skills,
                            availability = availability,
                            bloodGroup = bloodGroup,
                            joiningDate = joiningDate
                        )
                    )
                }
            )
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
fun ActivityFormDialog(
    initial: ActivityItem? = null,
    viewModel: MainViewModel,
    onDismiss: () -> Unit,
    onSave: (ActivityItem) -> Unit
) {
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf(initial?.title.orEmpty()) }
    var description by remember { mutableStateOf(initial?.description.orEmpty()) }
    var category by remember { mutableStateOf(initial?.category ?: "ত্রাণ ও মানবিক সহায়তা") }
    var imageUrl by remember { mutableStateOf(initial?.imageUrl.orEmpty()) }
    var dateText by remember { mutableStateOf(initial?.dateText.orEmpty()) }
    var location by remember { mutableStateOf(initial?.location.orEmpty()) }
    var participants by remember { mutableStateOf((initial?.participantsCount ?: 0).toString()) }
    var beneficiaries by remember { mutableStateOf((initial?.beneficiariesCount ?: 0).toString()) }
    var budget by remember { mutableStateOf((initial?.budget?.toInt() ?: 0).toString()) }
    var status by remember { mutableStateOf(initial?.status ?: "ongoing") }
    var uploadMsg by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            uploadMsg = "ছবি আপলোড হচ্ছে..."
            scope.launch {
                viewModel.uploadImageUri(uri)
                    .onSuccess {
                        imageUrl = it
                        uploadMsg = "ছবি আপলোড হয়েছে।"
                    }
                    .onFailure { uploadMsg = it.message }
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "নতুন কার্যক্রম যুক্ত করুন" else "কার্যক্রম সম্পাদনা") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("শিরোনাম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("বিভাগ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("বিবরণ") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = dateText, onValueChange = { dateText = it }, label = { Text("তারিখ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text("স্থান") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = participants, onValueChange = { participants = it.filter(Char::isDigit) }, label = { Text("অংশগ্রহণকারী") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = beneficiaries, onValueChange = { beneficiaries = it.filter(Char::isDigit) }, label = { Text("উপকারভোগী") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                }
                OutlinedTextField(value = budget, onValueChange = { budget = it.filter(Char::isDigit) }, label = { Text("বাজেট (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = imageUrl, onValueChange = { imageUrl = it }, label = { Text("ছবির HTTPS লিংক (ঐচ্ছিক)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                AnimatedOutlinedActionButton(
                    text = "গ্যালারি থেকে ছবি আপলোড",
                    onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                )
                if (!uploadMsg.isNullOrBlank()) Text(uploadMsg!!, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = status == "ongoing", onClick = { status = "ongoing" }, label = { Text("চলমান") })
                    FilterChip(selected = status == "completed", onClick = { status = "completed" }, label = { Text("সম্পন্ন") })
                }
            }
        },
        confirmButton = {
            AnimatedPrimaryButton(
                text = "সংরক্ষণ",
                enabled = title.isNotBlank() && description.isNotBlank() && dateText.isNotBlank() && location.isNotBlank(),
                onClick = {
                    onSave(
                        (initial ?: ActivityItem()).copy(
                            title = title,
                            description = description,
                            category = category,
                            imageUrl = imageUrl,
                            dateText = dateText,
                            location = location,
                            participantsCount = participants.toIntOrNull() ?: 0,
                            beneficiariesCount = beneficiaries.toIntOrNull() ?: 0,
                            budget = budget.toDoubleOrNull() ?: 0.0,
                            status = status
                        )
                    )
                }
            )
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
fun ContributionFormDialog(
    onDismiss: () -> Unit,
    onSave: (ContributionRecord) -> Unit
) {
    var memberName by remember { mutableStateOf("") }
    var memberUid by remember { mutableStateOf("") }
    var expected by remember { mutableStateOf("") }
    var paid by remember { mutableStateOf("") }
    var month by remember { mutableStateOf("") }
    var paymentDate by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("bKash") }

    val expectedVal = expected.toDoubleOrNull() ?: 0.0
    val paidVal = paid.toDoubleOrNull() ?: 0.0
    val dueVal = (expectedVal - paidVal).coerceAtLeast(0.0)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("সদস্য চাঁদা যুক্ত করুন") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = memberName, onValueChange = { memberName = it }, label = { Text("সদস্যের নাম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = memberUid, onValueChange = { memberUid = it }, label = { Text("সদস্য UID (নোটিফিকেশনের জন্য ঐচ্ছিক)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = expected, onValueChange = { expected = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("নির্ধারিত (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = paid, onValueChange = { paid = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("জমা (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                }
                Text("বকেয়া: ৳${dueVal.toInt()}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                OutlinedTextField(value = month, onValueChange = { month = it }, label = { Text("মাস (যেমন: নভেম্বর ২০২৬)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = paymentDate, onValueChange = { paymentDate = it }, label = { Text("পরিশোধের তারিখ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = method, onValueChange = { method = it }, label = { Text("মাধ্যম (bKash / Nagad / Cash)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            AnimatedPrimaryButton(
                text = "জমা করুন",
                enabled = memberName.isNotBlank() && month.isNotBlank() && paymentDate.isNotBlank() && expectedVal > 0,
                onClick = {
                    onSave(
                        ContributionRecord(
                            memberUid = memberUid.trim(),
                            memberName = memberName,
                            expectedAmount = expectedVal,
                            paidAmount = paidVal,
                            dueAmount = dueVal,
                            month = month,
                            paymentDate = paymentDate,
                            paymentMethod = method
                        )
                    )
                }
            )
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
fun DonationFormDialog(
    onDismiss: () -> Unit,
    onSave: (DonationRecord) -> Unit
) {
    var donorName by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var purpose by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("bKash") }
    var date by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন অনুদান যুক্ত করুন") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = donorName, onValueChange = { donorName = it }, label = { Text("দাতার নাম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = amount, onValueChange = { amount = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("পরিমাণ (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = purpose, onValueChange = { purpose = it }, label = { Text("উদ্দেশ্য") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = method, onValueChange = { method = it }, label = { Text("মাধ্যম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("তারিখ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            AnimatedPrimaryButton(
                text = "সংরক্ষণ",
                enabled = donorName.isNotBlank() && (amount.toDoubleOrNull() ?: 0.0) > 0 && purpose.isNotBlank() && date.isNotBlank(),
                onClick = {
                    onSave(
                        DonationRecord(
                            donorName = donorName,
                            amount = amount.toDoubleOrNull() ?: 0.0,
                            purpose = purpose,
                            paymentMethod = method,
                            donationDate = date
                        )
                    )
                }
            )
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
fun ExpenseFormDialog(
    onDismiss: () -> Unit,
    onSave: (ExpenseRecord) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন ব্যয় যুক্ত করুন") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("ব্যয়ের শিরোনাম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("বিভাগ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = amount, onValueChange = { amount = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("পরিমাণ (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("তারিখ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            AnimatedPrimaryButton(
                text = "সংরক্ষণ",
                enabled = title.isNotBlank() && category.isNotBlank() && (amount.toDoubleOrNull() ?: 0.0) > 0 && date.isNotBlank(),
                onClick = {
                    onSave(
                        ExpenseRecord(
                            title = title,
                            category = category,
                            amount = amount.toDoubleOrNull() ?: 0.0,
                            expenseDate = date
                        )
                    )
                }
            )
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
fun NoticeFormDialog(
    onDismiss: () -> Unit,
    onSave: (NoticeItem) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("notice") }
    var eventDate by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন নোটিশ / ইভেন্ট তৈরি") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("শিরোনাম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text("বিস্তারিত বার্তা") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("notice" to "নোটিশ", "announcement" to "ঘোষণা", "meeting" to "সভা", "event" to "ইভেন্ট").forEach { (k, l) ->
                        FilterChip(selected = type == k, onClick = { type = k }, label = { Text(l) })
                    }
                }
                OutlinedTextField(value = eventDate, onValueChange = { eventDate = it }, label = { Text("তারিখ ও সময় (ঐচ্ছিক)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text("স্থান (ঐচ্ছিক)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            AnimatedPrimaryButton(
                text = "প্রকাশ করুন",
                enabled = title.isNotBlank() && body.isNotBlank(),
                onClick = {
                    onSave(NoticeItem(title = title, body = body, type = type, eventDate = eventDate, location = location))
                }
            )
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
fun PositionFormDialog(
    onDismiss: () -> Unit,
    onSave: (PositionItem) -> Unit
) {
    var titleBn by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var rank by remember { mutableStateOf("1") }
    var description by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন পদবী যুক্ত করুন") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = titleBn, onValueChange = { titleBn = it }, label = { Text("বাংলা পদবী (যেমন: সভাপতি)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("ইংরেজি পদবী (যেমন: President)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = rank, onValueChange = { rank = it.filter(Char::isDigit) }, label = { Text("ক্রম") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("দায়িত্ব (ঐচ্ছিক)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            AnimatedPrimaryButton(
                text = "সংরক্ষণ",
                enabled = titleBn.isNotBlank() && title.isNotBlank(),
                onClick = {
                    onSave(PositionItem(title = title, titleBn = titleBn, rank = rank.toIntOrNull() ?: 1, description = description))
                }
            )
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
fun RolePermissionsDialog(
    targetUser: UserProfile,
    onDismiss: () -> Unit,
    onSave: (role: String, permissions: List<String>, status: String) -> Unit
) {
    var role by remember { mutableStateOf(targetUser.role) }
    var permissions by remember { mutableStateOf(targetUser.permissions.toSet()) }
    var status by remember { mutableStateOf(targetUser.status) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ভূমিকা ও অনুমতি: ${targetUser.name}") },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = role == "member", onClick = { role = "member" }, label = { Text("সদস্য") })
                    FilterChip(selected = role == "admin", onClick = { role = "admin" }, label = { Text("অ্যাডমিন") })
                }
                if (role == "admin") {
                    Text("অ্যাডমিন অনুমতিসমূহ:", style = MaterialTheme.typography.titleSmall)
                    AppConfig.ALL_PERMISSIONS.forEach { (key, label) ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = permissions.contains(key),
                                onCheckedChange = { checked ->
                                    permissions = if (checked) permissions + key else permissions - key
                                }
                            )
                            Text(label, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = status == "active", onClick = { status = "active" }, label = { Text("সক্রিয়") })
                    FilterChip(selected = status == "inactive", onClick = { status = "inactive" }, label = { Text("নিষ্ক্রিয়") })
                }
            }
        },
        confirmButton = {
            AnimatedPrimaryButton(
                text = "আপডেট করুন",
                onClick = {
                    val finalPerms = if (role == "admin") permissions.toList() else emptyList()
                    onSave(role, finalPerms, status)
                }
            )
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}
