package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.AddComment
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.core.UiState
import com.example.data.model.ConversationItem
import com.example.data.model.MemberItem
import com.example.ui.components.AnimatedEntranceItem
import com.example.ui.components.EmbossedCard
import com.example.ui.components.EmptyStateBengaliCard
import com.example.ui.components.GuestLoginRequiredCard
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConversationsScreen(
    isSignedIn: Boolean,
    currentUid: String,
    conversationsState: UiState<List<ConversationItem>>,
    membersState: UiState<List<MemberItem>>,
    onBack: () -> Unit,
    onRequireLogin: () -> Unit,
    onOpenConversation: (String) -> Unit,
    onStartConversationWithMember: (MemberItem) -> Unit
) {
    var showNewChatDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("বার্তা (১-টু-১ চ্যাট)") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "ফিরে যান")
                    }
                }
            )
        },
        floatingActionButton = {
            if (isSignedIn) {
                FloatingActionButton(
                    onClick = { showNewChatDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White
                ) {
                    Icon(Icons.Rounded.AddComment, contentDescription = "নতুন কথোপকথন")
                }
            }
        }
    ) { padding ->
        if (!isSignedIn) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
            ) {
                GuestLoginRequiredCard(
                    title = "সদস্যদের সাথে বার্তা বিনিময়ে লগইন করুন",
                    subtitle = "আপনার ব্যক্তিগত কথোপকথন কেবল অংশগ্রহণকারীদের জন্য সুরক্ষিত রাখতে লগইন প্রয়োজন।",
                    onLoginClick = onRequireLogin
                )
            }
        } else {
            val conversations = (conversationsState as? UiState.Success)?.data.orEmpty()
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .navigationBarsPadding(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (conversations.isEmpty()) {
                    item {
                        EmptyStateBengaliCard(
                            title = "এখনও কোনো কথোপকথন নেই",
                            subtitle = "নিচের বাটনে ট্যাপ করে অন্য কোনো সদস্যের সাথে ব্যক্তিগত বার্তা শুরু করুন।",
                            icon = Icons.Rounded.Forum
                        )
                    }
                } else {
                    itemsIndexed(conversations, key = { _, c -> c.id }) { idx, conv ->
                        val otherUid = conv.participantUids.firstOrNull { it != currentUid }.orEmpty()
                        val otherName = conv.participantNames[otherUid] ?: "সদস্য"
                        val otherPhoto = conv.participantPhotos[otherUid].orEmpty()
                        AnimatedEntranceItem(index = idx) {
                            EmbossedCard(
                                onClick = { onOpenConversation(conv.id) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (otherPhoto.startsWith("https://")) {
                                        AsyncImage(
                                            model = otherPhoto,
                                            contentDescription = otherName,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.size(48.dp).clip(CircleShape)
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .size(48.dp)
                                                .clip(CircleShape)
                                                .background(MaterialTheme.colorScheme.primaryContainer),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Rounded.Person, null, tint = MaterialTheme.colorScheme.primary)
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(otherName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text(
                                            text = conv.lastMessage.ifBlank { "কথোপকথন শুরু হয়েছে" },
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNewChatDialog) {
        val membersWithUid = (membersState as? UiState.Success)?.data.orEmpty()
            .filter { it.userId.isNotBlank() && it.userId != currentUid }

        AlertDialog(
            onDismissRequest = { showNewChatDialog = false },
            title = { Text("সদস্য নির্বাচন করুন") },
            text = {
                if (membersWithUid.isEmpty()) {
                    Text("এই মুহূর্তে চ্যাটের জন্য নিবন্ধিত অ্যাকাউন্টযুক্ত অন্য কোনো সদস্য পাওয়া যায়নি। সদস্য ডিরেক্টরিতে অ্যাকাউন্ট UID যুক্ত থাকলে এখানে দেখা যাবে।")
                } else {
                    LazyColumn(modifier = Modifier.height(260.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(membersWithUid, key = { it.id }) { m ->
                            EmbossedCard(
                                onClick = {
                                    showNewChatDialog = false
                                    onStartConversationWithMember(m)
                                },
                                contentPadding = PaddingValues(12.dp)
                            ) {
                                Text(m.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                Text(m.position, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showNewChatDialog = false }) { Text("বন্ধ করুন") }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatRoomScreen(
    conversationId: String,
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val currentUid = viewModel.currentUser.collectAsStateWithLifecycle().value?.uid.orEmpty()
    val conversations = (viewModel.conversationsState.collectAsStateWithLifecycle().value as? UiState.Success)?.data.orEmpty()
    val conversation = conversations.firstOrNull { it.id == conversationId }
    val otherUid = conversation?.participantUids?.firstOrNull { it != currentUid }.orEmpty()
    val otherName = conversation?.participantNames?.get(otherUid) ?: "কথোপকথন"

    val messages by remember(conversationId) {
        viewModel.observeMessages(conversationId)
    }.collectAsStateWithLifecycle(initialValue = emptyList())

    LaunchedEffect(messages) {
        if (messages.isNotEmpty()) {
            viewModel.markMessagesSeen(conversationId, messages)
        }
    }

    var textInput by remember { mutableStateOf("") }
    var imageUrlInput by remember { mutableStateOf("") }
    var showImageInput by remember { mutableStateOf(false) }
    val timeFormatter = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                viewModel.uploadImageUri(uri)
                    .onSuccess { url -> imageUrlInput = url }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(otherName) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "ফিরে যান")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding()
                .navigationBarsPadding()
        ) {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    val isMine = msg.senderUid == currentUid
                    val isSeenByOther = msg.seenBy.any { it != currentUid }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (isMine) Arrangement.End else Arrangement.Start
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (isMine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            tonalElevation = 2.dp,
                            modifier = Modifier.widthIn(max = 280.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                if (msg.imageUrl.startsWith("https://")) {
                                    AsyncImage(
                                        model = msg.imageUrl,
                                        contentDescription = "সংযুক্ত ছবি",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(160.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                }
                                if (msg.text.isNotBlank()) {
                                    Text(
                                        text = msg.text,
                                        color = if (isMine) Color.White else MaterialTheme.colorScheme.onSurface,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    val timeStr = msg.createdAt?.toDate()?.let { timeFormatter.format(it) }.orEmpty()
                                    Text(
                                        text = timeStr,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isMine) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (isMine) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            Icons.Rounded.DoneAll,
                                            contentDescription = if (isSeenByOther) "দেখা হয়েছে" else "পাঠানো হয়েছে",
                                            tint = if (isSeenByOther) Color(0xFFA7F3D0) else Color.White.copy(alpha = 0.7f),
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (showImageInput) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = imageUrlInput,
                        onValueChange = { imageUrlInput = it },
                        label = { Text("ছবির HTTPS লিংক") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = {
                        imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) {
                        Text("গ্যালারি")
                    }
                }
            }

            Surface(tonalElevation = 3.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { showImageInput = !showImageInput }) {
                        Icon(Icons.Rounded.Image, contentDescription = "ছবি যোগ করুন")
                    }
                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        placeholder = { Text("বার্তা লিখুন...") },
                        modifier = Modifier.weight(1f),
                        maxLines = 3
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                        enabled = textInput.isNotBlank() || imageUrlInput.startsWith("https://"),
                        onClick = {
                            val participants = conversation?.participantUids ?: listOf(currentUid, otherUid)
                            viewModel.sendMessage(
                                conversationId = conversationId,
                                participantUids = participants,
                                text = textInput,
                                imageUrl = imageUrlInput
                            ) {
                                textInput = ""
                                imageUrlInput = ""
                                showImageInput = false
                            }
                        }
                    ) {
                        Icon(
                            Icons.AutoMirrored.Rounded.Send,
                            contentDescription = "পাঠান",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}
