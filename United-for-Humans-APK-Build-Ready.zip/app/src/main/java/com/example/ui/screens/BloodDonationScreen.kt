package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Bloodtype
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.LocalHospital
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.core.AppConfig
import com.example.core.UiState
import com.example.data.model.BloodRequest
import com.example.data.model.MemberItem
import com.example.data.model.UserProfile
import com.example.ui.components.AnimatedEntranceItem
import com.example.ui.components.AnimatedOutlinedActionButton
import com.example.ui.components.AnimatedPrimaryButton
import com.example.ui.components.EmbossedCard
import com.example.ui.components.EmptyStateBengaliCard
import com.example.ui.components.GuestLoginRequiredCard
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.EmeraldSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BloodDonationScreen(
    isSignedIn: Boolean,
    userProfile: UserProfile?,
    membersState: UiState<List<MemberItem>>,
    bloodRequestsState: UiState<List<BloodRequest>>,
    onBack: () -> Unit,
    onRequireLogin: () -> Unit,
    onCreateBloodRequest: (BloodRequest, () -> Unit) -> Unit,
    onUpdateRequestStatus: (String, String) -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedBloodFilter by remember { mutableStateOf("সব") }
    var showCreateDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("রক্তদান কেন্দ্র") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "ফিরে যান")
                    }
                }
            )
        },
        floatingActionButton = {
            if (isSignedIn) {
                FloatingActionButton(
                    onClick = { showCreateDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = Color.White
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = "নতুন রক্তের অনুরোধ")
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .navigationBarsPadding()
        ) {
            if (!isSignedIn) {
                Box(modifier = Modifier.padding(16.dp)) {
                    GuestLoginRequiredCard(
                        title = "রক্তদাতা ও রোগীর তথ্য দেখতে লগইন করুন",
                        subtitle = "সদস্যদের ফোন নম্বর, রক্তের অনুরোধ ও রোগীর গোপনীয়তা রক্ষায় কেবল নিবন্ধিত সদস্যরাই এই বিভাগে প্রবেশ করতে পারেন।",
                        onLoginClick = onRequireLogin
                    )
                }
            } else {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        SegmentedButton(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            shape = SegmentedButtonDefaults.itemShape(0, 2)
                        ) { Text("রক্তের অনুরোধ") }
                        SegmentedButton(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            shape = SegmentedButtonDefaults.itemShape(1, 2)
                        ) { Text("রক্তদাতা তালিকা") }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        (listOf("সব") + AppConfig.BLOOD_GROUPS).forEach { group ->
                            FilterChip(
                                selected = selectedBloodFilter == group,
                                onClick = { selectedBloodFilter = group },
                                label = { Text(group) }
                            )
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (selectedTab == 0) {
                        val requests = (bloodRequestsState as? UiState.Success)?.data.orEmpty()
                            .filter { selectedBloodFilter == "সব" || it.bloodGroup == selectedBloodFilter }
                        if (requests.isEmpty()) {
                            item {
                                EmptyStateBengaliCard(
                                    title = "কোনো রক্তের অনুরোধ নেই",
                                    subtitle = "জরুরি প্রয়োজনে নিচের '+' বাটনে ট্যাপ করে নতুন রক্তের অনুরোধ যোগ করুন।",
                                    icon = Icons.Rounded.Bloodtype
                                )
                            }
                        } else {
                            itemsIndexed(requests, key = { _, r -> r.id }) { idx, req ->
                                AnimatedEntranceItem(index = idx) {
                                    EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(46.dp)
                                                        .clip(CircleShape)
                                                        .background(MaterialTheme.colorScheme.primaryContainer),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = req.bloodGroup,
                                                        style = MaterialTheme.typography.titleMedium,
                                                        fontWeight = FontWeight.Bold,
                                                        color = CrimsonPrimary
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Column {
                                                    Text(
                                                        text = req.patientName,
                                                        style = MaterialTheme.typography.titleMedium,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Text(
                                                        text = "${req.units} ব্যাগ • তারিখ: ${req.requiredDate}",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                            Surface(
                                                shape = RoundedCornerShape(50),
                                                color = when (req.urgency) {
                                                    "emergency" -> MaterialTheme.colorScheme.errorContainer
                                                    "urgent" -> MaterialTheme.colorScheme.tertiaryContainer
                                                    else -> MaterialTheme.colorScheme.secondaryContainer
                                                }
                                            ) {
                                                Text(
                                                    text = when (req.urgency) {
                                                        "emergency" -> "জরুরি!"
                                                        "urgent" -> "দ্রুত"
                                                        else -> "সাধারণ"
                                                    },
                                                    style = MaterialTheme.typography.labelMedium,
                                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(10.dp))
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Rounded.LocalHospital, null, modifier = Modifier.size(16.dp), tint = CrimsonPrimary)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(req.hospital, style = MaterialTheme.typography.bodyMedium)
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Rounded.LocationOn, null, modifier = Modifier.size(16.dp), tint = EmeraldSecondary)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("${req.location} • অবস্থা: ${req.status}", style = MaterialTheme.typography.bodySmall)
                                        }
                                        Spacer(modifier = Modifier.height(10.dp))

                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            AnimatedOutlinedActionButton(
                                                text = "কল করুন (${req.contact})",
                                                icon = Icons.Rounded.Call,
                                                onClick = {
                                                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${req.contact}"))
                                                    context.startActivity(intent)
                                                },
                                                modifier = Modifier.weight(1f)
                                            )
                                            val canFulfill = req.status == "open" &&
                                                (req.createdBy == userProfile?.uid || userProfile?.hasPermission(AppConfig.PERM_BLOOD) == true)
                                            if (canFulfill) {
                                                AnimatedOutlinedActionButton(
                                                    text = "সম্পন্ন",
                                                    icon = Icons.Rounded.CheckCircle,
                                                    contentColor = EmeraldSecondary,
                                                    onClick = { onUpdateRequestStatus(req.id, "fulfilled") }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        val donors = (membersState as? UiState.Success)?.data.orEmpty()
                            .filter { it.bloodDonor && it.status == "active" }
                            .filter { selectedBloodFilter == "সব" || it.bloodGroup == selectedBloodFilter }
                        if (donors.isEmpty()) {
                            item {
                                EmptyStateBengaliCard(
                                    title = "কোনো রক্তদাতা পাওয়া যায়নি",
                                    subtitle = "সদস্যদের তালিকায় রক্তদাতা হিসেবে যুক্ত সদস্যদের তথ্য এখানে প্রদর্শিত হবে।",
                                    icon = Icons.Rounded.Bloodtype
                                )
                            }
                        } else {
                            itemsIndexed(donors, key = { _, m -> m.id }) { idx, donor ->
                                AnimatedEntranceItem(index = idx) {
                                    EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            if (donor.photoUrl.startsWith("https://")) {
                                                AsyncImage(
                                                    model = donor.photoUrl,
                                                    contentDescription = donor.name,
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier
                                                        .size(50.dp)
                                                        .clip(CircleShape)
                                                )
                                            } else {
                                                Box(
                                                    modifier = Modifier
                                                        .size(50.dp)
                                                        .clip(CircleShape)
                                                        .background(MaterialTheme.colorScheme.primaryContainer),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(Icons.Rounded.Person, null, tint = MaterialTheme.colorScheme.primary)
                                                }
                                            }
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(donor.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                                Text(
                                                    text = "মোট রক্তদান: ${donor.donationCount} বার • সর্বশেষ: ${donor.lastDonationDate.ifBlank { "উল্লেখ নেই" }}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            Surface(
                                                shape = RoundedCornerShape(12.dp),
                                                color = MaterialTheme.colorScheme.primaryContainer
                                            ) {
                                                Text(
                                                    text = donor.bloodGroup,
                                                    style = MaterialTheme.typography.titleSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = CrimsonPrimary,
                                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(10.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Surface(
                                                shape = RoundedCornerShape(50),
                                                color = if (donor.donorAvailable) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface
                                            ) {
                                                Text(
                                                    text = if (donor.donorAvailable) "রক্তদানে প্রস্তুত" else "আপাতত বিরতিতে",
                                                    style = MaterialTheme.typography.labelMedium,
                                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                                )
                                            }
                                            AnimatedOutlinedActionButton(
                                                text = "কল করুন",
                                                icon = Icons.Rounded.Call,
                                                onClick = {
                                                    context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${donor.phone}")))
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        var patientName by remember { mutableStateOf("") }
        var bloodGroup by remember { mutableStateOf("O+") }
        var bgExpanded by remember { mutableStateOf(false) }
        var hospital by remember { mutableStateOf("") }
        var location by remember { mutableStateOf("") }
        var requiredDate by remember { mutableStateOf("") }
        var unitsText by remember { mutableStateOf("1") }
        var contact by remember { mutableStateOf(userProfile?.phone.orEmpty()) }
        var urgency by remember { mutableStateOf("urgent") }

        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("নতুন রক্তের অনুরোধ") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = patientName,
                        onValueChange = { patientName = it },
                        label = { Text("রোগীর নাম") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    ExposedDropdownMenuBox(
                        expanded = bgExpanded,
                        onExpandedChange = { bgExpanded = !bgExpanded }
                    ) {
                        OutlinedTextField(
                            value = bloodGroup,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("রক্তের গ্রুপ") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(bgExpanded) },
                            modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth()
                        )
                        ExposedDropdownMenu(expanded = bgExpanded, onDismissRequest = { bgExpanded = false }) {
                            AppConfig.BLOOD_GROUPS.forEach { bg ->
                                DropdownMenuItem(text = { Text(bg) }, onClick = {
                                    bloodGroup = bg
                                    bgExpanded = false
                                })
                            }
                        }
                    }
                    OutlinedTextField(value = hospital, onValueChange = { hospital = it }, label = { Text("হাসপাতালের নাম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text("শহর / এলাকা") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = requiredDate, onValueChange = { requiredDate = it }, label = { Text("তারিখ") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(
                            value = unitsText,
                            onValueChange = { unitsText = it.filter(Char::isDigit) },
                            label = { Text("ব্যাগ সংখ্যা") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedTextField(value = contact, onValueChange = { contact = it }, label = { Text("যোগাযোগ নম্বর") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("normal" to "সাধারণ", "urgent" to "জরুরি", "emergency" to "অতি জরুরি").forEach { (k, l) ->
                            FilterChip(selected = urgency == k, onClick = { urgency = k }, label = { Text(l) })
                        }
                    }
                }
            },
            confirmButton = {
                AnimatedPrimaryButton(
                    text = "প্রকাশ করুন",
                    enabled = patientName.isNotBlank() && hospital.isNotBlank() && location.isNotBlank() && requiredDate.isNotBlank() && contact.isNotBlank(),
                    onClick = {
                        onCreateBloodRequest(
                            BloodRequest(
                                patientName = patientName,
                                bloodGroup = bloodGroup,
                                hospital = hospital,
                                location = location,
                                requiredDate = requiredDate,
                                units = unitsText.toIntOrNull()?.coerceIn(1, 20) ?: 1,
                                contact = contact,
                                urgency = urgency
                            )
                        ) { showCreateDialog = false }
                    }
                )
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("বাতিল") }
            }
        )
    }
}
