package com.example.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Campaign
import androidx.compose.material.icons.rounded.Event
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Update
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.UiState
import com.example.data.model.NoticeItem
import com.example.ui.components.AnimatedEntranceItem
import com.example.ui.components.EmbossedCard
import com.example.ui.components.EmptyStateBengaliCard

@Composable
fun NoticesScreen(
    noticesState: UiState<List<NoticeItem>>
) {
    var selectedType by remember { mutableStateOf("all") }

    val types = listOf(
        "all" to "সব",
        "notice" to "নোটিশ",
        "announcement" to "ঘোষণা",
        "meeting" to "সভা",
        "event" to "ইভেন্ট",
        "activity_update" to "কার্যক্রম আপডেট"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "নোটিশ ও ইভেন্ট",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "সংগঠনের সকল জরুরি ঘোষণা, সভা ও কর্মসূচির রিয়েল-টাইম তথ্য",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                types.forEach { (key, label) ->
                    FilterChip(
                        selected = selectedType == key,
                        onClick = { selectedType = key },
                        label = { Text(label) }
                    )
                }
            }
        }

        when (noticesState) {
            is UiState.Loading -> {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
            }
            is UiState.Error -> {
                item {
                    EmptyStateBengaliCard(
                        title = "নোটিশ লোড করা যায়নি",
                        subtitle = noticesState.message
                    )
                }
            }
            is UiState.Success -> {
                val filtered = noticesState.data.filter {
                    selectedType == "all" || it.type == selectedType
                }
                if (filtered.isEmpty()) {
                    item {
                        EmptyStateBengaliCard(
                            title = "এখনও কোনো নোটিশ বা ইভেন্ট নেই",
                            subtitle = "অ্যাডমিন প্যানেল থেকে নতুন নোটিশ, সভা বা ইভেন্ট প্রকাশ করলে এখানে সাথে সাথে দেখতে পাবেন।",
                            icon = Icons.Rounded.Campaign
                        )
                    }
                } else {
                    itemsIndexed(filtered, key = { _, n -> n.id }) { idx, notice ->
                        AnimatedEntranceItem(index = idx) {
                            val icon = when (notice.type) {
                                "meeting" -> Icons.Rounded.Groups
                                "event" -> Icons.Rounded.Event
                                "announcement" -> Icons.Rounded.NotificationsActive
                                "activity_update" -> Icons.Rounded.Update
                                else -> Icons.Rounded.Campaign
                            }
                            val typeLabel = types.firstOrNull { it.first == notice.type }?.second ?: "নোটিশ"

                            EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(icon, contentDescription = typeLabel, tint = MaterialTheme.colorScheme.primary)
                                    Surface(
                                        shape = RoundedCornerShape(50),
                                        color = MaterialTheme.colorScheme.primaryContainer
                                    ) {
                                        Text(
                                            text = typeLabel,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = notice.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = notice.body,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (notice.eventDate.isNotBlank() || notice.location.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                        if (notice.eventDate.isNotBlank()) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Rounded.CalendarMonth, null, modifier = Modifier.size(15.dp), tint = MaterialTheme.colorScheme.secondary)
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(notice.eventDate, style = MaterialTheme.typography.bodySmall)
                                            }
                                        }
                                        if (notice.location.isNotBlank()) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Rounded.LocationOn, null, modifier = Modifier.size(15.dp), tint = MaterialTheme.colorScheme.primary)
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(notice.location, style = MaterialTheme.typography.bodySmall)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
