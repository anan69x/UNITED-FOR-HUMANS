package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Savings
import androidx.compose.material.icons.rounded.VolunteerActivism
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.UiState
import com.example.data.model.ContributionRecord
import com.example.data.model.DonationRecord
import com.example.data.model.ExpenseRecord
import com.example.data.model.FinancialSummary
import com.example.ui.components.AnimatedEntranceItem
import com.example.ui.components.EmbossedCard
import com.example.ui.components.EmptyStateBengaliCard
import com.example.ui.components.GuestLoginRequiredCard
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.EmeraldSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinanceScreen(
    isSignedIn: Boolean,
    summary: FinancialSummary,
    contributionsState: UiState<List<ContributionRecord>>,
    donationsState: UiState<List<DonationRecord>>,
    expensesState: UiState<List<ExpenseRecord>>,
    onBack: () -> Unit,
    onRequireLogin: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("আর্থিক হিসাব ও স্বচ্ছতা") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "ফিরে যান")
                    }
                }
            )
        }
    ) { padding ->
        if (!isSignedIn) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
            ) {
                GuestLoginRequiredCard(
                    title = "আর্থিক হিসাব দেখতে লগইন করুন",
                    subtitle = "সংগঠনের আর্থিক তথ্যের নিরাপত্তা ও স্বচ্ছতা বজায় রাখতে কেবল নিবন্ধিত সদস্যরাই এই হিসাব দেখতে পারেন।",
                    onLoginClick = onRequireLogin
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .navigationBarsPadding(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    AnimatedEntranceItem(index = 0) {
                        EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Rounded.AccountBalanceWallet, null, tint = EmeraldSecondary)
                                Text(
                                    text = "মোট আর্থিক সারসংক্ষেপ",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            SummaryRow("মোট সদস্য চাঁদা (+)", "৳${summary.totalContributions.toInt()}", EmeraldSecondary)
                            SummaryRow("মোট অনুদান (+)", "৳${summary.totalDonations.toInt()}", EmeraldSecondary)
                            SummaryRow("মোট ব্যয় (-)", "৳${summary.totalExpenses.toInt()}", CrimsonPrimary)
                            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("বর্তমান তহবিল ব্যালেন্স", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.secondaryContainer
                                ) {
                                    Text(
                                        text = "৳${summary.currentBalance.toInt()}",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldSecondary,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        SegmentedButton(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            shape = SegmentedButtonDefaults.itemShape(0, 3)
                        ) { Text("সদস্য চাঁদা") }
                        SegmentedButton(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            shape = SegmentedButtonDefaults.itemShape(1, 3)
                        ) { Text("অনুদান") }
                        SegmentedButton(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            shape = SegmentedButtonDefaults.itemShape(2, 3)
                        ) { Text("ব্যয়") }
                    }
                }

                when (selectedTab) {
                    0 -> {
                        val items = (contributionsState as? UiState.Success)?.data.orEmpty()
                        if (items.isEmpty()) {
                            item {
                                EmptyStateBengaliCard(
                                    title = "এখনও কোনো সদস্য চাঁদা যুক্ত হয়নি",
                                    subtitle = "অ্যাডমিন থেকে মাসিক চাঁদা এন্ট্রি দিলে এখানে বিস্তারিত দেখা যাবে।",
                                    icon = Icons.Rounded.Savings
                                )
                            }
                        } else {
                            itemsIndexed(items, key = { _, c -> c.id }) { idx, c ->
                                AnimatedEntranceItem(index = idx) {
                                    EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(c.memberName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                            Text(c.month, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = "নির্ধারিত: ৳${c.expectedAmount.toInt()} • পরিশোধ: ৳${c.paidAmount.toInt()} • বকেয়া: ৳${c.dueAmount.toInt()}",
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "তারিখ: ${c.paymentDate} • মাধ্যম: ${c.paymentMethod}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        val items = (donationsState as? UiState.Success)?.data.orEmpty()
                        if (items.isEmpty()) {
                            item {
                                EmptyStateBengaliCard(
                                    title = "এখনও কোনো অনুদান রেকর্ড নেই",
                                    subtitle = "দাতাদের অনুদান যুক্ত হলে এখানে রিয়েল-টাইমে দেখা যাবে।",
                                    icon = Icons.Rounded.VolunteerActivism
                                )
                            }
                        } else {
                            itemsIndexed(items, key = { _, d -> d.id }) { idx, d ->
                                AnimatedEntranceItem(index = idx) {
                                    EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(d.donorName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                            Text("৳${d.amount.toInt()}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = EmeraldSecondary)
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("উদ্দেশ্য: ${d.purpose}", style = MaterialTheme.typography.bodyMedium)
                                        Text(
                                            text = "তারিখ: ${d.donationDate} • মাধ্যম: ${d.paymentMethod}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }

                    else -> {
                        val items = (expensesState as? UiState.Success)?.data.orEmpty()
                        if (items.isEmpty()) {
                            item {
                                EmptyStateBengaliCard(
                                    title = "এখনও কোনো ব্যয়ের হিসাব নেই",
                                    subtitle = "মানবিক কার্যক্রমের ব্যয়ের হিসাব যুক্ত হলে এখানে প্রদর্শিত হবে।",
                                    icon = Icons.Rounded.ReceiptLong
                                )
                            }
                        } else {
                            itemsIndexed(items, key = { _, e -> e.id }) { idx, e ->
                                AnimatedEntranceItem(index = idx) {
                                    EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(e.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                            Text("৳${e.amount.toInt()}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = CrimsonPrimary)
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("বিভাগ: ${e.category} • তারিখ: ${e.expenseDate}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SummaryRow(
    label: String,
    value: String,
    color: androidx.compose.ui.graphics.Color
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = color)
    }
}
