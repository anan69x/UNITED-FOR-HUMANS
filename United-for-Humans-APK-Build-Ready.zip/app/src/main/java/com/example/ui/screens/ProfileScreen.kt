package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.Login
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.Bloodtype
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.core.AppConfig
import com.example.data.model.UserProfile
import com.example.ui.components.AnimatedEntranceItem
import com.example.ui.components.AnimatedOutlinedActionButton
import com.example.ui.components.AnimatedPrimaryButton
import com.example.ui.components.EmbossedCard
import com.example.ui.theme.AmberTertiary
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.EmeraldSecondary
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

@Composable
fun ProfileScreen(
    isSignedIn: Boolean,
    userProfile: UserProfile?,
    viewModel: MainViewModel,
    onOpenLogin: () -> Unit,
    onOpenAdminPanel: () -> Unit,
    onOpenBlood: () -> Unit,
    onOpenDirectory: () -> Unit,
    onOpenFinance: () -> Unit,
    onOpenMessages: () -> Unit,
    onOpenDeveloperAnvex: () -> Unit,
    onSignOut: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var showEditDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            AnimatedEntranceItem(index = 0) {
                EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                    if (!isSignedIn) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.logo_united_for_humans),
                                contentDescription = AppConfig.APP_NAME,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(CircleShape)
                                    .background(Color.White)
                                    .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                                    .padding(8.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "অতিথি মোড",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "সকল মানবিক সেবায় যুক্ত হতে লগইন বা নিবন্ধন করুন",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            AnimatedPrimaryButton(
                                text = "লগইন / নিবন্ধন করুন",
                                icon = Icons.AutoMirrored.Rounded.Login,
                                onClick = onOpenLogin,
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "profile_login_btn"
                            )
                        }
                    } else {
                        val name = userProfile?.name?.ifBlank { "সদস্য" } ?: "সদস্য"
                        val roleLabel = when {
                            userProfile?.isSuperAdmin == true -> "সুপার অ্যাডমিন"
                            userProfile?.isAdmin == true -> "অ্যাডমিন"
                            else -> "সদস্য"
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (userProfile?.photoUrl?.startsWith("https://") == true) {
                                AsyncImage(
                                    model = userProfile.photoUrl,
                                    contentDescription = name,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.size(64.dp).clip(CircleShape)
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primaryContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Rounded.Person, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
                                }
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Text(userProfile?.email.orEmpty(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.height(4.dp))
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = if (userProfile?.isAdmin == true) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer
                                ) {
                                    Text(
                                        text = roleLabel,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (userProfile?.isAdmin == true) CrimsonPrimary else EmeraldSecondary,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        if (!userProfile?.phone.isNullOrBlank() || !userProfile?.bloodGroup.isNullOrBlank()) {
                            Text(
                                text = "ফোন: ${userProfile?.phone.orEmpty()} • রক্তের গ্রুপ: ${userProfile?.bloodGroup.orEmpty()}",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            AnimatedOutlinedActionButton(
                                text = "প্রোফাইল সম্পাদনা",
                                icon = Icons.Rounded.Edit,
                                onClick = { showEditDialog = true },
                                modifier = Modifier.weight(1f)
                            )
                            AnimatedOutlinedActionButton(
                                text = "লগআউট",
                                icon = Icons.AutoMirrored.Rounded.Logout,
                                onClick = onSignOut,
                                modifier = Modifier.weight(1f),
                                testTag = "profile_logout_btn"
                            )
                        }
                    }
                }
            }
        }

        // Admin Panel ONLY visible to Admin / Super Admin
        if (isSignedIn && userProfile?.isAdmin == true) {
            item {
                AnimatedEntranceItem(index = 1) {
                    EmbossedCard(
                        onClick = onOpenAdminPanel,
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f),
                        modifier = Modifier.fillMaxWidth().testTag("open_admin_panel_btn")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.AdminPanelSettings, null, tint = CrimsonPrimary, modifier = Modifier.size(30.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("অ্যাডমিন কন্ট্রোল প্যানেল", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(
                                    text = if (userProfile.isSuperAdmin) "সুপার অ্যাডমিন — পূর্ণ নিয়ন্ত্রণ" else "অনুমোদিত অ্যাডমিন ফিচারসমূহ",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Icon(Icons.AutoMirrored.Rounded.ArrowForward, null, tint = CrimsonPrimary)
                        }
                    }
                }
            }
        }

        item {
            ProfileNavTile("রক্তদান কেন্দ্র", "রক্তের অনুরোধ ও রক্তদাতা", Icons.Rounded.Bloodtype, CrimsonPrimary, onOpenBlood)
        }
        item {
            ProfileNavTile("সদস্য, পদবী ও স্বেচ্ছাসেবক", "সংগঠন ডিরেক্টরি", Icons.Rounded.Groups, EmeraldSecondary, onOpenDirectory)
        }
        item {
            ProfileNavTile("আর্থিক হিসাব ও অনুদান", "চাঁদা, অনুদান, ব্যয় ও ব্যালেন্স", Icons.Rounded.AccountBalanceWallet, AmberTertiary, onOpenFinance)
        }
        item {
            ProfileNavTile("১-টু-১ বার্তা বিনিময়", "সদস্যদের সাথে চ্যাট", Icons.Rounded.Forum, MaterialTheme.colorScheme.primary, onOpenMessages)
        }

        // Developer: Anvex™ Section requested in Account/Profile
        item {
            AnimatedEntranceItem(index = 4) {
                EmbossedCard(
                    onClick = onOpenDeveloperAnvex,
                    modifier = Modifier.fillMaxWidth().testTag("developer_anvex_btn")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.logo_anvex),
                            contentDescription = "Anvex Team Logo",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .height(36.dp)
                                .width(72.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White)
                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                                .padding(4.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("ডেভেলপার পরিচিতি — Anvex™", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("POWERED BY ANVEX ™ • টিম সম্পর্কে জানুন", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(Icons.Rounded.Code, null, tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }

    if (showEditDialog && userProfile != null) {
        var name by remember { mutableStateOf(userProfile.name) }
        var phone by remember { mutableStateOf(userProfile.phone) }
        var bloodGroup by remember { mutableStateOf(userProfile.bloodGroup) }
        var address by remember { mutableStateOf(userProfile.address) }
        var photoUrl by remember { mutableStateOf(userProfile.photoUrl) }
        var uploadInfo by remember { mutableStateOf<String?>(null) }

        val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            if (uri != null) {
                uploadInfo = "ছবি আপলোড হচ্ছে..."
                scope.launch {
                    viewModel.uploadImageUri(uri)
                        .onSuccess {
                            photoUrl = it
                            uploadInfo = "ছবি আপলোড সম্পন্ন।"
                        }
                        .onFailure { uploadInfo = it.message }
                }
            }
        }

        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            title = { Text("প্রোফাইল সম্পাদনা") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("নাম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("ফোন") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = bloodGroup, onValueChange = { bloodGroup = it }, label = { Text("রক্তের গ্রুপ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("ঠিকানা") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = photoUrl, onValueChange = { photoUrl = it }, label = { Text("ছবির HTTPS লিংক") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    AnimatedOutlinedActionButton(
                        text = "গ্যালারি থেকে ছবি নিন",
                        onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                    )
                    if (!uploadInfo.isNullOrBlank()) {
                        Text(uploadInfo!!, style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = {
                AnimatedPrimaryButton(
                    text = "সংরক্ষণ",
                    enabled = name.isNotBlank(),
                    onClick = {
                        viewModel.updateOwnProfile(name, phone, photoUrl, bloodGroup, address) {
                            showEditDialog = false
                        }
                    }
                )
            },
            dismissButton = {
                TextButton(onClick = { showEditDialog = false }) { Text("বাতিল") }
            }
        )
    }
}

@Composable
private fun ProfileNavTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    tint: Color,
    onClick: () -> Unit
) {
    EmbossedCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(tint.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = title, tint = tint)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.AutoMirrored.Rounded.ArrowForward, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
