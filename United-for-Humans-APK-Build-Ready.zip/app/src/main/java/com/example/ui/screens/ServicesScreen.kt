package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.VolunteerActivism
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.UiState
import com.example.data.model.ServiceCategory
import com.example.data.model.ServiceRequest
import com.example.data.model.UserProfile
import com.example.ui.components.AnimatedEntranceItem
import com.example.ui.components.AnimatedOutlinedActionButton
import com.example.ui.components.AnimatedPrimaryButton
import com.example.ui.components.EmbossedCard
import com.example.ui.components.EmptyStateBengaliCard
import com.example.ui.components.serviceIconForKey

@Composable
fun ServicesScreen(
    isSignedIn: Boolean,
    userProfile: UserProfile?,
    servicesState: UiState<List<ServiceCategory>>,
    serviceRequestsState: UiState<List<ServiceRequest>>,
    onRequireLogin: () -> Unit,
    onSubmitServiceRequest: (ServiceRequest, () -> Unit) -> Unit
) {
    var selectedServiceForRequest by remember { mutableStateOf<ServiceCategory?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "মানবিক সেবাসমূহ",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "আমাদের সংগঠনের সকল চলমান মানবিক সেবা বিভাগসমূহ",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        when (servicesState) {
            is UiState.Loading -> {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
            }
            is UiState.Error -> {
                item {
                    EmptyStateBengaliCard(
                        title = "তথ্য লোড করা যায়নি",
                        subtitle = servicesState.message
                    )
                }
            }
            is UiState.Success -> {
                val activeServices = servicesState.data.filter { it.active }
                if (activeServices.isEmpty()) {
                    item {
                        EmptyStateBengaliCard(
                            title = "কোনো সেবা বিভাগ পাওয়া যায়নি",
                            subtitle = "অ্যাডমিন প্যানেল থেকে সেবা বিভাগ (যেমন: রক্তদান, চিকিৎসা সহায়তা, খাদ্য বিতরণ) যুক্ত করলে এখানে দেখা যাবে।",
                            icon = Icons.Rounded.VolunteerActivism
                        )
                    }
                } else {
                    itemsIndexed(activeServices, key = { _, s -> s.id }) { idx, service ->
                        AnimatedEntranceItem(index = idx) {
                            EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(48.dp)
                                            .clip(RoundedCornerShape(14.dp))
                                            .background(MaterialTheme.colorScheme.primaryContainer),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = serviceIconForKey(service.iconKey),
                                            contentDescription = service.titleBn,
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = service.titleBn.ifBlank { service.title },
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (service.title.isNotBlank() && service.titleBn.isNotBlank()) {
                                            Text(
                                                text = service.title,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = service.description,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                AnimatedOutlinedActionButton(
                                    text = "সহায়তার আবেদন করুন",
                                    icon = Icons.Rounded.Send,
                                    onClick = {
                                        if (isSignedIn) selectedServiceForRequest = service
                                        else onRequireLogin()
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        }

        if (isSignedIn) {
            val myRequests = (serviceRequestsState as? UiState.Success)?.data.orEmpty()
            if (myRequests.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "আপনার জমা দেওয়া আবেদনসমূহ",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                itemsIndexed(myRequests, key = { _, r -> r.id }) { idx, req ->
                    AnimatedEntranceItem(index = idx) {
                        EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = req.serviceTitle,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = MaterialTheme.colorScheme.secondaryContainer
                                ) {
                                    Text(
                                        text = when (req.status) {
                                            "in_progress" -> "চলমান"
                                            "completed" -> "সম্পন্ন"
                                            "rejected" -> "বাতিল"
                                            else -> "অপেক্ষমান"
                                        },
                                        style = MaterialTheme.typography.labelMedium,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = req.details, style = MaterialTheme.typography.bodyMedium)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "অবস্থান: ${req.location}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (req.adminNote.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "অ্যাডমিন নোট: ${req.adminNote}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    selectedServiceForRequest?.let { service ->
        var phone by remember(service) { mutableStateOf(userProfile?.phone.orEmpty()) }
        var location by remember(service) { mutableStateOf("") }
        var details by remember(service) { mutableStateOf("") }
        var urgency by remember(service) { mutableStateOf("normal") }

        AlertDialog(
            onDismissRequest = { selectedServiceForRequest = null },
            title = { Text("সেবা আবেদন: ${service.titleBn.ifBlank { service.title }}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("যোগাযোগ নম্বর") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = location,
                        onValueChange = { location = it },
                        label = { Text("এলাকা / ঠিকানা") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = details,
                        onValueChange = { details = it },
                        label = { Text("বিস্তারিত বিবরণ") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("normal" to "সাধারণ", "urgent" to "জরুরি", "critical" to "অতি জরুরি").forEach { (key, label) ->
                            FilterChip(
                                selected = urgency == key,
                                onClick = { urgency = key },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                AnimatedPrimaryButton(
                    text = "জমা দিন",
                    enabled = phone.isNotBlank() && location.isNotBlank() && details.isNotBlank(),
                    onClick = {
                        onSubmitServiceRequest(
                            ServiceRequest(
                                serviceId = service.id,
                                serviceTitle = service.titleBn.ifBlank { service.title },
                                requesterName = userProfile?.name?.ifBlank { "Member" } ?: "Member",
                                requesterPhone = phone,
                                location = location,
                                details = details,
                                urgency = urgency
                            )
                        ) {
                            selectedServiceForRequest = null
                        }
                    }
                )
            },
            dismissButton = {
                TextButton(onClick = { selectedServiceForRequest = null }) {
                    Text("বাতিল")
                }
            }
        )
    }
}
