package com.example.ui.navigation

object AppRoutes {
    const val SPLASH = "splash"
    const val HOME = "home"
    const val SERVICES = "services"
    const val ACTIVITIES = "activities"
    const val NOTICES = "notices"
    const val PROFILE = "profile"
    const val AUTH = "auth"
    const val BLOOD = "blood"
    const val DIRECTORY = "directory"
    const val FINANCE = "finance"
    const val MESSAGES = "messages"
    const val CHAT = "chat/{conversationId}"
    const val NOTIFICATIONS = "notifications"
    const val ADMIN = "admin"
    const val DEVELOPER_ANVEX = "developer_anvex"

    fun chatRoute(conversationId: String): String = "chat/$conversationId"
}
