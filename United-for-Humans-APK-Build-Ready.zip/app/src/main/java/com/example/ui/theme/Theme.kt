package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = CrimsonPrimary,
    onPrimary = Color.White,
    primaryContainer = CrimsonSoftContainer,
    onPrimaryContainer = CrimsonDeep,
    secondary = EmeraldSecondary,
    onSecondary = Color.White,
    secondaryContainer = EmeraldSoftContainer,
    onSecondaryContainer = Color(0xFF084C42),
    tertiary = AmberTertiary,
    onTertiary = Color.White,
    tertiaryContainer = AmberSoftContainer,
    onTertiaryContainer = Color(0xFF78350F),
    background = NeumorphicCanvasLight,
    onBackground = InkPrimaryLight,
    surface = NeumorphicSurfaceLight,
    onSurface = InkPrimaryLight,
    surfaceVariant = NeumorphicCardLight,
    onSurfaceVariant = InkSecondaryLight,
    outline = OutlineSubtleLight,
    error = Color(0xFFBA1A1A),
    onError = Color.White
)

private val DarkColorScheme = darkColorScheme(
    primary = CrimsonPrimaryDark,
    onPrimary = Color(0xFF3F0005),
    primaryContainer = Color(0xFF5D1318),
    onPrimaryContainer = Color(0xFFFFDADA),
    secondary = EmeraldSecondaryDark,
    onSecondary = Color(0xFF00372E),
    secondaryContainer = Color(0xFF0B493F),
    onSecondaryContainer = Color(0xFFA7F3E5),
    tertiary = AmberTertiaryDark,
    onTertiary = Color(0xFF451A03),
    tertiaryContainer = Color(0xFF633106),
    onTertiaryContainer = Color(0xFFFEF3C7),
    background = NeumorphicCanvasDark,
    onBackground = InkPrimaryDark,
    surface = NeumorphicSurfaceDark,
    onSurface = InkPrimaryDark,
    surfaceVariant = NeumorphicCardDark,
    onSurfaceVariant = InkSecondaryDark,
    outline = OutlineSubtleDark,
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005)
)

val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun UnitedForHumansTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}
