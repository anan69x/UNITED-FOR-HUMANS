package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Bloodtype
import androidx.compose.material.icons.rounded.Campaign
import androidx.compose.material.icons.rounded.Event
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.VolunteerActivism
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.UiState
import com.example.data.model.AppNotification
import com.example.ui.components.AnimatedEntranceItem
import com.example.ui.components.EmbossedCard
import com.example.ui.components.EmptyStateBengaliCard
import com.example.ui.components.GuestLoginRequiredCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsScreen(
    isSignedIn: Boolean,
    notificationsState: UiState<List<AppNotification>>,
    onBack: () -> Unit,
    onRequireLogin: () -> Unit,
    onMarkRead: (String) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("বিজ্ঞপ্তিসমূহ") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "ফিরে যান")
                    }
                }
            )
        }
    ) { padding ->
        if (!isSignedIn) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
            ) {
                GuestLoginRequiredCard(
                    title = "ব্যক্তিগত ও জরুরি বিজ্ঞপ্তি পেতে লগইন করুন",
                    subtitle = "নতুন বার্তা, রক্তের অনুরোধ, পেমেন্ট আপডেট এবং সংগঠনের ঘোষণাসমূহ এখানে দেখতে পাবেন।",
                    onLoginClick = onRequireLogin
                )
            }
        } else {
            val notifications = (notificationsState as? UiState.Success)?.data.orEmpty()
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .navigationBarsPadding(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (notifications.isEmpty()) {
                    item {
                        EmptyStateBengaliCard(
                            title = "কোনো নতুন বিজ্ঞপ্তি নেই",
                            subtitle = "নতুন বার্তা, রক্তের অনুরোধ বা অ্যাডমিন ঘোষণা এলে এখানে দেখতে পাবেন।",
                            icon = Icons.Rounded.Notifications
                        )
                    }
                } else {
                    itemsIndexed(notifications, key = { _, n -> n.id }) { idx, item ->
                        val icon = when (item.category) {
                            "message" -> Icons.Rounded.Forum
                            "blood_request" -> Icons.Rounded.Bloodtype
                            "event" -> Icons.Rounded.Event
                            "service_update" -> Icons.Rounded.VolunteerActivism
                            "payment_update" -> Icons.Rounded.AccountBalanceWallet
                            else -> Icons.Rounded.Campaign
                        }
                        AnimatedEntranceItem(index = idx) {
                            EmbossedCard(
                                onClick = { if (!item.read) onMarkRead(item.id) },
                                containerColor = if (!item.read) {
                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                                } else {
                                    MaterialTheme.colorScheme.surfaceVariant
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(verticalAlignment = Alignment.Top) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.primaryContainer),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(item.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        Text(item.body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
