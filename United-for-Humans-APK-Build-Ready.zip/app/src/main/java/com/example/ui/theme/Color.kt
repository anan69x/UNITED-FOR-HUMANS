package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Humanitarian Brand Palette anchored to United for Humans (Red Heart-Handshake) & Anvex
val CrimsonPrimary = Color(0xFFD91E2A)
val CrimsonPrimaryDark = Color(0xFFFF545D)
val CrimsonSoftContainer = Color(0xFFFFE9EB)
val CrimsonDeep = Color(0xFF9F111B)

val EmeraldSecondary = Color(0xFF0E7C6B)
val EmeraldSecondaryDark = Color(0xFF3CC5AE)
val EmeraldSoftContainer = Color(0xFFE0F5F1)

val AmberTertiary = Color(0xFFD97706)
val AmberTertiaryDark = Color(0xFFFBBF24)
val AmberSoftContainer = Color(0xFFFEF3C7)

// Subtle Embossed / Neumorphic Surfaces
val NeumorphicCanvasLight = Color(0xFFF2F5F9)
val NeumorphicSurfaceLight = Color(0xFFFAFBFD)
val NeumorphicCardLight = Color(0xFFFFFFFF)
val NeumorphicHighlightLight = Color(0xFFFFFFFF)
val NeumorphicShadowLight = Color(0xFFD5DCE6)

val NeumorphicCanvasDark = Color(0xFF0F131A)
val NeumorphicSurfaceDark = Color(0xFF171D27)
val NeumorphicCardDark = Color(0xFF1D2430)
val NeumorphicHighlightDark = Color(0xFF283142)
val NeumorphicShadowDark = Color(0xFF090C11)

val InkPrimaryLight = Color(0xFF18202C)
val InkSecondaryLight = Color(0xFF546173)
val OutlineSubtleLight = Color(0xFFDCE2EC)

val InkPrimaryDark = Color(0xFFF1F5F9)
val InkSecondaryDark = Color(0xFF9AA7B8)
val OutlineSubtleDark = Color(0xFF2C3545)
