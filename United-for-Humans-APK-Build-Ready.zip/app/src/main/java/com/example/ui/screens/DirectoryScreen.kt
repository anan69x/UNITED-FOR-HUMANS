package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.VolunteerActivism
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.core.UiState
import com.example.data.model.MemberItem
import com.example.data.model.PositionItem
import com.example.data.model.VolunteerItem
import com.example.ui.components.AnimatedEntranceItem
import com.example.ui.components.AnimatedOutlinedActionButton
import com.example.ui.components.EmbossedCard
import com.example.ui.components.EmptyStateBengaliCard
import com.example.ui.components.GuestLoginRequiredCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DirectoryScreen(
    isSignedIn: Boolean,
    positionsState: UiState<List<PositionItem>>,
    membersState: UiState<List<MemberItem>>,
    volunteersState: UiState<List<VolunteerItem>>,
    onBack: () -> Unit,
    onRequireLogin: () -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("সদস্য, পদবী ও স্বেচ্ছাসেবক") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "ফিরে যান")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .navigationBarsPadding()
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        shape = SegmentedButtonDefaults.itemShape(0, 3)
                    ) { Text("সদস্য") }
                    SegmentedButton(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        shape = SegmentedButtonDefaults.itemShape(1, 3)
                    ) { Text("স্বেচ্ছাসেবক") }
                    SegmentedButton(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        shape = SegmentedButtonDefaults.itemShape(2, 3)
                    ) { Text("পদবীসমূহ") }
                }
                if (selectedTab != 2 && isSignedIn) {
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        label = { Text("নাম বা রক্তের গ্রুপ দিয়ে খুঁজুন") },
                        leadingIcon = { Icon(Icons.Rounded.Search, null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when (selectedTab) {
                    0 -> {
                        if (!isSignedIn) {
                            item {
                                GuestLoginRequiredCard(
                                    title = "সদস্য তালিকা দেখতে লগইন করুন",
                                    subtitle = "সদস্যদের ব্যক্তিগত ফোন নম্বর ও তথ্য সুরক্ষিত রাখতে কেবল নিবন্ধিত সদস্যরাই ডিরেক্টরি দেখতে পারবেন।",
                                    onLoginClick = onRequireLogin
                                )
                            }
                        } else {
                            val members = (membersState as? UiState.Success)?.data.orEmpty().filter {
                                query.isBlank() ||
                                    it.name.contains(query, true) ||
                                    it.position.contains(query, true) ||
                                    it.bloodGroup.contains(query, true)
                            }
                            if (members.isEmpty()) {
                                item {
                                    EmptyStateBengaliCard(
                                        title = "কোনো সদস্য পাওয়া যায়নি",
                                        subtitle = "সংগঠনের সদস্য যুক্ত হলে এখানে পদবী ও তথ্যসহ দেখা যাবে।",
                                        icon = Icons.Rounded.Groups
                                    )
                                }
                            } else {
                                itemsIndexed(members, key = { _, m -> m.id }) { idx, m ->
                                    AnimatedEntranceItem(index = idx) {
                                        EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                if (m.photoUrl.startsWith("https://")) {
                                                    AsyncImage(
                                                        model = m.photoUrl,
                                                        contentDescription = m.name,
                                                        contentScale = ContentScale.Crop,
                                                        modifier = Modifier.size(50.dp).clip(CircleShape)
                                                    )
                                                } else {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(50.dp)
                                                            .clip(CircleShape)
                                                            .background(MaterialTheme.colorScheme.primaryContainer),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Icon(Icons.Rounded.Person, null, tint = MaterialTheme.colorScheme.primary)
                                                    }
                                                }
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(m.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                                    Text("${m.position} • ${m.bloodGroup}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                                                    if (m.address.isNotBlank()) {
                                                        Text(m.address, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                    }
                                                }
                                                Surface(
                                                    shape = RoundedCornerShape(50),
                                                    color = if (m.status == "active") MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface
                                                ) {
                                                    Text(
                                                        text = if (m.status == "active") "সক্রিয়" else "নিষ্ক্রিয়",
                                                        style = MaterialTheme.typography.labelMedium,
                                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                                    )
                                                }
                                            }
                                            Spacer(modifier = Modifier.height(8.dp))
                                            AnimatedOutlinedActionButton(
                                                text = "কল করুন (${m.phone})",
                                                icon = Icons.Rounded.Call,
                                                onClick = {
                                                    context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${m.phone}")))
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        if (!isSignedIn) {
                            item {
                                GuestLoginRequiredCard(
                                    title = "স্বেচ্ছাসেবক তালিকা দেখতে লগইন করুন",
                                    subtitle = "স্বেচ্ছাসেবকদের যোগাযোগ তথ্য সুরক্ষার জন্য লগইন প্রয়োজন।",
                                    onLoginClick = onRequireLogin
                                )
                            }
                        } else {
                            val volunteers = (volunteersState as? UiState.Success)?.data.orEmpty().filter {
                                query.isBlank() ||
                                    it.name.contains(query, true) ||
                                    it.skills.contains(query, true) ||
                                    it.bloodGroup.contains(query, true)
                            }
                            if (volunteers.isEmpty()) {
                                item {
                                    EmptyStateBengaliCard(
                                        title = "কোনো স্বেচ্ছাসেবক পাওয়া যায়নি",
                                        subtitle = "অ্যাডমিন প্যানেল থেকে স্বেচ্ছাসেবক যুক্ত করলে এখানে দেখা যাবে।",
                                        icon = Icons.Rounded.VolunteerActivism
                                    )
                                }
                            } else {
                                itemsIndexed(volunteers, key = { _, v -> v.id }) { idx, v ->
                                    AnimatedEntranceItem(index = idx) {
                                        EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                            Text(v.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                            Text("দক্ষতা: ${v.skills}", style = MaterialTheme.typography.bodyMedium)
                                            Text(
                                                text = "সময়: ${v.availability} • রক্তের গ্রুপ: ${v.bloodGroup}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Spacer(modifier = Modifier.height(8.dp))
                                            AnimatedOutlinedActionButton(
                                                text = "কল করুন (${v.phone})",
                                                icon = Icons.Rounded.Call,
                                                onClick = {
                                                    context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${v.phone}")))
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    else -> {
                        val positions = (positionsState as? UiState.Success)?.data.orEmpty()
                        if (positions.isEmpty()) {
                            item {
                                EmptyStateBengaliCard(
                                    title = "কোনো পদবী যুক্ত হয়নি",
                                    subtitle = "সংগঠনের কার্যকরী পদবীসমূহ এখানে ক্রমানুসারে প্রদর্শিত হবে।",
                                    icon = Icons.Rounded.Badge
                                )
                            }
                        } else {
                            itemsIndexed(positions, key = { _, p -> p.id }) { idx, p ->
                                AnimatedEntranceItem(index = idx) {
                                    EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Rounded.Badge, null, tint = MaterialTheme.colorScheme.primary)
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column {
                                                Text(p.titleBn.ifBlank { p.title }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                                if (p.title.isNotBlank() && p.titleBn.isNotBlank()) {
                                                    Text(p.title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                                                }
                                                if (p.description.isNotBlank()) {
                                                    Text(p.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
