package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.Bloodtype
import androidx.compose.material.icons.rounded.Campaign
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.VolunteerActivism
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.core.AppConfig
import com.example.core.UiState
import com.example.data.model.ActivityItem
import com.example.data.model.BloodRequest
import com.example.data.model.MemberItem
import com.example.data.model.NoticeItem
import com.example.data.model.ServiceCategory
import com.example.data.model.VolunteerItem
import com.example.ui.components.AnimatedEntranceItem
import com.example.ui.components.EmbossedCard
import com.example.ui.components.EmptyStateBengaliCard
import com.example.ui.components.serviceIconForKey
import com.example.ui.theme.AmberTertiary
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.EmeraldSecondary

@Composable
fun HomeScreen(
    isSignedIn: Boolean,
    servicesState: UiState<List<ServiceCategory>>,
    activitiesState: UiState<List<ActivityItem>>,
    noticesState: UiState<List<NoticeItem>>,
    membersState: UiState<List<MemberItem>>,
    volunteersState: UiState<List<VolunteerItem>>,
    bloodRequestsState: UiState<List<BloodRequest>>,
    onOpenBlood: () -> Unit,
    onOpenDirectory: () -> Unit,
    onOpenFinance: () -> Unit,
    onOpenMessages: () -> Unit,
    onOpenServices: () -> Unit,
    onOpenActivities: () -> Unit,
    onOpenNotices: () -> Unit
) {
    val services = (servicesState as? UiState.Success)?.data.orEmpty().filter { it.active }
    val activities = (activitiesState as? UiState.Success)?.data.orEmpty()
    val notices = (noticesState as? UiState.Success)?.data.orEmpty()
    val membersCount = (membersState as? UiState.Success)?.data?.size ?: 0
    val volunteersCount = (volunteersState as? UiState.Success)?.data?.size ?: 0
    val completedActivitiesCount = activities.count { it.status == "completed" }
    val openBloodCount = (bloodRequestsState as? UiState.Success)?.data?.count { it.status == "open" } ?: 0

    val pulseTransition = rememberInfiniteTransition(label = "home_hero_pulse")
    val badgeScale by pulseTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "hero_logo_pulse"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Organization Card
        item {
            AnimatedEntranceItem(index = 0) {
                EmbossedCard(
                    modifier = Modifier.fillMaxWidth(),
                    cornerRadius = 24.dp,
                    contentPadding = PaddingValues(18.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f),
                                        MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.52f)
                                    )
                                )
                            )
                            .padding(16.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.logo_united_for_humans),
                                contentDescription = AppConfig.APP_NAME,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .size(74.dp)
                                    .graphicsLayer {
                                        scaleX = badgeScale
                                        scaleY = badgeScale
                                    }
                                    .clip(CircleShape)
                                    .background(Color.White)
                                    .border(2.dp, Color.White, CircleShape)
                                    .padding(6.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = Color.White.copy(alpha = 0.85f)
                                ) {
                                    Text(
                                        text = AppConfig.ORG_TYPE_BN,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = AppConfig.TAGLINE_BN,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.onBackground,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = AppConfig.TAGLINE_EN,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // Organization Real Firestore Statistics
        item {
            AnimatedEntranceItem(index = 1) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "সংগঠনের পরিসংখ্যান",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        StatTile(
                            label = "সক্রিয় সেবা",
                            value = services.size.toString(),
                            icon = Icons.Rounded.VolunteerActivism,
                            tint = CrimsonPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        StatTile(
                            label = "সম্পন্ন কার্যক্রম",
                            value = completedActivitiesCount.toString(),
                            icon = Icons.Rounded.CheckCircle,
                            tint = EmeraldSecondary,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        StatTile(
                            label = if (isSignedIn) "মোট সদস্য" else "সদস্য (লগইন)",
                            value = if (isSignedIn) membersCount.toString() else "—",
                            icon = Icons.Rounded.Groups,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.weight(1f)
                        )
                        StatTile(
                            label = if (isSignedIn) "স্বেচ্ছাসেবক" else "রক্তের অনুরোধ",
                            value = if (isSignedIn) volunteersCount.toString() else "—",
                            icon = Icons.Rounded.Bloodtype,
                            tint = AmberTertiary,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (isSignedIn && openBloodCount > 0) {
                        EmbossedCard(
                            onClick = onOpenBlood,
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f),
                            contentPadding = PaddingValues(14.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(Icons.Rounded.Bloodtype, null, tint = CrimsonPrimary)
                                Text(
                                    text = "জরুরি রক্তের অনুরোধ সক্রিয় রয়েছে: $openBloodCount টি",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.weight(1f)
                                )
                                Icon(Icons.AutoMirrored.Rounded.ArrowForward, null, tint = CrimsonPrimary)
                            }
                        }
                    }
                }
            }
        }

        // Quick Humanitarian Portals
        item {
            AnimatedEntranceItem(index = 2) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "প্রধান বিভাগসমূহ",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        QuickHubCard(
                            title = "রক্তদান",
                            subtitle = "দাতা ও অনুরোধ",
                            icon = Icons.Rounded.Bloodtype,
                            accent = CrimsonPrimary,
                            onClick = onOpenBlood,
                            modifier = Modifier.weight(1f).testTag("home_quick_blood")
                        )
                        QuickHubCard(
                            title = "সদস্য ও স্বেচ্ছাসেবক",
                            subtitle = "পদবী ও ডিরেক্টরি",
                            icon = Icons.Rounded.Groups,
                            accent = EmeraldSecondary,
                            onClick = onOpenDirectory,
                            modifier = Modifier.weight(1f).testTag("home_quick_directory")
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        QuickHubCard(
                            title = "আর্থিক স্বচ্ছতা",
                            subtitle = "চাঁদা ও অনুদান",
                            icon = Icons.Rounded.AccountBalanceWallet,
                            accent = AmberTertiary,
                            onClick = onOpenFinance,
                            modifier = Modifier.weight(1f).testTag("home_quick_finance")
                        )
                        QuickHubCard(
                            title = "বার্তা বিনিময়",
                            subtitle = "১-টু-১ চ্যাট",
                            icon = Icons.Rounded.Forum,
                            accent = MaterialTheme.colorScheme.primary,
                            onClick = onOpenMessages,
                            modifier = Modifier.weight(1f).testTag("home_quick_messages")
                        )
                    }
                }
            }
        }

        // Featured Services from Firestore
        item {
            SectionHeaderRow(title = "মানবিক সেবাসমূহ", actionLabel = "সব দেখুন", onAction = onOpenServices)
        }
        item {
            if (services.isEmpty()) {
                EmptyStateBengaliCard(
                    title = "এখনও কোনো সেবা বিভাগ যুক্ত হয়নি",
                    subtitle = "অ্যাডমিন প্যানেল থেকে নতুন মানবিক সেবা বিভাগ যুক্ত করলে এখানে দেখা যাবে।"
                )
            } else {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(services.take(8), key = { it.id }) { srv ->
                        EmbossedCard(
                            onClick = onOpenServices,
                            modifier = Modifier.width(172.dp),
                            contentPadding = PaddingValues(14.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = serviceIconForKey(srv.iconKey),
                                    contentDescription = srv.titleBn,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = srv.titleBn.ifBlank { srv.title },
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = srv.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // Recent Humanitarian Activities from Firestore
        item {
            SectionHeaderRow(title = "সাম্প্রতিক কার্যক্রম", actionLabel = "সব দেখুন", onAction = onOpenActivities)
        }
        if (activities.isEmpty()) {
            item {
                EmptyStateBengaliCard(
                    title = "এখনও কোনো কার্যক্রম যুক্ত করা হয়নি",
                    subtitle = "সংগঠনের সাম্প্রতিক মানবিক কার্যক্রম যুক্ত হলে এখানে প্রদর্শিত হবে।"
                )
            }
        } else {
            items(activities.take(3), key = { it.id }) { activity ->
                AnimatedEntranceItem {
                    EmbossedCard(onClick = onOpenActivities, modifier = Modifier.fillMaxWidth()) {
                        if (activity.imageUrl.startsWith("https://")) {
                            AsyncImage(
                                model = activity.imageUrl,
                                contentDescription = activity.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(148.dp)
                                    .clip(RoundedCornerShape(14.dp))
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = if (activity.status == "completed") {
                                    MaterialTheme.colorScheme.secondaryContainer
                                } else {
                                    MaterialTheme.colorScheme.tertiaryContainer
                                }
                            ) {
                                Text(
                                    text = if (activity.status == "completed") "সম্পন্ন" else "চলমান",
                                    style = MaterialTheme.typography.labelMedium,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = activity.category,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = activity.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Rounded.LocationOn,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${activity.location} • ${activity.dateText}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Latest Notice Preview
        item {
            SectionHeaderRow(title = "সর্বশেষ নোটিশ", actionLabel = "সব দেখুন", onAction = onOpenNotices)
        }
        if (notices.isEmpty()) {
            item {
                EmptyStateBengaliCard(
                    title = "কোনো নোটিশ প্রকাশিত হয়নি",
                    subtitle = "সংগঠনের নতুন ঘোষণা, সভা বা ইভেন্টের তথ্য এখানে দেখা যাবে।",
                    icon = Icons.Rounded.Campaign
                )
            }
        } else {
            item {
                val latest = notices.first()
                EmbossedCard(onClick = onOpenNotices, modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Campaign, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = latest.title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = latest.body,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionHeaderRow(
    title: String,
    actionLabel: String,
    onAction: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        TextButton(onClick = onAction) {
            Text(actionLabel)
        }
    }
}

@Composable
private fun StatTile(
    label: String,
    value: String,
    icon: ImageVector,
    tint: Color,
    modifier: Modifier = Modifier
) {
    EmbossedCard(modifier = modifier, contentPadding = PaddingValues(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(tint.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun QuickHubCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    EmbossedCard(
        modifier = modifier,
        onClick = onClick,
        contentPadding = PaddingValues(14.dp)
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(accent.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = title, tint = accent, modifier = Modifier.size(22.dp))
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
