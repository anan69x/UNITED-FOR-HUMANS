const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const SUPER_ADMIN_UID = "PhjnBPiB5DNWAjiTdsYtB7oDAq93";
const ALICE_UID = "alice_member_1";
const BOB_UID = "bob_admin_2";
const ORG_ID = "anvex_united_for_humans";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated guest: can read public non-PII services/activities/notices, denied PII/finance/messages", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertSucceeds(unauthDb.collection("services").get());
  await assertSucceeds(unauthDb.collection("activities").get());
  await assertSucceeds(unauthDb.collection("notices").get());
  await assertSucceeds(unauthDb.collection("organizations").get());

  await assertFails(unauthDb.collection("users").get());
  await assertFails(unauthDb.collection("members").get());
  await assertFails(unauthDb.collection("contributions").get());
  await assertFails(unauthDb.collection("donations").get());
  await assertFails(unauthDb.collection("expenses").get());
  await assertFails(unauthDb.collection("bloodRequests").get());
  await assertFails(unauthDb.collection("medicalCases").get());
  await assertFails(unauthDb.collection("conversations").get());
  await assertFails(unauthDb.collection("notifications").get());
});

test("Registration: new user must have role=member and cannot self-assign admin", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date(Date.now() - 1000);

  // Escalation attempt rejected
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).set({
      uid: ALICE_UID,
      name: "Alice",
      email: "alice@example.com",
      organizationId: ORG_ID,
      role: "admin",
      permissions: ["manage_finance"],
      status: "active",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Valid member profile creation succeeds
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      uid: ALICE_UID,
      name: "Alice Rahman",
      email: "alice@example.com",
      phone: "01700000000",
      organizationId: ORG_ID,
      role: "member",
      permissions: [],
      status: "active",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Member cannot self-escalate role on update
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      role: "admin",
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Member can update own allowed profile fields
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      name: "Alice Rahman Updated",
      bloodGroup: "O+",
      updatedAt: new Date(Date.now() - 500),
    })
  );
});

test("Super Admin UID: can bootstrap super_admin, assign admin role & permissions, and manage services/finance", async () => {
  const superDb = testEnv.authenticatedContext(SUPER_ADMIN_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = new Date(Date.now() - 2000);

  await assertSucceeds(
    superDb.collection("users").doc(SUPER_ADMIN_UID).set({
      uid: SUPER_ADMIN_UID,
      name: "Super Admin",
      email: "admin@anvex.org",
      organizationId: ORG_ID,
      role: "super_admin",
      permissions: [],
      status: "active",
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    bobDb.collection("users").doc(BOB_UID).set({
      uid: BOB_UID,
      name: "Bob Hasan",
      email: "bob@anvex.org",
      organizationId: ORG_ID,
      role: "member",
      permissions: [],
      status: "active",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Super Admin promotes Bob to admin with finance permission only
  await assertSucceeds(
    superDb.collection("users").doc(BOB_UID).update({
      role: "admin",
      permissions: ["manage_finance"],
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Bob can record a contribution, but CANNOT create a service category
  await assertSucceeds(
    bobDb.collection("contributions").doc("contrib_1").set({
      organizationId: ORG_ID,
      memberName: "Alice Rahman",
      expectedAmount: 500,
      paidAmount: 500,
      dueAmount: 0,
      month: "November 2026",
      paymentDate: "2026-11-25",
      paymentMethod: "bKash",
      recordedBy: BOB_UID,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertFails(
    bobDb.collection("services").doc("srv_1").set({
      organizationId: ORG_ID,
      title: "Blood Donation",
      titleBn: "রক্তদান",
      description: "Emergency blood support",
      iconKey: "blood",
      active: true,
      sortOrder: 1,
      createdAt: now,
      updatedAt: now,
    })
  );

  // Super Admin can create service category
  await assertSucceeds(
    superDb.collection("services").doc("srv_1").set({
      organizationId: ORG_ID,
      title: "Blood Donation",
      titleBn: "রক্তদান",
      description: "Emergency blood support",
      iconKey: "blood",
      active: true,
      sortOrder: 1,
      createdAt: now,
      updatedAt: now,
    })
  );
});

test("Messaging: only conversation participants can read/send messages", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const charlieDb = testEnv.authenticatedContext("charlie_outsider").firestore();
  const now = new Date(Date.now() - 1000);

  await assertSucceeds(
    aliceDb.collection("conversations").doc("conv_1").set({
      organizationId: ORG_ID,
      participantUids: [ALICE_UID, BOB_UID],
      participantNames: { [ALICE_UID]: "Alice", [BOB_UID]: "Bob" },
      lastMessage: "Assalamu Alaikum",
      lastSenderUid: ALICE_UID,
      lastMessageAt: now,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("conversations").doc("conv_1").collection("messages").doc("msg_1").set({
      conversationId: "conv_1",
      participantUids: [ALICE_UID, BOB_UID],
      senderUid: ALICE_UID,
      senderName: "Alice",
      text: "Assalamu Alaikum",
      seenBy: [ALICE_UID],
      createdAt: now,
    })
  );

  // Bob can read and mark seen
  await assertSucceeds(
    bobDb
      .collection("conversations")
      .doc("conv_1")
      .collection("messages")
      .where("participantUids", "array-contains", BOB_UID)
      .get()
  );

  await assertSucceeds(
    bobDb.collection("conversations").doc("conv_1").collection("messages").doc("msg_1").update({
      seenBy: [ALICE_UID, BOB_UID],
    })
  );

  // Charlie cannot read conversation or messages
  await assertFails(charlieDb.collection("conversations").doc("conv_1").get());
  await assertFails(
    charlieDb
      .collection("conversations")
      .doc("conv_1")
      .collection("messages")
      .doc("msg_1")
      .get()
  );
});
