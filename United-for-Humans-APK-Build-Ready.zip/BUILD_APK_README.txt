UNITED FOR HUMANS — APK BUILD

I inspected the uploaded ZIP. It is a native Android/Kotlin + Jetpack Compose project,
not a simple HTML website. This archive includes a GitHub Actions workflow that builds
a DEBUG APK in the cloud.

HOW TO GET THE APK (Android phone is enough):
1. Extract this ZIP.
2. Create/sign in to a GitHub account and create a NEW repository.
3. Upload all extracted project files/folders to the repository root
   (make sure .github/workflows/build-apk.yml is included).
4. Open the repository -> Actions.
5. Select "Build United for Humans APK" -> "Run workflow" if it did not start
   automatically after uploading to the main branch.
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run, scroll to Artifacts, and download
   "United-for-Humans-debug-apk".
8. Extract the downloaded artifact ZIP; install the .apk on your Android phone.

IMPORTANT:
- I could not compile and attach an APK directly in this chat because this runtime
  does not have the Android SDK or Gradle installed.
- This workflow is intended to produce an installable DEBUG APK, not a Play Store
  release. A release APK needs a private signing keystore and secure signing setup.
- The project contains Firebase configuration. Keep the repository PRIVATE if its
  configuration includes credentials or other sensitive values. Firebase client
  configuration is not a substitute for Firestore/Auth security rules.
- The cloud build can still fail if the source project has compile errors or if one
  of its dependency/plugin versions is unavailable. A successful workflow is the
  confirmation that the APK was built.
